import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import app


@pytest.fixture
def client() -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)

    def override_get_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def register_and_login(client: TestClient, *, email: str, role: str) -> str:
    payload = {
        "email": email,
        "password": "password123",
        "full_name": "Application User",
        "role": role,
    }
    assert client.post("/api/auth/register", json=payload).status_code == 201
    return client.post(
        "/api/auth/login",
        data={"username": email, "password": "password123"},
    ).json()["access_token"]


def create_job(client: TestClient, recruiter_headers: dict[str, str]) -> str:
    assert client.post(
        "/api/companies",
        headers=recruiter_headers,
        json={"name": "Application Labs", "location": "Remote"},
    ).status_code == 201
    response = client.post(
        "/api/jobs",
        headers=recruiter_headers,
        json={
            "title": "Backend Intern",
            "description": "Build reliable APIs with a platform team and ship services.",
            "location": "Remote",
            "work_mode": "REMOTE",
            "job_type": "INTERNSHIP",
            "required_skills": ["Python"],
            "openings": 1,
        },
    )
    assert response.status_code == 201
    return response.json()["id"]


def test_student_can_apply_save_and_unsave_job(client: TestClient) -> None:
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    student_token = register_and_login(client, email="student@example.com", role="STUDENT")
    job_id = create_job(client, {"Authorization": f"Bearer {recruiter_token}"})
    student_headers = {"Authorization": f"Bearer {student_token}"}

    application = client.post(
        f"/api/jobs/{job_id}/apply",
        headers=student_headers,
        json={"cover_letter": "I would love to contribute to the platform team."},
    )
    duplicate_application = client.post(f"/api/jobs/{job_id}/apply", headers=student_headers, json={})
    saved = client.post(f"/api/jobs/{job_id}/save", headers=student_headers)
    duplicate_saved = client.post(f"/api/jobs/{job_id}/save", headers=student_headers)
    saved_list = client.get("/api/saved-jobs", headers=student_headers)
    unsaved = client.delete(f"/api/jobs/{job_id}/save", headers=student_headers)

    assert application.status_code == 201
    assert application.json()["status"] == "APPLIED"
    assert duplicate_application.status_code == 409
    assert saved.status_code == 201
    assert duplicate_saved.status_code == 409
    assert len(saved_list.json()) == 1
    assert unsaved.status_code == 204


def test_recruiter_can_review_and_update_application_status(client: TestClient) -> None:
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    student_token = register_and_login(client, email="student@example.com", role="STUDENT")
    other_recruiter_token = register_and_login(client, email="other@example.com", role="RECRUITER")
    recruiter_headers = {"Authorization": f"Bearer {recruiter_token}"}
    job_id = create_job(client, recruiter_headers)

    application = client.post(
        f"/api/jobs/{job_id}/apply",
        headers={"Authorization": f"Bearer {student_token}"},
        json={},
    )
    application_id = application.json()["id"]
    review = client.get(f"/api/recruiter/applications/{job_id}", headers=recruiter_headers)
    updated = client.patch(
        f"/api/applications/{application_id}/status",
        headers=recruiter_headers,
        json={"status": "SHORTLISTED"},
    )
    denied = client.get(
        f"/api/recruiter/applications/{job_id}",
        headers={"Authorization": f"Bearer {other_recruiter_token}"},
    )

    assert review.status_code == 200
    assert len(review.json()) == 1
    assert updated.status_code == 200
    assert updated.json()["status"] == "SHORTLISTED"
    assert denied.status_code == 404
