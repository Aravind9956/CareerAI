from types import SimpleNamespace

import fitz
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import app
import app.services.resumes as resume_service


@pytest.fixture
def client(tmp_path, monkeypatch) -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    monkeypatch.setattr(
        resume_service,
        "get_settings",
        lambda: SimpleNamespace(resume_storage_dir=str(tmp_path), max_resume_size_mb=5),
    )

    def override_get_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def register_and_login(client: TestClient, *, email: str, role: str) -> str:
    payload = {
        "email": email,
        "password": "password123",
        "full_name": "Resume User",
        "role": role,
    }
    assert client.post("/api/auth/register", json=payload).status_code == 201
    return client.post(
        "/api/auth/login",
        data={"username": email, "password": "password123"},
    ).json()["access_token"]


def pdf_bytes(text: str) -> bytes:
    document = fitz.open()
    page = document.new_page()
    page.insert_text((72, 72), text)
    content = document.tobytes()
    document.close()
    return content


def test_student_can_upload_replace_download_and_delete_resume(client: TestClient) -> None:
    token = register_and_login(client, email="student@example.com", role="STUDENT")
    headers = {"Authorization": f"Bearer {token}"}

    first = client.post(
        "/api/resumes/upload",
        headers=headers,
        files={"file": ("resume.pdf", pdf_bytes("Alex Rivera Python FastAPI"), "application/pdf")},
    )
    second = client.post(
        "/api/resumes/upload",
        headers=headers,
        files={"file": ("updated-resume.pdf", pdf_bytes("Alex Rivera Python PostgreSQL"), "application/pdf")},
    )
    resumes = client.get("/api/resumes", headers=headers)
    download = client.get(f"/api/resumes/{second.json()['id']}/download", headers=headers)
    deleted = client.delete(f"/api/resumes/{first.json()['id']}", headers=headers)

    assert first.status_code == 201
    assert "Python FastAPI" in first.json()["extracted_text"]
    assert second.status_code == 201
    assert resumes.status_code == 200
    assert len(resumes.json()) == 2
    assert sum(resume["is_current"] for resume in resumes.json()) == 1
    assert download.status_code == 200
    assert download.headers["content-type"] == "application/pdf"
    assert deleted.status_code == 204


def test_resume_upload_rejects_invalid_files_and_non_students(client: TestClient) -> None:
    student_token = register_and_login(client, email="student@example.com", role="STUDENT")
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")

    invalid_extension = client.post(
        "/api/resumes/upload",
        headers={"Authorization": f"Bearer {student_token}"},
        files={"file": ("resume.txt", b"not a pdf", "text/plain")},
    )
    invalid_pdf = client.post(
        "/api/resumes/upload",
        headers={"Authorization": f"Bearer {student_token}"},
        files={"file": ("resume.pdf", b"%PDF but invalid", "application/pdf")},
    )
    recruiter_upload = client.post(
        "/api/resumes/upload",
        headers={"Authorization": f"Bearer {recruiter_token}"},
        files={"file": ("resume.pdf", pdf_bytes("Recruiter"), "application/pdf")},
    )

    assert invalid_extension.status_code == 415
    assert invalid_pdf.status_code == 400
    assert recruiter_upload.status_code == 403
