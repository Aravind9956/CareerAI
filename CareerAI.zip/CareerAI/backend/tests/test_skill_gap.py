import fitz
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import app


@pytest.fixture
def client() -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)

    def override_get_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def register_and_login(client: TestClient, *, email: str, role: str) -> str:
    payload = {"email": email, "password": "password123", "full_name": "Gap User", "role": role}
    assert client.post("/api/auth/register", json=payload).status_code == 201
    return client.post("/api/auth/login", data={"username": email, "password": "password123"}).json()["access_token"]


def prepare_job_and_resume(client: TestClient) -> tuple[str, str, str]:
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    student_token = register_and_login(client, email="student@example.com", role="STUDENT")
    recruiter_headers = {"Authorization": f"Bearer {recruiter_token}"}
    assert client.post("/api/companies", headers=recruiter_headers, json={"name": "Gap Labs"}).status_code == 201
    job = client.post(
        "/api/jobs",
        headers=recruiter_headers,
        json={
            "title": "Platform Intern",
            "description": "Build reliable backend services and learn deployment.",
            "work_mode": "REMOTE",
            "job_type": "INTERNSHIP",
            "required_skills": ["Python", "Docker", "AWS"],
            "preferred_skills": ["Redis"],
        },
    )
    assert job.status_code == 201
    document = fitz.open()
    document.new_page().insert_text((72, 72), "Alex alex@example.com Python FastAPI")
    content = document.tobytes()
    document.close()
    resume = client.post(
        "/api/resumes/upload",
        headers={"Authorization": f"Bearer {student_token}"},
        files={"file": ("resume.pdf", content, "application/pdf")},
    )
    assert resume.status_code == 201
    return job.json()["id"], resume.json()["id"], student_token


def test_skill_gap_returns_current_skills_gaps_and_learning_path(client: TestClient) -> None:
    job_id, resume_id, token = prepare_job_and_resume(client)

    response = client.post(
        "/api/ai/skill-gap",
        headers={"Authorization": f"Bearer {token}"},
        json={"job_id": job_id, "resume_id": resume_id},
    )

    body = response.json()
    assert response.status_code == 200
    assert body["your_skills"] == ["Python", "FastAPI"]
    assert body["skills_to_develop"] == ["Docker", "AWS", "Redis"]
    assert body["learning_path"][0] == "Docker fundamentals"
    assert body["is_guidance"] is True
    assert "definitive" not in body["explanation"].casefold()


def test_skill_gap_protects_resume_ownership(client: TestClient) -> None:
    job_id, resume_id, _ = prepare_job_and_resume(client)
    other_token = register_and_login(client, email="other@example.com", role="STUDENT")

    response = client.post(
        "/api/ai/skill-gap",
        headers={"Authorization": f"Bearer {other_token}"},
        json={"job_id": job_id, "resume_id": resume_id},
    )

    assert response.status_code == 404
