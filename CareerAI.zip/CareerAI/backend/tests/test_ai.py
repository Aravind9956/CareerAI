import pytest
import fitz
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import app


@pytest.fixture
def client(tmp_path, monkeypatch) -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    monkeypatch.setenv("AI_PROVIDER", "mock")

    def override_get_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def register_and_login(client: TestClient, *, email: str, role: str) -> str:
    payload = {
        "email": email,
        "password": "password123",
        "full_name": "AI User",
        "role": role,
    }
    assert client.post("/api/auth/register", json=payload).status_code == 201
    return client.post(
        "/api/auth/login",
        data={"username": email, "password": "password123"},
    ).json()["access_token"]


def resume_pdf() -> bytes:
    document = fitz.open()
    document.new_page().insert_text((72, 72), "Alex Rivera alex@example.com Python FastAPI PostgreSQL")
    content = document.tobytes()
    document.close()
    return content


def upload_resume(client: TestClient, token: str) -> str:
    response = client.post(
        "/api/resumes/upload",
        headers={"Authorization": f"Bearer {token}"},
        files={"file": ("resume.pdf", resume_pdf(), "application/pdf")},
    )
    assert response.status_code == 201
    return response.json()["id"]


def test_student_can_generate_and_list_structured_resume_analysis(client: TestClient) -> None:
    token = register_and_login(client, email="student@example.com", role="STUDENT")
    resume_id = upload_resume(client, token)
    headers = {"Authorization": f"Bearer {token}"}

    response = client.post(
        "/api/ai/resume-analysis",
        headers=headers,
        json={
            "resume_id": resume_id,
            "target_job_description": "Backend role requiring Python, FastAPI, Docker, and AWS",
        },
    )
    history = client.get(f"/api/ai/resume-analyses?resume_id={resume_id}", headers=headers)
    result = response.json()["result"]

    assert response.status_code == 201
    assert response.json()["provider"] == "mock"
    assert {skill["name"] for skill in result["skills"]} == {"Python", "FastAPI", "PostgreSQL"}
    assert "Docker" in result["missing_skills"]
    assert "AWS" in result["missing_skills"]
    assert "Java" not in result["missing_skills"]
    assert 0 <= result["overall_score"] <= 100
    assert history.status_code == 200
    assert len(history.json()) == 1


def test_analysis_rejects_foreign_resume_and_non_students(client: TestClient) -> None:
    student_token = register_and_login(client, email="student@example.com", role="STUDENT")
    other_student_token = register_and_login(client, email="other@example.com", role="STUDENT")
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    resume_id = upload_resume(client, student_token)

    foreign = client.post(
        "/api/ai/resume-analysis",
        headers={"Authorization": f"Bearer {other_student_token}"},
        json={"resume_id": resume_id},
    )
    recruiter = client.post(
        "/api/ai/resume-analysis",
        headers={"Authorization": f"Bearer {recruiter_token}"},
        json={"resume_id": resume_id},
    )

    assert foreign.status_code == 404
    assert recruiter.status_code == 403
