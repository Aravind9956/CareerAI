import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import app


@pytest.fixture
def client() -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)

    def override_get_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def register_and_login(client: TestClient, *, email: str, role: str) -> str:
    payload = {
        "email": email,
        "password": "password123",
        "full_name": "Job User",
        "role": role,
    }
    assert client.post("/api/auth/register", json=payload).status_code == 201
    return client.post(
        "/api/auth/login",
        data={"username": email, "password": "password123"},
    ).json()["access_token"]


def create_company(client: TestClient, headers: dict[str, str]) -> None:
    response = client.post("/api/companies", headers=headers, json={"name": "Northstar Labs", "location": "Remote"})
    assert response.status_code == 201


def job_payload(title: str, *, job_type: str = "INTERNSHIP") -> dict:
    return {
        "title": title,
        "description": "Build reliable APIs with a platform team and ship production services.",
        "location": "Remote",
        "work_mode": "REMOTE",
        "job_type": job_type,
        "required_skills": ["Python", "FastAPI"],
        "preferred_skills": ["Docker"],
        "salary_range": "$30/hour",
        "experience_requirement": "Entry level",
        "education_requirement": "Computer Science or equivalent",
        "openings": 2,
    }


def test_recruiter_can_create_and_manage_job(client: TestClient) -> None:
    token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    headers = {"Authorization": f"Bearer {token}"}
    create_company(client, headers)

    created = client.post("/api/jobs", headers=headers, json=job_payload("Backend Intern"))
    assert created.status_code == 201
    job_id = created.json()["id"]
    assert created.json()["required_skills"] == ["Python", "FastAPI"]
    assert created.json()["company_name"] == "Northstar Labs"

    updated = client.put("/api/jobs/" + job_id, headers=headers, json={"title": "Senior Backend Intern"})
    deleted = client.delete("/api/jobs/" + job_id, headers=headers)
    public_detail = client.get("/api/jobs/" + job_id)

    assert updated.status_code == 200
    assert updated.json()["title"] == "Senior Backend Intern"
    assert deleted.status_code == 204
    assert public_detail.status_code == 404


def test_public_job_browse_filters_and_paginates(client: TestClient) -> None:
    token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    headers = {"Authorization": f"Bearer {token}"}
    create_company(client, headers)
    assert client.post("/api/jobs", headers=headers, json=job_payload("Python Backend Intern")).status_code == 201
    design_payload = job_payload("Design Intern")
    design_payload["required_skills"] = ["Figma"]
    assert client.post("/api/jobs", headers=headers, json=design_payload).status_code == 201
    assert client.post("/api/jobs", headers=headers, json=job_payload("Python Backend Engineer", job_type="FULL_TIME")).status_code == 201

    response = client.get("/api/jobs?q=python&job_type=INTERNSHIP&page=1&page_size=1")

    assert response.status_code == 200
    assert response.json()["total"] == 1
    assert response.json()["pages"] == 1
    assert response.json()["items"][0]["title"] == "Python Backend Intern"


def test_students_cannot_manage_jobs(client: TestClient) -> None:
    token = register_and_login(client, email="student@example.com", role="STUDENT")

    response = client.post("/api/jobs", headers={"Authorization": f"Bearer {token}"}, json=job_payload("Student Job"))

    assert response.status_code == 403
