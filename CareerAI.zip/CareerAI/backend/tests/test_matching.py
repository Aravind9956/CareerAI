import fitz
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import app


@pytest.fixture
def client() -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)

    def override_get_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def register_and_login(client: TestClient, *, email: str, role: str) -> str:
    payload = {"email": email, "password": "password123", "full_name": "Match User", "role": role}
    assert client.post("/api/auth/register", json=payload).status_code == 201
    return client.post("/api/auth/login", data={"username": email, "password": "password123"}).json()["access_token"]


def upload_resume(client: TestClient, token: str) -> str:
    document = fitz.open()
    document.new_page().insert_text((72, 72), "Alex alex@example.com Python FastAPI PostgreSQL")
    content = document.tobytes()
    document.close()
    response = client.post(
        "/api/resumes/upload",
        headers={"Authorization": f"Bearer {token}"},
        files={"file": ("resume.pdf", content, "application/pdf")},
    )
    assert response.status_code == 201
    return response.json()["id"]


def create_job(client: TestClient, token: str) -> str:
    headers = {"Authorization": f"Bearer {token}"}
    assert client.post("/api/companies", headers=headers, json={"name": "Match Labs"}).status_code == 201
    response = client.post(
        "/api/jobs",
        headers=headers,
        json={
            "title": "Python API Intern",
            "description": "Build backend services and maintain production APIs.",
            "work_mode": "REMOTE",
            "job_type": "INTERNSHIP",
            "required_skills": ["Python", "FastAPI", "Docker"],
            "preferred_skills": ["AWS"],
        },
    )
    assert response.status_code == 201
    return response.json()["id"]


def test_student_can_generate_and_refresh_job_match(client: TestClient) -> None:
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    student_token = register_and_login(client, email="student@example.com", role="STUDENT")
    job_id = create_job(client, recruiter_token)
    resume_id = upload_resume(client, student_token)
    headers = {"Authorization": f"Bearer {student_token}"}

    first = client.post("/api/ai/job-match", headers=headers, json={"job_id": job_id, "resume_id": resume_id})
    second = client.post("/api/ai/job-match", headers=headers, json={"job_id": job_id, "resume_id": resume_id})
    history = client.get("/api/ai/job-matches", headers=headers)

    assert first.status_code == 201
    assert 0 <= first.json()["score"] <= 100
    assert "Python" in first.json()["matched_skills"]
    assert "FastAPI" in first.json()["matched_skills"]
    assert "Docker" in first.json()["skill_gaps"]
    assert first.json()["is_estimate"] is True
    assert second.json()["id"] == first.json()["id"]
    assert history.status_code == 200
    assert len(history.json()) == 1


def test_job_match_is_role_and_ownership_scoped(client: TestClient) -> None:
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    student_token = register_and_login(client, email="student@example.com", role="STUDENT")
    other_student_token = register_and_login(client, email="other@example.com", role="STUDENT")
    recruiter_headers = {"Authorization": f"Bearer {recruiter_token}"}
    job_id = create_job(client, recruiter_token)
    resume_id = upload_resume(client, student_token)

    foreign = client.post(
        "/api/ai/job-match",
        headers={"Authorization": f"Bearer {other_student_token}"},
        json={"job_id": job_id, "resume_id": resume_id},
    )
    recruiter = client.post(
        "/api/ai/job-match",
        headers=recruiter_headers,
        json={"job_id": job_id, "resume_id": resume_id},
    )

    assert foreign.status_code == 404
    assert recruiter.status_code == 403
