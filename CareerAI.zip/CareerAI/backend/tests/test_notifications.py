import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import app


@pytest.fixture
def client() -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)

    def override_get_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def register_and_login(client: TestClient, *, email: str, role: str) -> str:
    payload = {"email": email, "password": "password123", "full_name": "Notification User", "role": role}
    assert client.post("/api/auth/register", json=payload).status_code == 201
    return client.post("/api/auth/login", data={"username": email, "password": "password123"}).json()["access_token"]


def create_job(client: TestClient, token: str) -> str:
    headers = {"Authorization": f"Bearer {token}"}
    assert client.post("/api/companies", headers=headers, json={"name": "Notify Labs"}).status_code == 201
    response = client.post(
        "/api/jobs",
        headers=headers,
        json={
            "title": "Notification Intern",
            "description": "Build reliable services and learn backend engineering.",
            "work_mode": "REMOTE",
            "job_type": "INTERNSHIP",
            "required_skills": ["Python"],
        },
    )
    assert response.status_code == 201
    return response.json()["id"]


def test_application_events_create_and_manage_notifications(client: TestClient) -> None:
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    student_token = register_and_login(client, email="student@example.com", role="STUDENT")
    job_id = create_job(client, recruiter_token)
    student_headers = {"Authorization": f"Bearer {student_token}"}

    application = client.post(f"/api/jobs/{job_id}/apply", headers=student_headers, json={})
    notifications = client.get("/api/notifications", headers=student_headers)
    unread = client.get("/api/notifications?unread_only=true", headers=student_headers)
    notification_id = notifications.json()[0]["id"]
    marked = client.patch(f"/api/notifications/{notification_id}/read", headers=student_headers)
    read_all = client.post("/api/notifications/read-all", headers=student_headers)
    unread_after = client.get("/api/notifications?unread_only=true", headers=student_headers)

    assert application.status_code == 201
    assert notifications.status_code == 200
    assert notifications.json()[0]["title"] == "Application submitted"
    assert len(unread.json()) == 1
    assert marked.status_code == 200
    assert marked.json()["is_read"] is True
    assert read_all.status_code == 200
    assert unread_after.json() == []


def test_status_change_notifies_student_and_notifications_are_private(client: TestClient) -> None:
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    student_token = register_and_login(client, email="student@example.com", role="STUDENT")
    other_student_token = register_and_login(client, email="other@example.com", role="STUDENT")
    job_id = create_job(client, recruiter_token)
    application = client.post(
        f"/api/jobs/{job_id}/apply",
        headers={"Authorization": f"Bearer {student_token}"},
        json={},
    )
    application_id = application.json()["id"]

    status_change = client.patch(
        f"/api/applications/{application_id}/status",
        headers={"Authorization": f"Bearer {recruiter_token}"},
        json={"status": "SHORTLISTED"},
    )
    notifications = client.get("/api/notifications", headers={"Authorization": f"Bearer {student_token}"})
    foreign = client.patch(
        f"/api/notifications/{notifications.json()[0]['id']}/read",
        headers={"Authorization": f"Bearer {other_student_token}"},
    )

    assert status_change.status_code == 200
    assert len(notifications.json()) == 2
    assert "Application status updated" in {item["title"] for item in notifications.json()}
    assert foreign.status_code == 404
