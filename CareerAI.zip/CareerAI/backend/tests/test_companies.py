import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import app


@pytest.fixture
def client() -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)

    def override_get_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def register_and_login(client: TestClient, *, email: str, role: str) -> str:
    payload = {
        "email": email,
        "password": "password123",
        "full_name": "Company User",
        "role": role,
    }
    assert client.post("/api/auth/register", json=payload).status_code == 201
    return client.post(
        "/api/auth/login",
        data={"username": email, "password": "password123"},
    ).json()["access_token"]


def test_recruiter_can_create_read_and_update_owned_company(client: TestClient) -> None:
    token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    headers = {"Authorization": f"Bearer {token}"}

    created = client.post(
        "/api/companies",
        headers=headers,
        json={
            "name": "Northstar Labs",
            "description": "Tools for better work.",
            "website_url": "https://northstar.example.com",
            "location": "Remote",
        },
    )
    assert created.status_code == 201
    company_id = created.json()["id"]

    owned = client.get("/api/companies/me", headers=headers)
    public = client.get(f"/api/companies/{company_id}")
    updated = client.put("/api/companies/me", headers=headers, json={"location": "New York"})

    assert owned.status_code == 200
    assert owned.json()["id"] == company_id
    assert public.status_code == 200
    assert updated.status_code == 200
    assert updated.json()["location"] == "New York"


def test_recruiter_cannot_create_two_companies_and_student_cannot_manage_one(client: TestClient) -> None:
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    student_token = register_and_login(client, email="student@example.com", role="STUDENT")
    recruiter_headers = {"Authorization": f"Bearer {recruiter_token}"}

    payload = {"name": "One Company", "location": "Remote"}
    assert client.post("/api/companies", headers=recruiter_headers, json=payload).status_code == 201
    duplicate = client.post("/api/companies", headers=recruiter_headers, json={"name": "Second Company"})
    student_create = client.post(
        "/api/companies",
        headers={"Authorization": f"Bearer {student_token}"},
        json=payload,
    )

    assert duplicate.status_code == 409
    assert student_create.status_code == 403
