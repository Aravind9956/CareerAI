import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from app.core.config import Settings
from app.main import app


def test_production_rejects_development_jwt_secret() -> None:
    with pytest.raises(ValidationError):
        Settings(app_env="production", jwt_secret_key="short")


def test_health_response_contains_security_headers() -> None:
    response = TestClient(app).get("/api/health")

    assert response.status_code == 200
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-Frame-Options"] == "DENY"
    assert response.headers["Referrer-Policy"] == "strict-origin-when-cross-origin"
    assert response.headers["Permissions-Policy"] == "camera=(), microphone=(), geolocation=()"


def test_trusted_host_rejects_unconfigured_host() -> None:
    response = TestClient(app).get("/api/health", headers={"host": "malicious.example"})

    assert response.status_code == 400


def test_cors_allows_configured_frontend_origin() -> None:
    response = TestClient(app).options(
        "/api/health",
        headers={
            "Origin": "http://localhost:5173",
            "Access-Control-Request-Method": "GET",
        },
    )

    assert response.status_code == 200
    assert response.headers["access-control-allow-origin"] == "http://localhost:5173"


def test_invalid_bearer_token_is_rejected() -> None:
    response = TestClient(app).get("/api/users/me", headers={"Authorization": "Bearer invalid-token"})

    assert response.status_code == 401
    assert response.headers["WWW-Authenticate"] == "Bearer"
