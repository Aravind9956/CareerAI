import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import app


@pytest.fixture
def client() -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)

    def override_get_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def register_and_login(client: TestClient, *, email: str, role: str) -> str:
    payload = {"email": email, "password": "password123", "full_name": "Interview User", "role": role}
    assert client.post("/api/auth/register", json=payload).status_code == 201
    return client.post("/api/auth/login", data={"username": email, "password": "password123"}).json()["access_token"]


def create_job(client: TestClient, recruiter_token: str) -> str:
    headers = {"Authorization": f"Bearer {recruiter_token}"}
    assert client.post("/api/companies", headers=headers, json={"name": "Interview Labs"}).status_code == 201
    response = client.post(
        "/api/jobs",
        headers=headers,
        json={
            "title": "Java Backend Developer Intern",
            "description": "Build reliable backend services and explain technical decisions.",
            "work_mode": "REMOTE",
            "job_type": "INTERNSHIP",
            "required_skills": ["Java", "REST APIs", "PostgreSQL"],
        },
    )
    assert response.status_code == 201
    return response.json()["id"]


def test_student_can_generate_interview_prep_and_feedback(client: TestClient) -> None:
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    student_token = register_and_login(client, email="student@example.com", role="STUDENT")
    job_id = create_job(client, recruiter_token)
    headers = {"Authorization": f"Bearer {student_token}"}

    first = client.post("/api/ai/interview", headers=headers, json={"job_id": job_id})
    second = client.post("/api/ai/interview", headers=headers, json={"job_id": job_id})
    feedback = client.post(
        "/api/ai/interview/feedback",
        headers=headers,
        json={
            "question": "What is dependency injection?",
            "answer": "Dependency injection provides dependencies from outside a class, which improves testing and keeps construction separate from behavior.",
            "category": "technical",
        },
    )

    content = first.json()["content"]
    assert first.status_code == 201
    assert content["technical_questions"]
    assert content["project_questions"]
    assert content["hr_questions"]
    assert content["behavioral_questions"]
    assert content["role_specific_questions"]
    assert second.json()["id"] == first.json()["id"]
    assert feedback.status_code == 200
    assert 0 <= feedback.json()["technical_accuracy"] <= 100
    assert feedback.json()["is_coaching"] is True


def test_interview_prep_is_student_only(client: TestClient) -> None:
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    job_id = create_job(client, recruiter_token)

    response = client.post("/api/ai/interview", headers={"Authorization": f"Bearer {recruiter_token}"}, json={"job_id": job_id})

    assert response.status_code == 403
