import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from app.core.security import hash_password
from app.db.base import Base
from app.db.session import get_db
from app.main import app
from app.models import User, UserRole


@pytest.fixture
def client() -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    with Session(engine) as session:
        session.add(
            User(
                email="admin@example.com",
                password_hash=hash_password("password123"),
                full_name="Platform Admin",
                role=UserRole.ADMIN,
            )
        )
        session.commit()

    def override_get_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def register_and_login(client: TestClient, *, email: str, role: str) -> str:
    payload = {
        "email": email,
        "password": "password123",
        "full_name": "Dashboard User",
        "role": role,
    }
    assert client.post("/api/auth/register", json=payload).status_code == 201
    return client.post(
        "/api/auth/login",
        data={"username": email, "password": "password123"},
    ).json()["access_token"]


def test_student_dashboard_returns_real_empty_state_and_is_role_scoped(client: TestClient) -> None:
    token = register_and_login(client, email="student@example.com", role="STUDENT")
    headers = {"Authorization": f"Bearer {token}"}

    dashboard = client.get("/api/dashboards/student", headers=headers)
    recruiter_dashboard = client.get("/api/dashboards/recruiter", headers=headers)

    assert dashboard.status_code == 200
    assert dashboard.json()["profile_completion"] == 0
    assert dashboard.json()["applications_total"] == 0
    assert dashboard.json()["recommended_jobs"] == []
    assert recruiter_dashboard.status_code == 403


def test_recruiter_dashboard_counts_owned_jobs(client: TestClient) -> None:
    token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    headers = {"Authorization": f"Bearer {token}"}
    assert client.post("/api/companies", headers=headers, json={"name": "Dashboard Labs"}).status_code == 201
    assert client.post(
        "/api/jobs",
        headers=headers,
        json={
            "title": "Dashboard Intern",
            "description": "Build reliable APIs with the platform team and ship services.",
            "work_mode": "REMOTE",
            "job_type": "INTERNSHIP",
            "required_skills": ["Python"],
        },
    ).status_code == 201

    dashboard = client.get("/api/dashboards/recruiter", headers=headers)

    assert dashboard.status_code == 200
    assert dashboard.json()["company_name"] == "Dashboard Labs"
    assert dashboard.json()["active_jobs"] == 1
    assert dashboard.json()["total_applications"] == 0


def test_admin_dashboard_counts_platform_data(client: TestClient) -> None:
    token = client.post(
        "/api/auth/login",
        data={"username": "admin@example.com", "password": "password123"},
    ).json()["access_token"]

    dashboard = client.get("/api/dashboards/admin", headers={"Authorization": f"Bearer {token}"})

    assert dashboard.status_code == 200
    assert dashboard.json()["total_users"] == 1
    assert dashboard.json()["students"] == 0
    assert dashboard.json()["recruiters"] == 0
