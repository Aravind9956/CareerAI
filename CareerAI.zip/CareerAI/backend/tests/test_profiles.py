import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import app


@pytest.fixture
def client() -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)

    def override_get_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def register_and_login(client: TestClient, *, email: str, role: str) -> str:
    payload = {
        "email": email,
        "password": "password123",
        "full_name": "Profile User",
        "role": role,
    }
    assert client.post("/api/auth/register", json=payload).status_code == 201
    return client.post(
        "/api/auth/login",
        data={"username": email, "password": "password123"},
    ).json()["access_token"]


def test_student_profile_updates_and_reports_completion(client: TestClient) -> None:
    token = register_and_login(client, email="student@example.com", role="STUDENT")
    headers = {"Authorization": f"Bearer {token}"}

    initial = client.get("/api/students/profile", headers=headers)
    assert initial.status_code == 200
    assert initial.json()["profile_completion"] == 0
    assert "Upload a resume" in initial.json()["missing"]

    updated = client.put(
        "/api/students/profile",
        headers=headers,
        json={
            "full_name": "Alex Student",
            "phone": "555-0100",
            "location": "New York",
            "degree": "Computer Science",
            "college": "CareerAI University",
            "graduation_year": 2027,
            "github_url": "https://github.com/alex",
            "linkedin_url": "https://linkedin.com/in/alex",
            "portfolio_url": "https://alex.example.com",
        },
    )
    assert updated.status_code == 200
    assert updated.json()["full_name"] == "Alex Student"
    assert updated.json()["profile_completion"] == 89
    assert updated.json()["missing"] == ["Upload a resume"]


def test_recruiter_profile_is_role_scoped(client: TestClient) -> None:
    recruiter_token = register_and_login(client, email="recruiter@example.com", role="RECRUITER")
    student_token = register_and_login(client, email="student@example.com", role="STUDENT")

    recruiter_response = client.put(
        "/api/recruiters/profile",
        headers={"Authorization": f"Bearer {recruiter_token}"},
        json={"full_name": "Recruiter Lead", "phone": "555-0200"},
    )
    student_response = client.get(
        "/api/recruiters/profile",
        headers={"Authorization": f"Bearer {student_token}"},
    )

    assert recruiter_response.status_code == 200
    assert recruiter_response.json()["full_name"] == "Recruiter Lead"
    assert student_response.status_code == 403
