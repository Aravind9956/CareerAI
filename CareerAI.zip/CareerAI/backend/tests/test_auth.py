import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from app.db.base import Base
from app.db.session import get_db
from app.main import app


@pytest.fixture
def client() -> TestClient:
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)

    def override_get_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def test_student_can_register_login_and_read_profile(client: TestClient) -> None:
    registration = client.post(
        "/api/auth/register",
        json={
            "email": "Student@Example.com",
            "password": "password123",
            "full_name": "Student Example",
            "role": "STUDENT",
        },
    )
    assert registration.status_code == 201
    assert registration.json()["email"] == "student@example.com"
    assert "password_hash" not in registration.json()

    login = client.post(
        "/api/auth/login",
        data={"username": "student@example.com", "password": "password123"},
    )
    assert login.status_code == 200
    token = login.json()["access_token"]
    assert login.json()["token_type"] == "bearer"

    profile = client.get("/api/users/me", headers={"Authorization": f"Bearer {token}"})
    assert profile.status_code == 200
    assert profile.json()["full_name"] == "Student Example"


def test_auth_rejects_duplicates_admin_registration_and_bad_password(client: TestClient) -> None:
    payload = {
        "email": "recruiter@example.com",
        "password": "password123",
        "full_name": "Recruiter Example",
        "role": "RECRUITER",
    }
    assert client.post("/api/auth/register", json=payload).status_code == 201
    assert client.post("/api/auth/register", json=payload).status_code == 409
    assert client.post("/api/auth/register", json={**payload, "email": "admin@example.com", "role": "ADMIN"}).status_code == 403
    assert client.post(
        "/api/auth/login",
        data={"username": payload["email"], "password": "wrong-password"},
    ).status_code == 401


def test_protected_route_requires_token(client: TestClient) -> None:
    response = client.get("/api/users/me")

    assert response.status_code == 401
    assert response.json()["detail"] == "Not authenticated"


def test_role_guard_rejects_non_admin_users(client: TestClient) -> None:
    registration = client.post(
        "/api/auth/register",
        json={
            "email": "student@example.com",
            "password": "password123",
            "full_name": "Student Example",
            "role": "STUDENT",
        },
    )
    token = client.post(
        "/api/auth/login",
        data={"username": "student@example.com", "password": "password123"},
    ).json()["access_token"]

    assert registration.status_code == 201
    response = client.get("/api/admin/access-check", headers={"Authorization": f"Bearer {token}"})

    assert response.status_code == 403
    assert response.json()["detail"] == "Insufficient permissions"
