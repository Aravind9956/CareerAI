from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import Session

from app.db.base import Base
from app.models import Company, Job, JobType, User, UserRole, WorkMode


def test_initial_schema_creates_expected_tables() -> None:
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)

    assert {
        "users",
        "student_profiles",
        "recruiter_profiles",
        "companies",
        "resumes",
        "jobs",
        "applications",
        "saved_jobs",
        "notifications",
    }.issubset(inspect(engine).get_table_names())


def test_job_relationships_persist_with_sqlite() -> None:
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)

    with Session(engine) as session:
        recruiter = User(
            email="recruiter@example.com",
            password_hash="not-a-real-password-hash",
            full_name="Recruiter",
            role=UserRole.RECRUITER,
        )
        company = Company(name="CareerAI Labs")
        job = Job(
            company=company,
            title="Backend Intern",
            description="Build APIs with the platform team.",
            work_mode=WorkMode.REMOTE,
            job_type=JobType.INTERNSHIP,
            required_skills="Python, FastAPI",
        )
        session.add_all([recruiter, job])
        session.commit()

        saved_job = session.get(Job, job.id)
        assert saved_job is not None
        assert saved_job.company.name == "CareerAI Labs"
