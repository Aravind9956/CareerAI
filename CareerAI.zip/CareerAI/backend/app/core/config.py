from functools import lru_cache

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_env: str = "development"
    backend_port: int = 8000
    database_url: str = "postgresql+psycopg://careerai:careerai@localhost:5432/careerai"
    database_echo: bool = False
    redis_url: str = "redis://localhost:6379/0"

    jwt_secret_key: str = "development-only-change-me"
    jwt_access_token_expire_minutes: int = 30

    # AI
    ai_provider: str = "mock"
    ai_api_key: str | None = None

    # Featherless
    featherless_base_url: str = "https://api.featherless.ai/v1"
    featherless_model: str = "Qwen/Qwen2.5-7B-Instruct"
    featherless_embedding_model: str = "Qwen/Qwen3-Embedding-8B"

    # Resume
    resume_storage_dir: str = "data/resumes"
    max_resume_size_mb: int = 5

    # CORS / Security
    cors_origins: str = "http://localhost:5173"
    allowed_hosts: str = "localhost,127.0.0.1,testserver"

    model_config = SettingsConfigDict(
        env_file=(".env", "../.env"),
        extra="ignore",
    )

    @property
    def cors_origin_list(self) -> list[str]:
        return [
            origin.strip()
            for origin in self.cors_origins.split(",")
            if origin.strip()
        ]

    @property
    def allowed_host_list(self) -> list[str]:
        return [
            host.strip()
            for host in self.allowed_hosts.split(",")
            if host.strip()
        ]

    @model_validator(mode="after")
    def validate_runtime_security(self) -> "Settings":
        if self.max_resume_size_mb < 1:
            raise ValueError("max_resume_size_mb must be at least 1")

        if self.app_env.lower() == "production":
            if (
                self.jwt_secret_key == "development-only-change-me"
                or len(self.jwt_secret_key) < 32
            ):
                raise ValueError(
                    "Production requires a JWT secret of at least 32 characters"
                )

        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()