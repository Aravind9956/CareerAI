from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.api.dependencies import require_roles
from app.db.session import get_db
from app.models import User, UserRole
from app.schemas.saved_jobs import SavedJobResponse
from app.services.saved_jobs import list_saved_jobs, save_job, to_saved_job_response, unsave_job

router = APIRouter(tags=["saved jobs"])


@router.post("/api/jobs/{job_id}/save", response_model=SavedJobResponse, status_code=status.HTTP_201_CREATED)
def save(
    job_id: str,
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> SavedJobResponse:
    saved_job = save_job(db, current_user, job_id)
    return to_saved_job_response(saved_job, saved_job.job.title, saved_job.job.company.name)


@router.delete("/api/jobs/{job_id}/save", status_code=status.HTTP_204_NO_CONTENT)
def remove_saved_job(
    job_id: str,
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> None:
    unsave_job(db, current_user, job_id)


@router.get("/api/saved-jobs", response_model=list[SavedJobResponse])
def read_saved_jobs(
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> list[SavedJobResponse]:
    return [to_saved_job_response(saved_job, title, company) for saved_job, title, company in list_saved_jobs(db, current_user)]
