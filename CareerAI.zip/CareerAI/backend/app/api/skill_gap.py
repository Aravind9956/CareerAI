from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.api.dependencies import require_roles
from app.db.session import get_db
from app.models import User, UserRole
from app.schemas.skill_gap import SkillGapRequest, SkillGapResponse
from app.services.skill_gap import analyze_skill_gap

router = APIRouter(prefix="/api/ai", tags=["ai"])


@router.post("/skill-gap", response_model=SkillGapResponse, status_code=status.HTTP_200_OK)
def create_skill_gap_analysis(
    payload: SkillGapRequest,
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> SkillGapResponse:
    return analyze_skill_gap(db, current_user, payload)
