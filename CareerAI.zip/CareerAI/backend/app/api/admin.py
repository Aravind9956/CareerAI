from fastapi import APIRouter, Depends

from app.api.dependencies import require_roles
from app.models import User, UserRole

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.get("/access-check")
def admin_access_check(current_user: User = Depends(require_roles(UserRole.ADMIN))) -> dict[str, str]:
    return {"status": "ok", "role": current_user.role.value}
