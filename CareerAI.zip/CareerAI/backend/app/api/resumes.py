from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.api.dependencies import require_roles
from app.db.session import get_db
from app.models import User, UserRole
from app.schemas.resumes import ResumeResponse
from app.services.resumes import delete_resume, get_student_resume, list_student_resumes, to_resume_response, upload_resume

router = APIRouter(prefix="/api/resumes", tags=["resumes"])


@router.post("/upload", response_model=ResumeResponse, status_code=status.HTTP_201_CREATED)
async def upload(
    file: UploadFile = File(...),
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> ResumeResponse:
    content = await file.read()
    resume = upload_resume(
        db,
        current_user,
        file_name=file.filename or "resume.pdf",
        content_type=file.content_type,
        content=content,
    )
    return to_resume_response(resume)


@router.get("", response_model=list[ResumeResponse])
def read_resumes(
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> list[ResumeResponse]:
    return [to_resume_response(resume) for resume in list_student_resumes(db, current_user)]


@router.get("/{resume_id}", response_model=ResumeResponse)
def read_resume(
    resume_id: str,
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> ResumeResponse:
    return to_resume_response(get_student_resume(db, current_user, resume_id))


@router.get("/{resume_id}/download")
def download_resume(
    resume_id: str,
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> FileResponse:
    resume = get_student_resume(db, current_user, resume_id)
    if not Path(resume.file_path).is_file():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resume file not found")
    return FileResponse(resume.file_path, media_type="application/pdf", filename=resume.file_name)


@router.delete("/{resume_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_resume(
    resume_id: str,
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> None:
    delete_resume(db, current_user, resume_id)
