from datetime import datetime
from typing import Literal

from fastapi import APIRouter, Depends, Query, Response, status
from sqlalchemy.orm import Session

from app.api.dependencies import require_roles
from app.db.session import get_db
from app.models import JobType, User, UserRole, WorkMode
from app.schemas.jobs import JobCreate, JobListResponse, JobResponse, JobUpdate
from app.services.jobs import create_job, deactivate_job, get_job, list_jobs, to_job_response, update_job

router = APIRouter(prefix="/api/jobs", tags=["jobs"])


@router.get("", response_model=JobListResponse)
def browse_jobs(
    q: str | None = Query(default=None, max_length=100),
    location: str | None = Query(default=None, max_length=160),
    job_type: JobType | None = None,
    work_mode: WorkMode | None = None,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    sort_by: Literal["created_at", "deadline", "title"] = "created_at",
    sort_order: Literal["asc", "desc"] = "desc",
    db: Session = Depends(get_db),
) -> JobListResponse:
    rows, total = list_jobs(
        db,
        query_text=q,
        location=location,
        job_type=job_type.value if job_type else None,
        work_mode=work_mode.value if work_mode else None,
        page=page,
        page_size=page_size,
        sort_by=sort_by,
        sort_order=sort_order,
    )
    items = [to_job_response(job, company_name) for job, company_name in rows]
    return JobListResponse.from_items(items, page=page, page_size=page_size, total=total)


@router.post("", response_model=JobResponse, status_code=status.HTTP_201_CREATED)
def create_listing(
    payload: JobCreate,
    current_user: User = Depends(require_roles(UserRole.RECRUITER)),
    db: Session = Depends(get_db),
) -> JobResponse:
    job = create_job(db, current_user, payload)
    return to_job_response(job, job.company.name)


@router.get("/{job_id}", response_model=JobResponse)
def read_job(job_id: str, db: Session = Depends(get_db)) -> JobResponse:
    job, company_name = get_job(db, job_id)
    return to_job_response(job, company_name)


@router.put("/{job_id}", response_model=JobResponse)
def update_listing(
    job_id: str,
    payload: JobUpdate,
    current_user: User = Depends(require_roles(UserRole.RECRUITER)),
    db: Session = Depends(get_db),
) -> JobResponse:
    job = update_job(db, current_user, job_id, payload)
    return to_job_response(job, job.company.name)


@router.delete("/{job_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_listing(
    job_id: str,
    current_user: User = Depends(require_roles(UserRole.RECRUITER)),
    db: Session = Depends(get_db),
) -> Response:
    deactivate_job(db, current_user, job_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
