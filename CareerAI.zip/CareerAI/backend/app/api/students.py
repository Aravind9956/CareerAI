from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.dependencies import require_roles
from app.db.session import get_db
from app.models import User, UserRole
from app.schemas.profiles import StudentProfileResponse, StudentProfileUpdate
from app.services.profiles import build_student_profile_response, get_or_create_student_profile

router = APIRouter(prefix="/api/students", tags=["students"])


@router.get("/profile", response_model=StudentProfileResponse)
def read_student_profile(
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> StudentProfileResponse:
    response = build_student_profile_response(db, current_user)
    db.commit()
    return response


@router.put("/profile", response_model=StudentProfileResponse)
def update_student_profile(
    payload: StudentProfileUpdate,
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> StudentProfileResponse:
    profile = get_or_create_student_profile(db, current_user)
    values = payload.model_dump(exclude_unset=True)
    if "full_name" in values:
        current_user.full_name = values.pop("full_name")
    for field_name, value in values.items():
        setattr(profile, field_name, value)
    db.commit()
    return build_student_profile_response(db, current_user)
