from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.api.dependencies import require_roles
from app.db.session import get_db
from app.models import User, UserRole
from app.schemas.applications import ApplicationCreate, ApplicationResponse, ApplicationStatusUpdate
from app.services.applications import (
    apply_to_job,
    list_job_applications,
    list_student_applications,
    to_application_response,
    update_application_status,
)

router = APIRouter(tags=["applications"])


@router.post("/api/jobs/{job_id}/apply", response_model=ApplicationResponse, status_code=status.HTTP_201_CREATED)
def apply(
    job_id: str,
    payload: ApplicationCreate,
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> ApplicationResponse:
    application = apply_to_job(db, current_user, job_id, payload)
    return to_application_response(application, application.job.title, application.job.company.name)


@router.get("/api/applications/my", response_model=list[ApplicationResponse])
def read_my_applications(
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> list[ApplicationResponse]:
    return [to_application_response(application, title, company) for application, title, company in list_student_applications(db, current_user)]


@router.get("/api/recruiter/applications/{job_id}", response_model=list[ApplicationResponse])
def read_job_applications(
    job_id: str,
    current_user: User = Depends(require_roles(UserRole.RECRUITER)),
    db: Session = Depends(get_db),
) -> list[ApplicationResponse]:
    return [to_application_response(application, title, company) for application, title, company in list_job_applications(db, current_user, job_id)]


@router.patch("/api/applications/{application_id}/status", response_model=ApplicationResponse)
def change_application_status(
    application_id: str,
    payload: ApplicationStatusUpdate,
    current_user: User = Depends(require_roles(UserRole.RECRUITER)),
    db: Session = Depends(get_db),
) -> ApplicationResponse:
    application, title, company = update_application_status(db, current_user, application_id, payload)
    return to_application_response(application, title, company)
