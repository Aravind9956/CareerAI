from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.api.dependencies import require_roles
from app.db.session import get_db
from app.models import User, UserRole
from app.schemas.interview import (
    InterviewFeedbackRequest,
    InterviewFeedbackResponse,
    InterviewPreparationRequest,
    InterviewPreparationResponse,
)
from app.services.interview import generate_preparation, provide_feedback, to_preparation_response

router = APIRouter(prefix="/api/ai", tags=["ai"])


@router.post("/interview", response_model=InterviewPreparationResponse, status_code=status.HTTP_201_CREATED)
def create_interview_preparation(
    payload: InterviewPreparationRequest,
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> InterviewPreparationResponse:
    return to_preparation_response(generate_preparation(db, current_user, payload))


@router.post("/interview/feedback", response_model=InterviewFeedbackResponse)
def interview_feedback(
    payload: InterviewFeedbackRequest,
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
) -> InterviewFeedbackResponse:
    return provide_feedback(payload)
