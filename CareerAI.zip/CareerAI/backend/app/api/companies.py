from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.dependencies import require_roles
from app.db.session import get_db
from app.models import Company, User, UserRole
from app.schemas.companies import CompanyCreate, CompanyResponse, CompanyUpdate
from app.services.companies import create_company_for_recruiter, get_owned_company, update_owned_company

router = APIRouter(prefix="/api/companies", tags=["companies"])


@router.post("", response_model=CompanyResponse, status_code=status.HTTP_201_CREATED)
def create_company(
    payload: CompanyCreate,
    current_user: User = Depends(require_roles(UserRole.RECRUITER)),
    db: Session = Depends(get_db),
) -> Company:
    return create_company_for_recruiter(db, current_user, **payload.model_dump())


@router.get("/me", response_model=CompanyResponse)
def read_my_company(
    current_user: User = Depends(require_roles(UserRole.RECRUITER)),
    db: Session = Depends(get_db),
) -> Company:
    return get_owned_company(db, current_user)


@router.put("/me", response_model=CompanyResponse)
def update_my_company(
    payload: CompanyUpdate,
    current_user: User = Depends(require_roles(UserRole.RECRUITER)),
    db: Session = Depends(get_db),
) -> Company:
    return update_owned_company(db, current_user, payload.model_dump(exclude_unset=True))


@router.get("/{company_id}", response_model=CompanyResponse)
def read_company(company_id: str, db: Session = Depends(get_db)) -> Company:
    company = db.get(Company, company_id)
    if company is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Company not found")
    return company
