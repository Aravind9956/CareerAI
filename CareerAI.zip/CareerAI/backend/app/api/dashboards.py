from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.dependencies import require_roles
from app.db.session import get_db
from app.models import User, UserRole
from app.schemas.dashboards import AdminDashboardResponse, RecruiterDashboardResponse, StudentDashboardResponse
from app.services.dashboards import admin_dashboard, recruiter_dashboard, student_dashboard

router = APIRouter(prefix="/api/dashboards", tags=["dashboards"])


@router.get("/student", response_model=StudentDashboardResponse)
def read_student_dashboard(
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> StudentDashboardResponse:
    return student_dashboard(db, current_user)


@router.get("/recruiter", response_model=RecruiterDashboardResponse)
def read_recruiter_dashboard(
    current_user: User = Depends(require_roles(UserRole.RECRUITER)),
    db: Session = Depends(get_db),
) -> RecruiterDashboardResponse:
    return recruiter_dashboard(db, current_user)


@router.get("/admin", response_model=AdminDashboardResponse)
def read_admin_dashboard(
    current_user: User = Depends(require_roles(UserRole.ADMIN)),
    db: Session = Depends(get_db),
) -> AdminDashboardResponse:
    return admin_dashboard(db)
