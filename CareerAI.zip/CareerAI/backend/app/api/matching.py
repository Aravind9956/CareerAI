from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.api.dependencies import require_roles
from app.db.session import get_db
from app.models import User, UserRole
from app.schemas.matching import JobMatchRequest, JobMatchResponse
from app.services.matching import list_matches, match_job, to_match_response

router = APIRouter(prefix="/api/ai", tags=["ai"])


@router.post("/job-match", response_model=JobMatchResponse, status_code=status.HTTP_201_CREATED)
def create_job_match(
    payload: JobMatchRequest,
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> JobMatchResponse:
    return to_match_response(match_job(db, current_user, payload))


@router.get("/job-matches", response_model=list[JobMatchResponse])
def read_job_matches(
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> list[JobMatchResponse]:
    return [to_match_response(result) for result in list_matches(db, current_user)]
