from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session

from app.api.dependencies import require_roles
from app.core.config import get_settings
from app.db.session import get_db
from app.models import User, UserRole
from app.schemas.ai import ResumeAnalysisRequest, ResumeAnalysisResponse
from app.services.ai import analyze_resume, list_resume_analyses, to_analysis_response

router = APIRouter(prefix="/api/ai", tags=["ai"])


@router.post("/resume-analysis", response_model=ResumeAnalysisResponse, status_code=status.HTTP_201_CREATED)
def create_resume_analysis(
    payload: ResumeAnalysisRequest,
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> ResumeAnalysisResponse:
    return to_analysis_response(analyze_resume(db, current_user, payload))


@router.get("/resume-analyses", response_model=list[ResumeAnalysisResponse])
def read_resume_analyses(
    resume_id: str | None = Query(default=None, max_length=36),
    current_user: User = Depends(require_roles(UserRole.STUDENT)),
    db: Session = Depends(get_db),
) -> list[ResumeAnalysisResponse]:
    return [to_analysis_response(analysis) for analysis in list_resume_analyses(db, current_user, resume_id)]
