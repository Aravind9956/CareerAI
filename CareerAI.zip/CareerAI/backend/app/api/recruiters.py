from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.dependencies import require_roles
from app.db.session import get_db
from app.models import User, UserRole
from app.schemas.profiles import RecruiterProfileResponse, RecruiterProfileUpdate
from app.services.profiles import get_or_create_recruiter_profile

router = APIRouter(prefix="/api/recruiters", tags=["recruiters"])


@router.get("/profile", response_model=RecruiterProfileResponse)
def read_recruiter_profile(
    current_user: User = Depends(require_roles(UserRole.RECRUITER)),
    db: Session = Depends(get_db),
) -> RecruiterProfileResponse:
    profile = get_or_create_recruiter_profile(db, current_user)
    db.commit()
    return RecruiterProfileResponse(
        user_id=current_user.id,
        full_name=current_user.full_name,
        email=current_user.email,
        phone=profile.phone,
        company_id=profile.company_id,
    )


@router.put("/profile", response_model=RecruiterProfileResponse)
def update_recruiter_profile(
    payload: RecruiterProfileUpdate,
    current_user: User = Depends(require_roles(UserRole.RECRUITER)),
    db: Session = Depends(get_db),
) -> RecruiterProfileResponse:
    profile = get_or_create_recruiter_profile(db, current_user)
    values = payload.model_dump(exclude_unset=True)
    if "full_name" in values:
        current_user.full_name = values.pop("full_name")
    for field_name, value in values.items():
        setattr(profile, field_name, value)
    db.commit()
    return RecruiterProfileResponse(
        user_id=current_user.id,
        full_name=current_user.full_name,
        email=current_user.email,
        phone=profile.phone,
        company_id=profile.company_id,
    )
