from __future__ import annotations

import hashlib
import math
import re
from typing import Protocol

from openai import OpenAI

from app.core.config import get_settings


EMBEDDING_DIMENSIONS = 4096


class EmbeddingProvider(Protocol):
    name: str

    def embed(self, text: str) -> list[float]:
        ...


class MockEmbeddingProvider:
    name = "mock"

    def embed(self, text: str) -> list[float]:
        vector = [0.0] * EMBEDDING_DIMENSIONS

        tokens = re.findall(r"[a-z0-9+#.-]+", text.casefold())

        for token in tokens:
            digest = hashlib.sha256(token.encode("utf-8")).digest()
            index = int.from_bytes(digest[:4], "big") % EMBEDDING_DIMENSIONS
            sign = 1.0 if digest[4] % 2 else -1.0
            vector[index] += sign

        magnitude = math.sqrt(sum(value * value for value in vector))

        return (
            [value / magnitude for value in vector]
            if magnitude
            else vector
        )


class FeatherlessEmbeddingProvider:
    name = "featherless"

    def __init__(self):
        settings = get_settings()

        if not settings.ai_api_key:
            raise ValueError("AI_API_KEY is not configured")

        self.client = OpenAI(
            api_key=settings.ai_api_key,
            base_url=settings.featherless_base_url,
        )

        self.model = settings.featherless_embedding_model

    def embed(self, text: str) -> list[float]:
        response = self.client.embeddings.create(
            model=self.model,
            input=text,
        )

        embedding = response.data[0].embedding

        if len(embedding) != EMBEDDING_DIMENSIONS:
            raise ValueError(
                f"Unexpected embedding dimension: "
                f"{len(embedding)}; expected {EMBEDDING_DIMENSIONS}"
            )

        return embedding


def cosine_similarity(
    left: list[float],
    right: list[float],
) -> float:
    if len(left) != len(right):
        raise ValueError(
            f"Embedding dimensions do not match: "
            f"{len(left)} != {len(right)}"
        )

    return max(
        -1.0,
        min(
            1.0,
            sum(a * b for a, b in zip(left, right, strict=True)),
        ),
    )


def get_embedding_provider(
    provider_name: str,
) -> EmbeddingProvider:

    if provider_name == "mock":
        return MockEmbeddingProvider()

    if provider_name == "featherless":
        return FeatherlessEmbeddingProvider()

    raise ValueError(
        f"Unsupported embedding provider: {provider_name}"
    )