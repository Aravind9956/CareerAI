from app.schemas.interview import InterviewFeedbackResponse, InterviewPreparationContent


def generate_interview_content(job_title: str, required_skills: str, resume_text: str | None) -> InterviewPreparationContent:
    skills = [skill.strip() for skill in required_skills.split(",") if skill.strip()]
    technical = [f"What is {skill}, and how would you use it in a {job_title} role?" for skill in skills[:4]]
    if not technical:
        technical = [f"What technical fundamentals matter most for a {job_title} role?"]
    project = [
        "Walk through a project where you solved a difficult problem.",
        "How did you test and measure the result of that project?",
    ]
    if resume_text and "project" in resume_text.casefold():
        project[0] = "Choose one project from your resume and explain the architecture, tradeoffs, and outcome."
    return InterviewPreparationContent(
        technical_questions=technical,
        project_questions=project,
        hr_questions=["Why are you interested in this role?", "What kind of team helps you do your best work?"],
        behavioral_questions=["Tell me about a time you received difficult feedback.", "Describe a time you had to prioritize under a deadline."],
        role_specific_questions=[f"What would you focus on during your first 30 days as a {job_title}?", "How would you explain a technical decision to a non-technical teammate?"],
    )


def evaluate_answer(question: str, answer: str, category: str) -> InterviewFeedbackResponse:
    word_count = len(answer.split())
    has_specificity = any(marker in answer.casefold() for marker in ("because", "result", "example", "measured"))
    baseline = min(92, 45 + min(word_count, 35))
    return InterviewFeedbackResponse(
        relevance=min(100, baseline + (8 if category in {"technical", "role_specific"} else 4)),
        completeness=min(100, baseline + (8 if word_count >= 45 else 0)),
        technical_accuracy=min(100, baseline + (8 if category == "technical" and has_specificity else 0)),
        communication=min(100, baseline + (8 if 35 <= word_count <= 120 else 0)),
        feedback=[
            "Lead with the context, then explain your action and result.",
            "Add one concrete example or measurable outcome to make the answer easier to evaluate.",
        ],
    )
