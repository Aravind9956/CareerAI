from __future__ import annotations

import json
import re
from typing import Protocol

from openai import OpenAI

from app.core.config import get_settings
from app.schemas.ai import ResumeAnalysisResult, SkillAnalysis

KNOWN_SKILLS = (
    "Python", "Java", "JavaScript", "TypeScript", "React", "FastAPI", "Django",
    "SQL", "PostgreSQL", "Redis", "Docker", "AWS", "Git", "REST APIs", "GraphQL",
    "Figma", "Project Management", "Data Analysis", "Machine Learning",
)


class ResumeAnalysisProvider(Protocol):
    name: str

    def analyze(
        self,
        resume_text: str,
        target_job_description: str | None
    ) -> ResumeAnalysisResult:
        ...


class MockResumeAnalysisProvider:
    name = "mock"

    def analyze(
        self,
        resume_text: str,
        target_job_description: str | None
    ) -> ResumeAnalysisResult:

        detected = [
            skill
            for skill in KNOWN_SKILLS
            if re.search(
                rf"(?<!\w){re.escape(skill)}(?!\w)",
                resume_text,
                re.IGNORECASE
            )
        ]

        target_skills = []

        if target_job_description:
            target_skills = [
                skill
                for skill in KNOWN_SKILLS
                if re.search(
                    rf"(?<!\w){re.escape(skill)}(?!\w)",
                    target_job_description,
                    re.IGNORECASE
                )
            ]

        missing = [
            skill
            for skill in target_skills
            if skill.casefold()
            not in {item.casefold() for item in detected}
        ]

        strengths = [
            f"Demonstrates {skill} in the resume"
            for skill in detected[:4]
        ]

        weaknesses = (
            ["Add measurable outcomes to project and experience bullets"]
            if detected
            else ["Add specific technical skills to the resume"]
        )

        suggestions = [
            "Use concise, outcome-focused bullets",
            "Keep skill names consistent with the target role"
        ]

        ats_feedback = [
            "Resume text was successfully extracted"
        ]

        if "email" not in resume_text.casefold():
            ats_feedback.append(
                "Add a clearly labeled email address"
            )

        score = max(
            35,
            min(
                95,
                55 + len(detected) * 6 - len(missing) * 4
            )
        )

        return ResumeAnalysisResult(
            overall_score=score,
            skills=[
                SkillAnalysis(
                    name=skill,
                    strength="strong"
                )
                for skill in detected
            ],
            strengths=strengths,
            weaknesses=weaknesses,
            missing_skills=missing,
            improvement_suggestions=suggestions,
            ats_feedback=ats_feedback,
        )


class FeatherlessResumeAnalysisProvider:
    name = "featherless"

    def __init__(self):
        settings = get_settings()

        if not settings.ai_api_key:
            raise ValueError(
                "AI_API_KEY is not configured"
            )

        self.client = OpenAI(
            api_key=settings.ai_api_key,
            base_url=settings.featherless_base_url,
        )

        self.model = settings.featherless_model

    def analyze(
        self,
        resume_text: str,
        target_job_description: str | None
    ) -> ResumeAnalysisResult:

        job_description = (
            target_job_description
            if target_job_description
            else "No specific target job description was provided."
        )

        prompt = f"""
You are an expert ATS resume analyzer.

Analyze the resume against the target job description.

Return ONLY valid JSON.
Do not use Markdown.
Do not use ```json.
Do not include any explanation outside the JSON.

The JSON must follow exactly this structure:

{{
  "overall_score": 0,
  "skills": [
    {{
      "name": "Python",
      "strength": "strong"
    }}
  ],
  "strengths": [],
  "weaknesses": [],
  "missing_skills": [],
  "improvement_suggestions": [],
  "ats_feedback": []
}}

Rules:

1. overall_score must be an integer between 0 and 100.
2. Every skill strength must be exactly:
   "strong", "moderate", or "weak".
3. All list fields must contain strings.
4. Do not invent skills, experience, education, or achievements.
5. Only use information supported by the resume or target job.
6. Evaluate:
   - technical skills
   - job relevance
   - ATS keyword alignment
   - projects
   - achievements
   - resume clarity
   - missing requirements
7. missing_skills should contain skills required by the
   target job but not demonstrated in the resume.

TARGET JOB DESCRIPTION:
{job_description}

RESUME:
{resume_text}
"""

        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an expert resume analyzer. "
                        "Return only valid JSON."
                    ),
                },
                {
                    "role": "user",
                    "content": prompt,
                },
            ],
            max_tokens=1800,
            temperature=0.2,
        )

        if not response.choices:
            raise ValueError(
                "Featherless returned no choices"
            )

        content = response.choices[0].message.content

        if not content:
            raise ValueError(
                "Featherless returned an empty response"
            )

        parsed = self._parse_json(content)

        return ResumeAnalysisResult.model_validate(parsed)

    @staticmethod
    def _parse_json(content: str) -> dict:

        content = content.strip()

        # Remove Markdown code fences if the model adds them.
        content = re.sub(
            r"^```json\s*",
            "",
            content,
            flags=re.IGNORECASE
        )

        content = re.sub(
            r"^```\s*",
            "",
            content
        )

        content = re.sub(
            r"\s*```$",
            "",
            content
        )

        try:
            return json.loads(content)

        except json.JSONDecodeError:

            # Try to extract a JSON object from surrounding text.
            match = re.search(
                r"\{.*\}",
                content,
                re.DOTALL
            )

            if not match:
                raise ValueError(
                    "Featherless returned invalid JSON"
                )

            try:
                return json.loads(match.group(0))

            except json.JSONDecodeError as exc:
                raise ValueError(
                    "Featherless returned invalid JSON"
                ) from exc


def get_resume_analysis_provider(
    provider_name: str
) -> ResumeAnalysisProvider:

    if provider_name == "mock":
        return MockResumeAnalysisProvider()

    if provider_name == "featherless":
        return FeatherlessResumeAnalysisProvider()

    raise ValueError(
        f"Unsupported AI provider: {provider_name}"
    )