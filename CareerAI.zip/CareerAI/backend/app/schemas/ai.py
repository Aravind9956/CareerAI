from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class ResumeAnalysisRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    resume_id: str = Field(min_length=1, max_length=36)
    target_job_description: str | None = Field(default=None, max_length=12000)


class SkillAnalysis(BaseModel):
    name: str
    strength: Literal["strong", "moderate", "weak"]


class ResumeAnalysisResult(BaseModel):
    overall_score: int = Field(ge=0, le=100)
    skills: list[SkillAnalysis]
    strengths: list[str]
    weaknesses: list[str]
    missing_skills: list[str]
    improvement_suggestions: list[str]
    ats_feedback: list[str]


class ResumeAnalysisResponse(BaseModel):
    id: str
    resume_id: str
    provider: str
    target_job_description: str | None
    result: ResumeAnalysisResult
    created_at: datetime
