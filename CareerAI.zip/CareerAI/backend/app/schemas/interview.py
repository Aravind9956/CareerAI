from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class InterviewPreparationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    job_id: str = Field(min_length=1, max_length=36)


class InterviewPreparationContent(BaseModel):
    technical_questions: list[str]
    project_questions: list[str]
    hr_questions: list[str]
    behavioral_questions: list[str]
    role_specific_questions: list[str]


class InterviewPreparationResponse(BaseModel):
    id: str
    job_id: str
    provider: str
    content: InterviewPreparationContent
    created_at: datetime


class InterviewFeedbackRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    question: str = Field(min_length=5, max_length=1000)
    answer: str = Field(min_length=20, max_length=5000)
    category: Literal["technical", "project", "hr", "behavioral", "role_specific"] = "technical"


class InterviewFeedbackResponse(BaseModel):
    relevance: int = Field(ge=0, le=100)
    completeness: int = Field(ge=0, le=100)
    technical_accuracy: int = Field(ge=0, le=100)
    communication: int = Field(ge=0, le=100)
    feedback: list[str]
    is_coaching: bool = True
