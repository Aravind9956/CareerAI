from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.models import ApplicationStatus


class ApplicationCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    cover_letter: str | None = Field(default=None, max_length=5000)
    resume_id: str | None = Field(default=None, max_length=36)


class ApplicationStatusUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    status: ApplicationStatus


class ApplicationResponse(BaseModel):
    id: str
    job_id: str
    job_title: str
    company_name: str
    resume_id: str | None
    cover_letter: str | None
    status: ApplicationStatus
    created_at: datetime
