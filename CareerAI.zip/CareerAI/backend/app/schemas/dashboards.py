from pydantic import BaseModel

from app.schemas.jobs import JobResponse


class StudentDashboardResponse(BaseModel):
    profile_completion: int
    applications_total: int
    applications_by_status: dict[str, int]
    saved_jobs_count: int
    current_resume_present: bool
    recommended_jobs: list[JobResponse]


class RecruiterDashboardResponse(BaseModel):
    company_name: str
    active_jobs: int
    total_applications: int
    shortlisted_candidates: int
    interviews: int
    selected_candidates: int
    recent_jobs: list[JobResponse]


class AdminDashboardResponse(BaseModel):
    total_users: int
    students: int
    recruiters: int
    companies: int
    jobs: int
    active_listings: int
    applications: int
