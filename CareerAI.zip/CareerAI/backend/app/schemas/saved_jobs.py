from datetime import datetime

from pydantic import BaseModel


class SavedJobResponse(BaseModel):
    id: str
    job_id: str
    job_title: str
    company_name: str
    saved_at: datetime | None
