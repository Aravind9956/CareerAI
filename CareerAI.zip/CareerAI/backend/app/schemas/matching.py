from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class JobMatchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    job_id: str = Field(min_length=1, max_length=36)
    resume_id: str | None = Field(default=None, max_length=36)


class JobMatchResponse(BaseModel):
    id: str
    job_id: str
    resume_id: str
    provider: str
    score: float
    matched_skills: list[str]
    skill_gaps: list[str]
    explanation: str
    is_estimate: bool = True
    created_at: datetime
