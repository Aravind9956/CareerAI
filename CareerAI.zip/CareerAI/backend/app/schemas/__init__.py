from app.schemas.auth import RegisterRequest, TokenResponse, UserResponse
from app.schemas.ai import ResumeAnalysisRequest, ResumeAnalysisResponse, ResumeAnalysisResult, SkillAnalysis
from app.schemas.applications import ApplicationCreate, ApplicationResponse, ApplicationStatusUpdate
from app.schemas.companies import CompanyCreate, CompanyResponse, CompanyUpdate
from app.schemas.dashboards import AdminDashboardResponse, RecruiterDashboardResponse, StudentDashboardResponse
from app.schemas.jobs import JobCreate, JobListResponse, JobResponse, JobUpdate
from app.schemas.matching import JobMatchRequest, JobMatchResponse
from app.schemas.interview import (
	InterviewFeedbackRequest,
	InterviewFeedbackResponse,
	InterviewPreparationContent,
	InterviewPreparationRequest,
	InterviewPreparationResponse,
)
from app.schemas.saved_jobs import SavedJobResponse
from app.schemas.resumes import ResumeResponse
from app.schemas.skill_gap import SkillGapRequest, SkillGapResponse
from app.schemas.notifications import NotificationResponse
from app.schemas.profiles import (
	RecruiterProfileResponse,
	RecruiterProfileUpdate,
	StudentProfileResponse,
	StudentProfileUpdate,
)

__all__ = [
	"RegisterRequest",
	"TokenResponse",
	"UserResponse",
	"RecruiterProfileResponse",
	"RecruiterProfileUpdate",
	"StudentProfileResponse",
	"StudentProfileUpdate",
	"CompanyCreate",
	"CompanyResponse",
	"CompanyUpdate",
	"AdminDashboardResponse",
	"RecruiterDashboardResponse",
	"StudentDashboardResponse",
	"ApplicationCreate",
	"ApplicationResponse",
	"ApplicationStatusUpdate",
	"JobCreate",
	"JobListResponse",
	"JobResponse",
	"JobUpdate",
	"SavedJobResponse",
	"ResumeResponse",
	"ResumeAnalysisRequest",
	"ResumeAnalysisResponse",
	"ResumeAnalysisResult",
	"SkillAnalysis",
	"JobMatchRequest",
	"JobMatchResponse",
	"SkillGapRequest",
	"SkillGapResponse",
	"InterviewFeedbackRequest",
	"InterviewFeedbackResponse",
	"InterviewPreparationContent",
	"InterviewPreparationRequest",
	"InterviewPreparationResponse",
	"NotificationResponse",
]
