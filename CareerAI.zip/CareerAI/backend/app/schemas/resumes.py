from datetime import datetime

from pydantic import BaseModel


class ResumeResponse(BaseModel):
    id: str
    file_name: str
    is_current: bool
    extracted_text: str | None
    created_at: datetime
