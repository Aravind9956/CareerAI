from datetime import datetime
from math import ceil

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.models import JobType, WorkMode


def normalize_skills(value: list[str]) -> list[str]:
    normalized = []
    seen = set()
    for skill in value:
        clean_skill = skill.strip()
        key = clean_skill.casefold()
        if clean_skill and key not in seen:
            normalized.append(clean_skill)
            seen.add(key)
    return normalized


class JobCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str = Field(min_length=2, max_length=200)
    description: str = Field(min_length=20, max_length=10000)
    location: str | None = Field(default=None, max_length=160)
    work_mode: WorkMode
    job_type: JobType
    required_skills: list[str] = Field(default_factory=list, max_length=40)
    preferred_skills: list[str] = Field(default_factory=list, max_length=40)
    salary_range: str | None = Field(default=None, max_length=160)
    experience_requirement: str | None = Field(default=None, max_length=160)
    education_requirement: str | None = Field(default=None, max_length=200)
    application_deadline: datetime | None = None
    openings: int = Field(default=1, ge=1, le=10000)

    @field_validator("title", "description", "location", "salary_range", "experience_requirement", "education_requirement", mode="before")
    @classmethod
    def normalize_text(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return value.strip() or None

    @field_validator("required_skills", "preferred_skills")
    @classmethod
    def clean_skills(cls, value: list[str]) -> list[str]:
        return normalize_skills(value)


class JobUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str | None = Field(default=None, min_length=2, max_length=200)
    description: str | None = Field(default=None, min_length=20, max_length=10000)
    location: str | None = Field(default=None, max_length=160)
    work_mode: WorkMode | None = None
    job_type: JobType | None = None
    required_skills: list[str] | None = Field(default=None, max_length=40)
    preferred_skills: list[str] | None = Field(default=None, max_length=40)
    salary_range: str | None = Field(default=None, max_length=160)
    experience_requirement: str | None = Field(default=None, max_length=160)
    education_requirement: str | None = Field(default=None, max_length=200)
    application_deadline: datetime | None = None
    openings: int | None = Field(default=None, ge=1, le=10000)
    is_active: bool | None = None

    @field_validator("title", "description", "location", "salary_range", "experience_requirement", "education_requirement", mode="before")
    @classmethod
    def normalize_text(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return value.strip() or None

    @field_validator("required_skills", "preferred_skills")
    @classmethod
    def clean_skills(cls, value: list[str] | None) -> list[str] | None:
        return normalize_skills(value) if value is not None else None


class JobResponse(BaseModel):
    id: str
    company_id: str
    company_name: str
    title: str
    description: str
    location: str | None
    work_mode: WorkMode
    job_type: JobType
    required_skills: list[str]
    preferred_skills: list[str]
    salary_range: str | None
    experience_requirement: str | None
    education_requirement: str | None
    application_deadline: datetime | None
    openings: int
    is_active: bool
    created_at: datetime


class JobListResponse(BaseModel):
    items: list[JobResponse]
    page: int
    page_size: int
    total: int
    pages: int

    @classmethod
    def from_items(cls, items: list[JobResponse], *, page: int, page_size: int, total: int) -> "JobListResponse":
        return cls(items=items, page=page, page_size=page_size, total=total, pages=ceil(total / page_size) if total else 0)
