from pydantic import BaseModel, ConfigDict, Field


class SkillGapRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    job_id: str = Field(min_length=1, max_length=36)
    resume_id: str | None = Field(default=None, max_length=36)


class SkillGapResponse(BaseModel):
    job_id: str
    resume_id: str
    your_skills: list[str]
    skills_to_develop: list[str]
    learning_path: list[str]
    explanation: str
    is_guidance: bool = True
