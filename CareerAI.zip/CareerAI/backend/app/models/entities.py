from __future__ import annotations

import enum
import uuid
from datetime import datetime

from pgvector.sqlalchemy import Vector
from sqlalchemy import JSON, Boolean, DateTime, Enum, Float, ForeignKey, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


def new_id() -> str:
    return str(uuid.uuid4())


class UserRole(str, enum.Enum):
    STUDENT = "STUDENT"
    RECRUITER = "RECRUITER"
    ADMIN = "ADMIN"


class JobType(str, enum.Enum):
    INTERNSHIP = "INTERNSHIP"
    FULL_TIME = "FULL_TIME"
    PART_TIME = "PART_TIME"


class WorkMode(str, enum.Enum):
    REMOTE = "REMOTE"
    HYBRID = "HYBRID"
    ONSITE = "ONSITE"


class ApplicationStatus(str, enum.Enum):
    APPLIED = "APPLIED"
    SHORTLISTED = "SHORTLISTED"
    INTERVIEW = "INTERVIEW"
    SELECTED = "SELECTED"
    REJECTED = "REJECTED"


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class User(TimestampMixin, Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    full_name: Mapped[str] = mapped_column(String(160))
    role: Mapped[UserRole] = mapped_column(Enum(UserRole, native_enum=False), index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    student_profile: Mapped[StudentProfile | None] = relationship(back_populates="user", uselist=False)
    recruiter_profile: Mapped[RecruiterProfile | None] = relationship(back_populates="user", uselist=False)
    applications: Mapped[list[Application]] = relationship(back_populates="student")
    notifications: Mapped[list[Notification]] = relationship(back_populates="user")
    ai_resume_analyses: Mapped[list[AIResumeAnalysis]] = relationship(back_populates="student", cascade="all, delete-orphan")
    job_match_results: Mapped[list[JobMatchResult]] = relationship(back_populates="student", cascade="all, delete-orphan")
    interview_preparations: Mapped[list[InterviewPreparation]] = relationship(back_populates="student", cascade="all, delete-orphan")


class StudentProfile(TimestampMixin, Base):
    __tablename__ = "student_profiles"

    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    phone: Mapped[str | None] = mapped_column(String(40))
    location: Mapped[str | None] = mapped_column(String(160))
    degree: Mapped[str | None] = mapped_column(String(160))
    college: Mapped[str | None] = mapped_column(String(200))
    graduation_year: Mapped[int | None] = mapped_column(Integer)
    github_url: Mapped[str | None] = mapped_column(String(500))
    linkedin_url: Mapped[str | None] = mapped_column(String(500))
    portfolio_url: Mapped[str | None] = mapped_column(String(500))

    user: Mapped[User] = relationship(back_populates="student_profile")
    resumes: Mapped[list[Resume]] = relationship(back_populates="student", cascade="all, delete-orphan")


class RecruiterProfile(TimestampMixin, Base):
    __tablename__ = "recruiter_profiles"

    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    phone: Mapped[str | None] = mapped_column(String(40))
    company_id: Mapped[str | None] = mapped_column(ForeignKey("companies.id", ondelete="SET NULL"), index=True)

    user: Mapped[User] = relationship(back_populates="recruiter_profile")
    company: Mapped[Company | None] = relationship(back_populates="recruiters")


class Company(TimestampMixin, Base):
    __tablename__ = "companies"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String(200), index=True)
    description: Mapped[str | None] = mapped_column(Text)
    website_url: Mapped[str | None] = mapped_column(String(500))
    location: Mapped[str | None] = mapped_column(String(160))

    recruiters: Mapped[list[RecruiterProfile]] = relationship(back_populates="company")
    jobs: Mapped[list[Job]] = relationship(back_populates="company")


class Job(TimestampMixin, Base):
    __tablename__ = "jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    company_id: Mapped[str] = mapped_column(ForeignKey("companies.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(200), index=True)
    description: Mapped[str] = mapped_column(Text)
    location: Mapped[str | None] = mapped_column(String(160))
    work_mode: Mapped[WorkMode] = mapped_column(Enum(WorkMode, native_enum=False))
    job_type: Mapped[JobType] = mapped_column(Enum(JobType, native_enum=False), index=True)
    required_skills: Mapped[str] = mapped_column(Text, default="")
    preferred_skills: Mapped[str] = mapped_column(Text, default="")
    salary_range: Mapped[str | None] = mapped_column(String(160))
    experience_requirement: Mapped[str | None] = mapped_column(String(160))
    education_requirement: Mapped[str | None] = mapped_column(String(200))
    application_deadline: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    openings: Mapped[int] = mapped_column(Integer, default=1)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)

    company: Mapped[Company] = relationship(back_populates="jobs")
    applications: Mapped[list[Application]] = relationship(back_populates="job", cascade="all, delete-orphan")
    saved_by: Mapped[list[SavedJob]] = relationship(back_populates="job", cascade="all, delete-orphan")
    match_results: Mapped[list[JobMatchResult]] = relationship(back_populates="job", cascade="all, delete-orphan")
    interview_preparations: Mapped[list[InterviewPreparation]] = relationship(back_populates="job", cascade="all, delete-orphan")


class Resume(TimestampMixin, Base):
    __tablename__ = "resumes"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    student_id: Mapped[str] = mapped_column(ForeignKey("student_profiles.user_id", ondelete="CASCADE"), index=True)
    file_name: Mapped[str] = mapped_column(String(255))
    file_path: Mapped[str] = mapped_column(String(500))
    extracted_text: Mapped[str | None] = mapped_column(Text)
    is_current: Mapped[bool] = mapped_column(Boolean, default=True)

    student: Mapped[StudentProfile] = relationship(back_populates="resumes")
    applications: Mapped[list[Application]] = relationship(back_populates="resume")
    ai_analyses: Mapped[list[AIResumeAnalysis]] = relationship(back_populates="resume", cascade="all, delete-orphan")


class AIResumeAnalysis(TimestampMixin, Base):
    __tablename__ = "ai_resume_analyses"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    student_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    resume_id: Mapped[str] = mapped_column(ForeignKey("resumes.id", ondelete="CASCADE"), index=True)
    target_job_description: Mapped[str | None] = mapped_column(Text)
    provider: Mapped[str] = mapped_column(String(80))
    result: Mapped[dict] = mapped_column(JSON)

    student: Mapped[User] = relationship(back_populates="ai_resume_analyses")
    resume: Mapped[Resume] = relationship(back_populates="ai_analyses")


class JobMatchResult(TimestampMixin, Base):
    __tablename__ = "job_match_results"
    __table_args__ = (UniqueConstraint("student_id", "job_id", name="uq_job_match_student_job"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    student_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)
    resume_id: Mapped[str] = mapped_column(ForeignKey("resumes.id", ondelete="CASCADE"), index=True)
    provider: Mapped[str] = mapped_column(String(80))
    score: Mapped[float] = mapped_column(Float)
    matched_skills: Mapped[list] = mapped_column(JSON)
    skill_gaps: Mapped[list] = mapped_column(JSON)
    explanation: Mapped[str] = mapped_column(Text)
    embedding: Mapped[list[float]] = mapped_column(JSON().with_variant(Vector(128), "postgresql"))

    student: Mapped[User] = relationship(back_populates="job_match_results")
    job: Mapped[Job] = relationship(back_populates="match_results")


class InterviewPreparation(TimestampMixin, Base):
    __tablename__ = "interview_preparations"
    __table_args__ = (UniqueConstraint("student_id", "job_id", name="uq_interview_prep_student_job"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    student_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)
    provider: Mapped[str] = mapped_column(String(80))
    content: Mapped[dict] = mapped_column(JSON)

    student: Mapped[User] = relationship(back_populates="interview_preparations")
    job: Mapped[Job] = relationship(back_populates="interview_preparations")


class Application(TimestampMixin, Base):
    __tablename__ = "applications"
    __table_args__ = (UniqueConstraint("student_id", "job_id", name="uq_application_student_job"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    student_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)
    resume_id: Mapped[str | None] = mapped_column(ForeignKey("resumes.id", ondelete="SET NULL"))
    cover_letter: Mapped[str | None] = mapped_column(Text)
    status: Mapped[ApplicationStatus] = mapped_column(Enum(ApplicationStatus, native_enum=False), default=ApplicationStatus.APPLIED, index=True)

    student: Mapped[User] = relationship(back_populates="applications")
    job: Mapped[Job] = relationship(back_populates="applications")
    resume: Mapped[Resume | None] = relationship(back_populates="applications")


class SavedJob(Base):
    __tablename__ = "saved_jobs"
    __table_args__ = (UniqueConstraint("student_id", "job_id", name="uq_saved_job_student_job"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    student_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)

    job: Mapped[Job] = relationship(back_populates="saved_by")


class Notification(TimestampMixin, Base):
    __tablename__ = "notifications"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(200))
    message: Mapped[str] = mapped_column(Text)
    is_read: Mapped[bool] = mapped_column(Boolean, default=False, index=True)

    user: Mapped[User] = relationship(back_populates="notifications")