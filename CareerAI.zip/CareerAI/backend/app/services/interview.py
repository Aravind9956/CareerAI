from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai.interview import evaluate_answer, generate_interview_content
from app.core.config import get_settings
from app.models import InterviewPreparation, Job, Resume, User
from app.schemas.interview import (
    InterviewFeedbackRequest,
    InterviewFeedbackResponse,
    InterviewPreparationRequest,
    InterviewPreparationResponse,
)


def to_preparation_response(preparation: InterviewPreparation) -> InterviewPreparationResponse:
    return InterviewPreparationResponse(
        id=preparation.id,
        job_id=preparation.job_id,
        provider=preparation.provider,
        content=preparation.content,
        created_at=preparation.created_at,
    )


def generate_preparation(db: Session, student: User, payload: InterviewPreparationRequest) -> InterviewPreparation:
    job = db.scalar(select(Job).where(Job.id == payload.job_id, Job.is_active.is_(True)))
    if job is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    resume = db.scalar(select(Resume).where(Resume.student_id == student.id, Resume.is_current.is_(True)))
    content = generate_interview_content(job.title, job.required_skills, resume.extracted_text if resume else None)
    provider = get_settings().ai_provider
    existing = db.scalar(select(InterviewPreparation).where(InterviewPreparation.student_id == student.id, InterviewPreparation.job_id == job.id))
    if existing:
        existing.provider = provider
        existing.content = content.model_dump()
        preparation = existing
    else:
        preparation = InterviewPreparation(student_id=student.id, job_id=job.id, provider=provider, content=content.model_dump())
        db.add(preparation)
    db.commit()
    db.refresh(preparation)
    return preparation


def provide_feedback(payload: InterviewFeedbackRequest) -> InterviewFeedbackResponse:
    return evaluate_answer(payload.question, payload.answer, payload.category)
