from pathlib import Path
from uuid import uuid4

import fitz
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.models import Resume, User
from app.schemas.resumes import ResumeResponse
from app.services.profiles import get_or_create_student_profile


def to_resume_response(resume: Resume) -> ResumeResponse:
    return ResumeResponse(
        id=resume.id,
        file_name=resume.file_name,
        is_current=resume.is_current,
        extracted_text=resume.extracted_text,
        created_at=resume.created_at,
    )


def validate_and_extract_pdf(content: bytes, *, file_name: str, content_type: str | None) -> str:
    settings = get_settings()
    max_bytes = settings.max_resume_size_mb * 1024 * 1024
    if len(content) > max_bytes:
        raise HTTPException(status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, detail="Resume exceeds the size limit")
    if Path(file_name).suffix.lower() != ".pdf" or content_type not in {None, "", "application/pdf", "application/octet-stream"}:
        raise HTTPException(status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, detail="Only PDF resumes are supported")
    if not content.startswith(b"%PDF"):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Uploaded file is not a valid PDF")
    try:
        with fitz.open(stream=content, filetype="pdf") as document:
            text = "\n".join(page.get_text() for page in document).strip()
    except (fitz.FileDataError, ValueError) as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Uploaded file is not a readable PDF") from exc
    if not text:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="PDF does not contain extractable text")
    return text


def upload_resume(
    db: Session,
    student: User,
    *,
    file_name: str,
    content_type: str | None,
    content: bytes,
) -> Resume:
    text = validate_and_extract_pdf(content, file_name=file_name, content_type=content_type)
    profile = get_or_create_student_profile(db, student)
    settings = get_settings()
    resume_id = str(uuid4())
    safe_name = Path(file_name).name[:255]
    storage_dir = Path(settings.resume_storage_dir) / student.id
    storage_dir.mkdir(parents=True, exist_ok=True)
    stored_path = storage_dir / f"{resume_id}.pdf"
    stored_path.write_bytes(content)

    db.query(Resume).filter(Resume.student_id == student.id, Resume.is_current.is_(True)).update({Resume.is_current: False})
    resume = Resume(
        id=resume_id,
        student_id=profile.user_id,
        file_name=safe_name,
        file_path=str(stored_path),
        extracted_text=text,
        is_current=True,
    )
    db.add(resume)
    db.commit()
    db.refresh(resume)
    return resume


def get_student_resume(db: Session, student: User, resume_id: str) -> Resume:
    resume = db.scalar(select(Resume).where(Resume.id == resume_id, Resume.student_id == student.id))
    if resume is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resume not found")
    return resume


def list_student_resumes(db: Session, student: User) -> list[Resume]:
    return list(db.scalars(select(Resume).where(Resume.student_id == student.id).order_by(Resume.created_at.desc())).all())


def delete_resume(db: Session, student: User, resume_id: str) -> None:
    resume = get_student_resume(db, student, resume_id)
    Path(resume.file_path).unlink(missing_ok=True)
    db.delete(resume)
    db.commit()
