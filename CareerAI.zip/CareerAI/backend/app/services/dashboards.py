from collections.abc import Sequence

from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import Application, ApplicationStatus, Company, Job, RecruiterProfile, Resume, SavedJob, StudentProfile, User, UserRole
from app.schemas.dashboards import AdminDashboardResponse, RecruiterDashboardResponse, StudentDashboardResponse
from app.services.companies import get_owned_company
from app.services.jobs import to_job_response
from app.services.profiles import build_student_profile_response


def _job_rows_to_responses(rows: Sequence[tuple[Job, str]]) -> list:
    return [to_job_response(job, company_name) for job, company_name in rows]


def student_dashboard(db: Session, student: User) -> StudentDashboardResponse:
    profile = build_student_profile_response(db, student)
    applications_total = db.scalar(select(func.count()).select_from(Application).where(Application.student_id == student.id)) or 0
    saved_jobs_count = db.scalar(select(func.count()).select_from(SavedJob).where(SavedJob.student_id == student.id)) or 0
    status_rows = db.execute(
        select(Application.status, func.count()).where(Application.student_id == student.id).group_by(Application.status)
    ).all()
    applications_by_status = {status.value: 0 for status in ApplicationStatus}
    applications_by_status.update({application_status.value: count for application_status, count in status_rows})
    current_resume_present = bool(
        db.scalar(select(Resume.id).where(Resume.student_id == student.id, Resume.is_current.is_(True)).limit(1))
    )
    recommended_rows = db.execute(
        select(Job, Company.name)
        .join(Company, Company.id == Job.company_id)
        .where(Job.is_active.is_(True))
        .order_by(Job.created_at.desc())
        .limit(5)
    ).all()
    return StudentDashboardResponse(
        profile_completion=profile.profile_completion,
        applications_total=applications_total,
        applications_by_status=applications_by_status,
        saved_jobs_count=saved_jobs_count,
        current_resume_present=current_resume_present,
        recommended_jobs=_job_rows_to_responses(recommended_rows),
    )


def recruiter_dashboard(db: Session, recruiter: User) -> RecruiterDashboardResponse:
    company = get_owned_company(db, recruiter)
    active_jobs = db.scalar(select(func.count()).select_from(Job).where(Job.company_id == company.id, Job.is_active.is_(True))) or 0
    total_applications = db.scalar(
        select(func.count()).select_from(Application).join(Job, Job.id == Application.job_id).where(Job.company_id == company.id)
    ) or 0
    shortlisted = db.scalar(
        select(func.count()).select_from(Application).join(Job, Job.id == Application.job_id).where(
            Job.company_id == company.id, Application.status == ApplicationStatus.SHORTLISTED
        )
    ) or 0
    interviews = db.scalar(
        select(func.count()).select_from(Application).join(Job, Job.id == Application.job_id).where(
            Job.company_id == company.id, Application.status == ApplicationStatus.INTERVIEW
        )
    ) or 0
    selected = db.scalar(
        select(func.count()).select_from(Application).join(Job, Job.id == Application.job_id).where(
            Job.company_id == company.id, Application.status == ApplicationStatus.SELECTED
        )
    ) or 0
    recent_rows = db.execute(
        select(Job, Company.name)
        .join(Company, Company.id == Job.company_id)
        .where(Job.company_id == company.id)
        .order_by(Job.created_at.desc())
        .limit(5)
    ).all()
    return RecruiterDashboardResponse(
        company_name=company.name,
        active_jobs=active_jobs,
        total_applications=total_applications,
        shortlisted_candidates=shortlisted,
        interviews=interviews,
        selected_candidates=selected,
        recent_jobs=_job_rows_to_responses(recent_rows),
    )


def admin_dashboard(db: Session) -> AdminDashboardResponse:
    def count(model, *criteria) -> int:
        return db.scalar(select(func.count()).select_from(model).where(*criteria)) or 0

    return AdminDashboardResponse(
        total_users=count(User),
        students=count(User, User.role == UserRole.STUDENT),
        recruiters=count(User, User.role == UserRole.RECRUITER),
        companies=count(Company),
        jobs=count(Job),
        active_listings=count(Job, Job.is_active.is_(True)),
        applications=count(Application),
    )
