from collections.abc import Sequence

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Company, Job, SavedJob, User
from app.schemas.saved_jobs import SavedJobResponse


def to_saved_job_response(saved_job: SavedJob, job_title: str, company_name: str) -> SavedJobResponse:
    return SavedJobResponse(
        id=saved_job.id,
        job_id=saved_job.job_id,
        job_title=job_title,
        company_name=company_name,
        saved_at=None,
    )


def save_job(db: Session, student: User, job_id: str) -> SavedJob:
    job = db.scalar(select(Job).where(Job.id == job_id, Job.is_active.is_(True)))
    if job is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    existing = db.scalar(select(SavedJob).where(SavedJob.student_id == student.id, SavedJob.job_id == job_id))
    if existing is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Job is already saved")
    saved_job = SavedJob(student_id=student.id, job_id=job_id)
    db.add(saved_job)
    db.commit()
    db.refresh(saved_job)
    return saved_job


def unsave_job(db: Session, student: User, job_id: str) -> None:
    saved_job = db.scalar(select(SavedJob).where(SavedJob.student_id == student.id, SavedJob.job_id == job_id))
    if saved_job is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Saved job not found")
    db.delete(saved_job)
    db.commit()


def list_saved_jobs(db: Session, student: User) -> Sequence[tuple[SavedJob, str, str]]:
    query = (
        select(SavedJob, Job.title, Company.name)
        .join(Job, Job.id == SavedJob.job_id)
        .join(Company, Company.id == Job.company_id)
        .where(SavedJob.student_id == student.id)
        .order_by(Job.created_at.desc())
    )
    return db.execute(query).all()
