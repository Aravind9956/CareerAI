from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.models import Notification
from app.schemas.notifications import NotificationResponse


def create_notification(db: Session, *, user_id: str, title: str, message: str) -> Notification:
    notification = Notification(user_id=user_id, title=title, message=message)
    db.add(notification)
    return notification


def list_notifications(db: Session, user_id: str, *, unread_only: bool = False) -> list[Notification]:
    query = select(Notification).where(Notification.user_id == user_id).order_by(Notification.created_at.desc(), Notification.id.desc())
    if unread_only:
        query = query.where(Notification.is_read.is_(False))
    return list(db.scalars(query).all())


def mark_notification_read(db: Session, user_id: str, notification_id: str) -> Notification | None:
    notification = db.scalar(select(Notification).where(Notification.id == notification_id, Notification.user_id == user_id))
    if notification is None:
        return None
    notification.is_read = True
    db.commit()
    db.refresh(notification)
    return notification


def mark_all_notifications_read(db: Session, user_id: str) -> int:
    result = db.execute(
        update(Notification).where(Notification.user_id == user_id, Notification.is_read.is_(False)).values(is_read=True)
    )
    db.commit()
    return result.rowcount or 0
