from sqlalchemy.orm import Session

from app.models import RecruiterProfile, Resume, StudentProfile, User
from app.schemas.profiles import StudentProfileResponse


STUDENT_COMPLETION_FIELDS = (
    ("phone", "Add your phone number"),
    ("location", "Add your location"),
    ("degree", "Add your degree"),
    ("college", "Add your college"),
    ("graduation_year", "Add your graduation year"),
    ("github_url", "Add your GitHub profile"),
    ("linkedin_url", "Add your LinkedIn profile"),
    ("portfolio_url", "Add your portfolio"),
)


def get_or_create_student_profile(db: Session, user: User) -> StudentProfile:
    if user.student_profile is None:
        user.student_profile = StudentProfile(user_id=user.id)
        db.add(user.student_profile)
        db.flush()
    return user.student_profile


def get_or_create_recruiter_profile(db: Session, user: User) -> RecruiterProfile:
    if user.recruiter_profile is None:
        user.recruiter_profile = RecruiterProfile(user_id=user.id)
        db.add(user.recruiter_profile)
        db.flush()
    return user.recruiter_profile


def build_student_profile_response(db: Session, user: User) -> StudentProfileResponse:
    profile = get_or_create_student_profile(db, user)
    values = {field_name: getattr(profile, field_name) for field_name, _ in STUDENT_COMPLETION_FIELDS}
    values["resume"] = db.query(Resume).filter(Resume.student_id == user.id, Resume.is_current.is_(True)).first()
    completed = sum(value is not None for value in values.values())
    total = len(STUDENT_COMPLETION_FIELDS) + 1
    missing = [label for field_name, label in STUDENT_COMPLETION_FIELDS if not values[field_name]]
    if values["resume"] is None:
        missing.append("Upload a resume")
    return StudentProfileResponse(
        user_id=user.id,
        full_name=user.full_name,
        email=user.email,
        phone=profile.phone,
        location=profile.location,
        degree=profile.degree,
        college=profile.college,
        graduation_year=profile.graduation_year,
        github_url=profile.github_url,
        linkedin_url=profile.linkedin_url,
        portfolio_url=profile.portfolio_url,
        profile_completion=round(completed / total * 100),
        missing=missing,
    )
