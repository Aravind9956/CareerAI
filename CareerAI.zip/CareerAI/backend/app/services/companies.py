from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models import Company, User
from app.services.profiles import get_or_create_recruiter_profile


def create_company_for_recruiter(
    db: Session,
    recruiter: User,
    *,
    name: str,
    description: str | None,
    website_url: str | None,
    location: str | None,
) -> Company:
    profile = get_or_create_recruiter_profile(db, recruiter)
    if profile.company_id is not None and db.get(Company, profile.company_id) is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Recruiter already owns a company")

    company = Company(name=name, description=description, website_url=website_url, location=location)
    db.add(company)
    db.flush()
    profile.company_id = company.id
    db.commit()
    db.refresh(company)
    return company


def get_owned_company(db: Session, recruiter: User) -> Company:
    profile = get_or_create_recruiter_profile(db, recruiter)
    if profile.company_id is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Recruiter has no company profile")
    company = db.get(Company, profile.company_id)
    if company is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Company profile not found")
    return company


def update_owned_company(db: Session, recruiter: User, values: dict[str, str | None]) -> Company:
    company = get_owned_company(db, recruiter)
    for field_name, value in values.items():
        setattr(company, field_name, value)
    db.commit()
    db.refresh(company)
    return company
