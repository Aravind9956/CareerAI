from collections.abc import Sequence

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Application, ApplicationStatus, Company, Job, Resume, StudentProfile, User
from app.schemas.applications import ApplicationCreate, ApplicationResponse, ApplicationStatusUpdate
from app.services.jobs import get_owned_job
from app.services.notifications import create_notification


def to_application_response(application: Application, job_title: str, company_name: str) -> ApplicationResponse:
    return ApplicationResponse(
        id=application.id,
        job_id=application.job_id,
        job_title=job_title,
        company_name=company_name,
        resume_id=application.resume_id,
        cover_letter=application.cover_letter,
        status=application.status,
        created_at=application.created_at,
    )


def apply_to_job(db: Session, student: User, job_id: str, payload: ApplicationCreate) -> Application:
    job = db.scalar(select(Job).where(Job.id == job_id, Job.is_active.is_(True)))
    if job is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    existing = db.scalar(select(Application).where(Application.student_id == student.id, Application.job_id == job_id))
    if existing is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="You have already applied to this job")
    if payload.resume_id is not None:
        resume = db.scalar(
            select(Resume).join(StudentProfile, StudentProfile.user_id == Resume.student_id).where(
                Resume.id == payload.resume_id,
                StudentProfile.user_id == student.id,
            )
        )
        if resume is None:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Resume does not belong to the current student")
    application = Application(
        student_id=student.id,
        job_id=job_id,
        resume_id=payload.resume_id,
        cover_letter=payload.cover_letter,
        status=ApplicationStatus.APPLIED,
    )
    db.add(application)
    db.flush()
    create_notification(
        db,
        user_id=student.id,
        title="Application submitted",
        message=f"Your application for {job.title} was submitted successfully.",
    )
    db.commit()
    db.refresh(application)
    return application


def list_student_applications(db: Session, student: User) -> Sequence[tuple[Application, str, str]]:
    query = (
        select(Application, Job.title, Company.name)
        .join(Job, Job.id == Application.job_id)
        .join(Company, Company.id == Job.company_id)
        .where(Application.student_id == student.id)
        .order_by(Application.created_at.desc())
    )
    return db.execute(query).all()


def list_job_applications(db: Session, recruiter: User, job_id: str) -> Sequence[tuple[Application, str, str]]:
    job = get_owned_job(db, recruiter, job_id)
    query = (
        select(Application, Job.title, Company.name)
        .join(Job, Job.id == Application.job_id)
        .join(Company, Company.id == Job.company_id)
        .where(Application.job_id == job.id)
        .order_by(Application.created_at.desc())
    )
    return db.execute(query).all()


def update_application_status(
    db: Session,
    recruiter: User,
    application_id: str,
    payload: ApplicationStatusUpdate,
) -> tuple[Application, str, str]:
    query = (
        select(Application, Job.title, Company.name)
        .join(Job, Job.id == Application.job_id)
        .join(Company, Company.id == Job.company_id)
        .where(Application.id == application_id)
    )
    row = db.execute(query).first()
    if row is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Application not found")
    application, job_title, company_name = row
    get_owned_job(db, recruiter, application.job_id)
    previous_status = application.status
    application.status = payload.status
    if previous_status != payload.status:
        create_notification(
            db,
            user_id=application.student_id,
            title="Application status updated",
            message=f"Your application for {job_title} is now {payload.status.value}.",
        )
    db.commit()
    db.refresh(application)
    return application, job_title, company_name
