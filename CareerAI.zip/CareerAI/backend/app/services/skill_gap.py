import re

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai.providers import KNOWN_SKILLS
from app.models import Job, Resume, User
from app.schemas.skill_gap import SkillGapRequest, SkillGapResponse

LEARNING_PATHS = {
    "Docker": ["Docker fundamentals", "Dockerize a FastAPI application", "Run services with Docker Compose"],
    "AWS": ["AWS cloud fundamentals", "Deploy a small API to AWS", "Add logging and basic monitoring"],
    "Redis": ["Redis data structures", "Add caching to an API", "Design cache invalidation rules"],
    "PostgreSQL": ["PostgreSQL query fundamentals", "Model a relational feature", "Add indexes and inspect query plans"],
    "FastAPI": ["FastAPI routing and validation", "Build a typed REST endpoint", "Add authentication and tests"],
    "React": ["React component fundamentals", "Build a data-driven view", "Connect a view to an API"],
}


def _skills_from_text(text: str) -> list[str]:
    return [skill for skill in KNOWN_SKILLS if re.search(rf"(?<!\w){re.escape(skill)}(?!\w)", text, re.IGNORECASE)]


def _job_skills(job: Job) -> list[str]:
    skills = [skill.strip() for skill in f"{job.required_skills},{job.preferred_skills}".split(",") if skill.strip()]
    result = []
    seen = set()
    for skill in skills:
        if skill.casefold() not in seen:
            result.append(skill)
            seen.add(skill.casefold())
    return result


def analyze_skill_gap(db: Session, student: User, payload: SkillGapRequest) -> SkillGapResponse:
    job = db.scalar(select(Job).where(Job.id == payload.job_id, Job.is_active.is_(True)))
    if job is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    resume_query = select(Resume).where(Resume.student_id == student.id, Resume.is_current.is_(True))
    if payload.resume_id:
        resume_query = select(Resume).where(Resume.id == payload.resume_id, Resume.student_id == student.id)
    resume = db.scalar(resume_query)
    if resume is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resume not found")
    if not resume.extracted_text:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Resume has no extracted text")
    your_skills = _skills_from_text(resume.extracted_text)
    required_skills = _job_skills(job)
    your_skill_keys = {skill.casefold() for skill in your_skills}
    skills_to_develop = [skill for skill in required_skills if skill.casefold() not in your_skill_keys]
    learning_path = []
    for skill in skills_to_develop:
        learning_path.extend(LEARNING_PATHS.get(skill, [f"Learn {skill} fundamentals", f"Build a small project using {skill}"]))
    explanation = "Your resume skills were compared with this listing's required and preferred skills."
    return SkillGapResponse(
        job_id=job.id,
        resume_id=resume.id,
        your_skills=your_skills,
        skills_to_develop=skills_to_develop,
        learning_path=learning_path,
        explanation=explanation,
    )
