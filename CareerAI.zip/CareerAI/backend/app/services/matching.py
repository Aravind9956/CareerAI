import re

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai.embeddings import cosine_similarity, get_embedding_provider
from app.core.config import get_settings
from app.models import Job, JobMatchResult, Resume, User
from app.schemas.matching import JobMatchRequest, JobMatchResponse


def to_match_response(result: JobMatchResult) -> JobMatchResponse:
    return JobMatchResponse(
        id=result.id,
        job_id=result.job_id,
        resume_id=result.resume_id,
        provider=result.provider,
        score=result.score,
        matched_skills=result.matched_skills,
        skill_gaps=result.skill_gaps,
        explanation=result.explanation,
        created_at=result.created_at,
    )


def _job_skills(job: Job) -> list[str]:
    return [skill.strip() for skill in f"{job.required_skills},{job.preferred_skills}".split(",") if skill.strip()]


def match_job(db: Session, student: User, payload: JobMatchRequest) -> JobMatchResult:
    job = db.scalar(select(Job).where(Job.id == payload.job_id, Job.is_active.is_(True)))
    if job is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    resume_query = select(Resume).where(Resume.student_id == student.id, Resume.is_current.is_(True))
    if payload.resume_id:
        resume_query = select(Resume).where(Resume.id == payload.resume_id, Resume.student_id == student.id)
    resume = db.scalar(resume_query)
    if resume is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resume not found")
    if not resume.extracted_text:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Resume has no extracted text")
    settings = get_settings()
    try:
        provider = get_embedding_provider(settings.ai_provider)
        resume_embedding = provider.embed(resume.extracted_text)
        job_text = " ".join([job.title, job.description, job.required_skills, job.preferred_skills, job.education_requirement or ""])
        job_embedding = provider.embed(job_text)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Configured embedding provider is unavailable") from exc
    resume_text = resume.extracted_text.casefold()
    skills = _job_skills(job)
    matched = [skill for skill in skills if re.search(rf"(?<!\w){re.escape(skill)}(?!\w)", resume_text, re.IGNORECASE)]
    gaps = [skill for skill in skills if skill.casefold() not in {item.casefold() for item in matched}]
    semantic_score = max(0.0, cosine_similarity(resume_embedding, job_embedding))
    skill_score = len(matched) / len(skills) if skills else semantic_score
    score = round((semantic_score * 0.6 + skill_score * 0.4) * 100, 2)
    explanation = "Strong overlap between the resume content and this job's requirements." if score >= 70 else "Some relevant overlap found; review the listed skill gaps before applying."
    existing = db.scalar(select(JobMatchResult).where(JobMatchResult.student_id == student.id, JobMatchResult.job_id == job.id))
    if existing:
        existing.resume_id = resume.id
        existing.provider = provider.name
        existing.score = score
        existing.matched_skills = matched
        existing.skill_gaps = gaps
        existing.explanation = explanation
        existing.embedding = job_embedding
        result = existing
    else:
        result = JobMatchResult(
            student_id=student.id,
            job_id=job.id,
            resume_id=resume.id,
            provider=provider.name,
            score=score,
            matched_skills=matched,
            skill_gaps=gaps,
            explanation=explanation,
            embedding=job_embedding,
        )
        db.add(result)
    db.commit()
    db.refresh(result)
    return result


def list_matches(db: Session, student: User) -> list[JobMatchResult]:
    return list(db.scalars(select(JobMatchResult).where(JobMatchResult.student_id == student.id).order_by(JobMatchResult.score.desc())).all())
