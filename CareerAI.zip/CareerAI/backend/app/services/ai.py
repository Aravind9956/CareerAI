from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai.providers import get_resume_analysis_provider
from app.core.config import get_settings
from app.models import AIResumeAnalysis, Resume, User
from app.schemas.ai import ResumeAnalysisRequest, ResumeAnalysisResponse


def to_analysis_response(analysis: AIResumeAnalysis) -> ResumeAnalysisResponse:
    return ResumeAnalysisResponse(
        id=analysis.id,
        resume_id=analysis.resume_id,
        provider=analysis.provider,
        target_job_description=analysis.target_job_description,
        result=analysis.result,
        created_at=analysis.created_at,
    )


def analyze_resume(db: Session, student: User, payload: ResumeAnalysisRequest) -> AIResumeAnalysis:
    resume = db.scalar(select(Resume).where(Resume.id == payload.resume_id, Resume.student_id == student.id))
    if resume is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resume not found")
    if not resume.extracted_text:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Resume has no extracted text")
    settings = get_settings()
    try:
        provider = get_resume_analysis_provider(settings.ai_provider)
        result = provider.analyze(resume.extracted_text, payload.target_job_description)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Configured AI provider is unavailable") from exc
    analysis = AIResumeAnalysis(
        student_id=student.id,
        resume_id=resume.id,
        target_job_description=payload.target_job_description,
        provider=provider.name,
        result=result.model_dump(),
    )
    db.add(analysis)
    db.commit()
    db.refresh(analysis)
    return analysis


def list_resume_analyses(db: Session, student: User, resume_id: str | None = None) -> list[AIResumeAnalysis]:
    query = select(AIResumeAnalysis).where(AIResumeAnalysis.student_id == student.id).order_by(AIResumeAnalysis.created_at.desc())
    if resume_id:
        query = query.where(AIResumeAnalysis.resume_id == resume_id)
    return list(db.scalars(query).all())
