from collections.abc import Sequence

from fastapi import HTTPException, status
from sqlalchemy import asc, desc, func, or_, select
from sqlalchemy.orm import Session

from app.models import Company, Job, User
from app.schemas.jobs import JobCreate, JobResponse, JobUpdate
from app.services.companies import get_owned_company

SORT_COLUMNS = {
    "created_at": Job.created_at,
    "deadline": Job.application_deadline,
    "title": Job.title,
}


def to_job_response(job: Job, company_name: str) -> JobResponse:
    return JobResponse(
        id=job.id,
        company_id=job.company_id,
        company_name=company_name,
        title=job.title,
        description=job.description,
        location=job.location,
        work_mode=job.work_mode,
        job_type=job.job_type,
        required_skills=[skill for skill in job.required_skills.split(",") if skill],
        preferred_skills=[skill for skill in job.preferred_skills.split(",") if skill],
        salary_range=job.salary_range,
        experience_requirement=job.experience_requirement,
        education_requirement=job.education_requirement,
        application_deadline=job.application_deadline,
        openings=job.openings,
        is_active=job.is_active,
        created_at=job.created_at,
    )


def skills_to_storage(skills: list[str]) -> str:
    return ",".join(skills)


def create_job(db: Session, recruiter: User, payload: JobCreate) -> Job:
    company = get_owned_company(db, recruiter)
    values = payload.model_dump()
    values["required_skills"] = skills_to_storage(values["required_skills"])
    values["preferred_skills"] = skills_to_storage(values["preferred_skills"])
    job = Job(company_id=company.id, **values)
    db.add(job)
    db.commit()
    db.refresh(job)
    return job


def get_job(db: Session, job_id: str, *, include_inactive: bool = False) -> tuple[Job, str]:
    query = select(Job, Company.name).join(Company, Company.id == Job.company_id).where(Job.id == job_id)
    if not include_inactive:
        query = query.where(Job.is_active.is_(True))
    result = db.execute(query).first()
    if result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    return result


def get_owned_job(db: Session, recruiter: User, job_id: str) -> Job:
    company = get_owned_company(db, recruiter)
    job = db.scalar(select(Job).where(Job.id == job_id, Job.company_id == company.id))
    if job is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    return job


def update_job(db: Session, recruiter: User, job_id: str, payload: JobUpdate) -> Job:
    job = get_owned_job(db, recruiter, job_id)
    values = payload.model_dump(exclude_unset=True)
    for field_name in ("required_skills", "preferred_skills"):
        if field_name in values:
            values[field_name] = skills_to_storage(values[field_name])
    for field_name, value in values.items():
        setattr(job, field_name, value)
    db.commit()
    db.refresh(job)
    return job


def deactivate_job(db: Session, recruiter: User, job_id: str) -> None:
    job = get_owned_job(db, recruiter, job_id)
    job.is_active = False
    db.commit()


def list_jobs(
    db: Session,
    *,
    query_text: str | None,
    location: str | None,
    job_type: str | None,
    work_mode: str | None,
    page: int,
    page_size: int,
    sort_by: str,
    sort_order: str,
) -> tuple[Sequence[tuple[Job, str]], int]:
    query = select(Job, Company.name).join(Company, Company.id == Job.company_id).where(Job.is_active.is_(True))
    if query_text:
        pattern = f"%{query_text.strip()}%"
        query = query.where(or_(Job.title.ilike(pattern), Job.description.ilike(pattern), Job.required_skills.ilike(pattern)))
    if location:
        query = query.where(Job.location.ilike(f"%{location.strip()}%"))
    if job_type:
        query = query.where(Job.job_type == job_type)
    if work_mode:
        query = query.where(Job.work_mode == work_mode)

    total = db.scalar(select(func.count()).select_from(query.subquery())) or 0
    sort_column = SORT_COLUMNS[sort_by]
    query = query.order_by(desc(sort_column) if sort_order == "desc" else asc(sort_column))
    rows = db.execute(query.offset((page - 1) * page_size).limit(page_size)).all()
    return rows, total
