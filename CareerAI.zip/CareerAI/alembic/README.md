Alembic migrations will be added in Phase 2 with the SQLAlchemy database model layer.
