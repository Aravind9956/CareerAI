import React, { useEffect, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { Bell, LogOut, Menu, Sparkles, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import AuthModal from './AuthModal';
import api from '../services/api';
import { Avatar } from './ui';

type NavItem = { to: string; label: string };

const PUBLIC_LINKS: NavItem[] = [{ to: '/jobs', label: 'Discover' }];
const STUDENT_LINKS: NavItem[] = [
  { to: '/dashboard', label: 'Dashboard' },
  { to: '/jobs', label: 'Discover' },
  { to: '/applications', label: 'Applications' },
  { to: '/saved-jobs', label: 'Saved' },
  { to: '/resumes', label: 'Resumes' },
  { to: '/ai', label: 'AI Career Center' },
];
const RECRUITER_LINKS: NavItem[] = [
  { to: '/dashboard', label: 'Dashboard' },
  { to: '/recruiter/jobs', label: 'Jobs' },
  { to: '/company', label: 'Company' },
  { to: '/jobs', label: 'Browse' },
];
const ADMIN_LINKS: NavItem[] = [{ to: '/dashboard', label: 'Dashboard' }, { to: '/jobs', label: 'Jobs' }];

export const Navbar: React.FC = () => {
  const { user, isAuthenticated, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const [authMode, setAuthMode] = useState<'login' | 'register' | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [unread, setUnread] = useState(0);

  const links = !isAuthenticated ? PUBLIC_LINKS
    : user?.role === 'RECRUITER' ? RECRUITER_LINKS
    : user?.role === 'ADMIN' ? ADMIN_LINKS
    : STUDENT_LINKS;

  // Open the auth modal when redirected with ?auth=login|register
  useEffect(() => {
    const requested = params.get('auth');
    if (requested === 'login' || requested === 'register') {
      if (!isAuthenticated) setAuthMode(requested);
      const next = new URLSearchParams(params);
      next.delete('auth');
      setParams(next, { replace: true });
    }
  }, [params, setParams, isAuthenticated]);

  useEffect(() => { setMenuOpen(false); }, [location.pathname]);

  useEffect(() => {
    if (!isAuthenticated) { setUnread(0); return; }
    api.get('/notifications?unread_only=true').then((r) => setUnread(r.data.length)).catch(() => {});
  }, [isAuthenticated, location.pathname]);

  const handleLogout = () => { logout(); setMenuOpen(false); navigate('/'); };
  const linkClass = ({ isActive }: { isActive: boolean }) => `nav-item ${isActive ? 'active' : ''}`;

  return (
    <>
      <header className="navbar">
        <div className="container navbar-inner">
          <Link to="/" className="brand-logo" aria-label="CareerAI home">
            <span className="brand-icon"><Sparkles size={16} /></span>
            <span className="brand-word">career<span>ai</span></span>
          </Link>

          <nav className="nav-links" aria-label="Main">
            {links.map((l) => <NavLink key={l.to + l.label} to={l.to} end={l.to === '/jobs'} className={linkClass}>{l.label}</NavLink>)}
          </nav>

          <div className="nav-actions">
            {isAuthenticated && user ? (
              <>
                <Link to="/notifications" className="icon-btn" aria-label={`Notifications${unread ? `, ${unread} unread` : ''}`}>
                  <Bell size={19} />
                  {unread > 0 && <span className="notif-dot">{unread > 9 ? '9+' : unread}</span>}
                </Link>
                <Link to="/profile" className="nav-profile" aria-label="Profile">
                  <Avatar name={user.full_name} />
                  <span className="nav-profile-name">{user.full_name.split(' ')[0]}</span>
                </Link>
                <button onClick={handleLogout} className="btn btn-ghost btn-sm nav-desktop-only" aria-label="Log out"><LogOut size={16} /></button>
              </>
            ) : (
              <div className="nav-desktop-only nav-auth">
                <button onClick={() => setAuthMode('login')} className="btn btn-ghost btn-sm">Sign in</button>
                <button onClick={() => setAuthMode('register')} className="btn btn-primary btn-sm">Get started</button>
              </div>
            )}
            <button className="icon-btn nav-mobile-only" onClick={() => setMenuOpen((o) => !o)} aria-expanded={menuOpen} aria-label="Toggle menu">
              {menuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className="mobile-menu nav-mobile-only">
            {links.map((l) => <NavLink key={l.to + l.label} to={l.to} className={linkClass}>{l.label}</NavLink>)}
            {isAuthenticated ? (
              <>
                <NavLink to="/notifications" className={linkClass}>Notifications{unread ? ` (${unread})` : ''}</NavLink>
                <NavLink to="/profile" className={linkClass}>Profile</NavLink>
                <button onClick={handleLogout} className="btn btn-secondary btn-block"><LogOut size={16} /> Log out</button>
              </>
            ) : (
              <>
                <button onClick={() => { setMenuOpen(false); setAuthMode('login'); }} className="btn btn-secondary btn-block">Sign in</button>
                <button onClick={() => { setMenuOpen(false); setAuthMode('register'); }} className="btn btn-primary btn-block">Create account</button>
              </>
            )}
          </div>
        )}
      </header>

      {authMode && <AuthModal mode={authMode} onClose={() => setAuthMode(null)} onSwitchMode={setAuthMode} />}
    </>
  );
};
