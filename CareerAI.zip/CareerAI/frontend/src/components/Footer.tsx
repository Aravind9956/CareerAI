import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer style={{
      backgroundColor: 'var(--surface)',
      borderTop: '1px solid var(--border)',
      paddingTop: '3rem',
      paddingBottom: '2.5rem',
      marginTop: 'auto',
    }}>
      <div className="container">
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '2.5rem',
          paddingBottom: '2.5rem',
          borderBottom: '1px solid var(--border)',
        }}>
          {/* Brand Col */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
            <div className="brand-logo">
              <div className="brand-icon">
                <Sparkles size={18} />
              </div>
              <span style={{ fontSize: '1.25rem', fontWeight: 800 }}>
                career<span style={{ color: 'var(--accent)' }}>ai</span>
              </span>
            </div>
            <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
              "Build a career that moves with you."
            </p>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.8125rem', color: 'var(--success)', fontWeight: 600 }}>
              <ShieldCheck size={16} />
              <span>Real-time AI Match Engine</span>
            </div>
          </div>

          {/* Platform Col */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
            <h4 style={{ fontSize: '0.875rem', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)' }}>Platform</h4>
            <Link to="/jobs" style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>Discover Jobs</Link>
            <Link to="/ai" style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>AI Career Tools</Link>
            <Link to="/resumes" style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>Resume Intelligence</Link>
            <Link to="/dashboard" style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>Student Dashboard</Link>
          </div>

          {/* Resources Col */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
            <h4 style={{ fontSize: '0.875rem', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)' }}>AI Services</h4>
            <Link to="/ai" style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>AI Resume Analyzer</Link>
            <Link to="/ai" style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>AI Job Matcher</Link>
            <Link to="/ai" style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>Skill Gap Visualizer</Link>
            <Link to="/ai" style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>AI Interview Coach</Link>
          </div>

          {/* Legal / API Col */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
            <h4 style={{ fontSize: '0.875rem', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-muted)' }}>API & Docs</h4>
            <a href="http://127.0.0.1:8000/docs" target="_blank" rel="noreferrer" style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>FastAPI OpenAPI Docs</a>
            <a href="http://127.0.0.1:8000/api/health" target="_blank" rel="noreferrer" style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>API Health Status</a>
            <span style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>FastAPI + SQLite/PostgreSQL</span>
          </div>
        </div>

        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '1rem',
          paddingTop: '1.5rem',
          fontSize: '0.8125rem',
          color: 'var(--text-muted)',
        }}>
          <span>© {new Date().getFullYear()} CareerAI. All rights reserved.</span>
          <span>AI-assisted, transparent, and career-first platform.</span>
        </div>
      </div>
    </footer>
  );
};
