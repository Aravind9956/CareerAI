import type { ReactNode } from 'react';
import { AlertCircle, Inbox } from 'lucide-react';

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="page-header">
      <div>
        <h1>{title}</h1>
        {subtitle && <p>{subtitle}</p>}
      </div>
      {actions && <div className="page-header-actions">{actions}</div>}
    </div>
  );
}

export function StatCard({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return (
    <div className="stat-card">
      <span className="stat-label">{label}</span>
      <strong className="stat-value">{value}</strong>
      {hint && <span className="stat-hint">{hint}</span>}
    </div>
  );
}

export function Skeleton({ height = 16, width = '100%' }: { height?: number; width?: number | string }) {
  return <div className="skeleton" style={{ height, width }} aria-hidden="true" />;
}

export function SkeletonCards({ count = 3, height = 96 }: { count?: number; height?: number }) {
  return (
    <div className="stack" role="status" aria-label="Loading">
      {Array.from({ length: count }, (_, i) => <Skeleton key={i} height={height} />)}
    </div>
  );
}

export function EmptyState({ title, message, action }: { title: string; message?: string; action?: ReactNode }) {
  return (
    <div className="state-box">
      <Inbox size={28} aria-hidden="true" />
      <h3>{title}</h3>
      {message && <p>{message}</p>}
      {action}
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="state-box state-error" role="alert">
      <AlertCircle size={28} aria-hidden="true" />
      <h3>Something went wrong</h3>
      <p>{message}</p>
      {onRetry && <button className="btn btn-secondary btn-sm" onClick={onRetry}>Try again</button>}
    </div>
  );
}

const STATUS: Record<string, { label: string; cls: string }> = {
  APPLIED: { label: 'Applied', cls: 'badge-default' },
  SHORTLISTED: { label: 'Shortlisted', cls: 'badge-warning' },
  INTERVIEW: { label: 'Interview', cls: 'badge-accent' },
  SELECTED: { label: 'Selected', cls: 'badge-success' },
  REJECTED: { label: 'Rejected', cls: 'badge-danger' },
};

export function StatusBadge({ status }: { status: string }) {
  const meta = STATUS[status] ?? { label: status, cls: 'badge-default' };
  return <span className={`badge ${meta.cls}`}>{meta.label}</span>;
}

/** Circular score. `score` may be 0–1 or 0–100 (the backend job-match score is a float). */
export function MatchScore({ score, size = 88 }: { score: number; size?: number }) {
  const pct = Math.round(score <= 1 ? score * 100 : score);
  const r = (size - 10) / 2;
  const c = 2 * Math.PI * r;
  const color = pct >= 70 ? 'var(--brand-green)' : pct >= 40 ? 'var(--warning)' : 'var(--accent)';
  return (
    <div className="match-score" style={{ width: size, height: size }} role="img" aria-label={`${pct} percent match`}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-muted)" strokeWidth="6" />
        <circle
          cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth="6" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - pct / 100)} transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </svg>
      <span>{pct}%</span>
    </div>
  );
}

export function Avatar({ name }: { name: string }) {
  const initials = name.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]?.toUpperCase()).join('');
  return <span className="avatar-badge" aria-hidden="true">{initials || '?'}</span>;
}

export function formatDate(iso: string | null | undefined): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

export function humanize(value: string): string {
  return value.replace(/_/g, ' ').toLowerCase().replace(/^\w/, (c) => c.toUpperCase());
}
