import React, { useState } from 'react';
import { X, Sparkles, Eye, EyeOff, LoaderCircle, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { useNavigate } from 'react-router-dom';
import { friendlyError } from '../lib/errors';

type Mode = 'login' | 'register';

interface Props {
  mode: Mode;
  onClose: () => void;
  onSwitchMode: (mode: Mode) => void;
}

const AuthModal: React.FC<Props> = ({ mode, onClose, onSwitchMode }) => {
  const { login, register } = useAuth();
  const { success, error: toastError } = useToast();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<'STUDENT' | 'RECRUITER'>('STUDENT');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  function validate(): string {
    if (!email.trim()) return 'Email is required.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return 'Enter a valid email address.';
    if (!password) return 'Password is required.';
    if (mode === 'register') {
      if (password.length < 8) return 'Password must be at least 8 characters.';
      if (!fullName.trim()) return 'Full name is required.';
      if (fullName.trim().length < 2) return 'Full name must be at least 2 characters.';
    }
    return '';
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const validationError = validate();
    if (validationError) { setError(validationError); return; }
    setLoading(true);
    setError('');
    try {
      if (mode === 'login') {
        const user = await login(email.trim(), password);
        success('Welcome back!', `Signed in as ${user.full_name}`);
        onClose();
        navigate('/dashboard');
      } else {
        await register({ email: email.trim(), password, full_name: fullName.trim(), role });
        success('Account created!', 'You\'re now signed in.');
        onClose();
        navigate('/dashboard');
      }
    } catch (err: unknown) {
      const msg = friendlyError(err, mode === 'login' ? 'Sign in failed. Check your credentials.' : 'Registration failed. Please try again.');
      setError(msg);
      toastError(mode === 'login' ? 'Sign in failed' : 'Registration failed', msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-content">
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
            <div className="brand-icon" style={{ width: '2rem', height: '2rem' }}>
              <Sparkles size={15} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.125rem', fontWeight: 700, marginBottom: '0.125rem' }}>
                {mode === 'login' ? 'Sign in to CareerAI' : 'Create your account'}
              </h3>
              <p style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', margin: 0 }}>
                {mode === 'login' ? 'Access your career workspace' : 'Start building your career'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="btn-ghost btn-sm" style={{ padding: '6px', borderRadius: 'var(--radius-sm)' }}>
            <X size={18} />
          </button>
        </div>

        {/* Error banner */}
        {error && (
          <div style={{
            display: 'flex', alignItems: 'flex-start', gap: '0.5rem',
            padding: '0.75rem 1rem', marginBottom: '1.25rem',
            background: 'var(--danger-light)', border: '1px solid #fca5a5',
            borderRadius: 'var(--radius-md)', fontSize: '0.875rem', color: 'var(--danger)',
          }}>
            <AlertCircle size={15} style={{ flexShrink: 0, marginTop: '1px' }} />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          {/* Register fields */}
          {mode === 'register' && (
            <>
              <div className="form-group">
                <label className="form-label" htmlFor="auth-fullname">Full name</label>
                <input
                  id="auth-fullname"
                  className="input"
                  type="text"
                  placeholder="Your full name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  autoComplete="name"
                  disabled={loading}
                />
              </div>
              <div className="form-group">
                <label className="form-label">I am a</label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.625rem' }}>
                  {(['STUDENT', 'RECRUITER'] as const).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRole(r)}
                      style={{
                        padding: '0.625rem', borderRadius: 'var(--radius-md)',
                        border: `2px solid ${role === r ? 'var(--primary)' : 'var(--border)'}`,
                        background: role === r ? 'var(--primary)' : 'var(--surface)',
                        color: role === r ? '#fff' : 'var(--text-secondary)',
                        fontWeight: 600, fontSize: '0.875rem', transition: 'all 0.15s',
                      }}
                    >
                      {r === 'STUDENT' ? '🎓 Student' : '💼 Recruiter'}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          <div className="form-group">
            <label className="form-label" htmlFor="auth-email">Email</label>
            <input
              id="auth-email"
              className="input"
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete={mode === 'login' ? 'username' : 'email'}
              disabled={loading}
            />
          </div>

          <div className="form-group" style={{ marginBottom: '1.5rem' }}>
            <label className="form-label" htmlFor="auth-password">Password</label>
            <div style={{ position: 'relative' }}>
              <input
                id="auth-password"
                className="input"
                type={showPassword ? 'text' : 'password'}
                placeholder={mode === 'register' ? 'At least 8 characters' : 'Your password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                disabled={loading}
                style={{ paddingRight: '2.75rem' }}
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                style={{
                  position: 'absolute', right: '0.75rem', top: '50%', transform: 'translateY(-50%)',
                  background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: '2px',
                }}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="btn btn-primary btn-lg"
            style={{ width: '100%', justifyContent: 'center' }}
            disabled={loading}
          >
            {loading
              ? <><LoaderCircle size={17} className="spin" /> {mode === 'login' ? 'Signing in…' : 'Creating account…'}</>
              : mode === 'login' ? 'Sign in' : 'Create account'
            }
          </button>
        </form>

        {/* Switch mode */}
        <p style={{ textAlign: 'center', marginTop: '1.25rem', fontSize: '0.875rem', color: 'var(--text-muted)' }}>
          {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
          <button
            type="button"
            onClick={() => { setError(''); onSwitchMode(mode === 'login' ? 'register' : 'login'); }}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--accent)', fontWeight: 600, fontSize: '0.875rem' }}
          >
            {mode === 'login' ? 'Create one' : 'Sign in'}
          </button>
        </p>
      </div>
    </div>
  );
};

export default AuthModal;
