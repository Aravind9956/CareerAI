import { BrowserRouter, Link, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { ArrowRight, FileSearch, MessageSquare, Target, TrendingUp } from 'lucide-react';
import { AuthProvider, useAuth, type UserRole } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import Dashboard from './pages/Dashboard';
import JobsPage from './pages/JobsPage';
import JobDetailPage from './pages/JobDetailPage';
import ProfilePage from './pages/ProfilePage';
import ResumesPage from './pages/ResumesPage';
import ApplicationsPage from './pages/ApplicationsPage';
import SavedJobsPage from './pages/SavedJobsPage';
import NotificationsPage from './pages/NotificationsPage';
import AIToolsPage from './pages/AIToolsPage';
import { ApplicantsPage, CompanyPage, RecruiterJobsPage } from './pages/RecruiterPages';
import { Skeleton } from './components/ui';

/* ── Landing (marketing only — no personalised or fake data) ─────────── */
const FEATURES = [
  { icon: Target, title: 'AI Job Matching', text: 'See how your resume lines up with a role, which skills match and which are missing.' },
  { icon: FileSearch, title: 'Resume Intelligence', text: 'Get structured feedback on strengths, gaps and ATS readiness for any target role.' },
  { icon: TrendingUp, title: 'Skill Gap Analysis', text: 'Understand what to learn next, with a suggested learning path for the job you want.' },
  { icon: MessageSquare, title: 'Interview Preparation', text: 'Practise role-specific questions and get feedback on your answers.' },
];

function Landing() {
  const { isAuthenticated } = useAuth();
  return (
    <main>
      <section className="landing-hero">
        <div className="container landing-hero-inner">
          <p className="eyebrow">AI job &amp; internship portal</p>
          <h1>Find work that <em>moves you forward.</em></h1>
          <p className="landing-lead">
            CareerAI connects you with relevant opportunities and AI-powered tools to help you build a stronger career.
          </p>
          <div className="landing-cta">
            <Link className="btn btn-primary btn-lg" to="/jobs">Explore opportunities <ArrowRight size={17} /></Link>
            <Link className="btn btn-secondary btn-lg" to={isAuthenticated ? '/profile' : '/?auth=register'}>Build your profile</Link>
          </div>
        </div>
      </section>

      <section className="container landing-features" aria-labelledby="features-title">
        <h2 id="features-title" className="landing-section-title">Everything you need to move faster</h2>
        <div className="feature-grid">
          {FEATURES.map(({ icon: Icon, title, text }) => (
            <article key={title} className="feature-card">
              <span className="feature-icon"><Icon size={20} /></span>
              <h3>{title}</h3>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}

/* ── Route guards ────────────────────────────────────────────────────── */
function PrivateRoute({ children, roles }: { children: React.ReactNode; roles?: UserRole[] }) {
  const { isAuthenticated, isLoading, user } = useAuth();
  const location = useLocation();
  if (isLoading) return <div className="container main-content"><Skeleton height={200} /></div>;
  if (!isAuthenticated) return <Navigate to="/?auth=login" state={{ from: location }} replace />;
  if (roles && user && !roles.includes(user.role)) return <Navigate to="/dashboard" replace />;
  return <>{children}</>;
}

function PageLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navbar />
      <main className="main-content">
        <div className="container">{children}</div>
      </main>
      <Footer />
    </>
  );
}

const student = (el: React.ReactNode) => <PrivateRoute roles={['STUDENT']}><PageLayout>{el}</PageLayout></PrivateRoute>;
const recruiter = (el: React.ReactNode) => <PrivateRoute roles={['RECRUITER']}><PageLayout>{el}</PageLayout></PrivateRoute>;
const anyUser = (el: React.ReactNode) => <PrivateRoute><PageLayout>{el}</PageLayout></PrivateRoute>;

function AppShell() {
  return (
    <Routes>
      <Route path="/" element={<><Navbar /><Landing /><Footer /></>} />
      <Route path="/jobs" element={<PageLayout><JobsPage /></PageLayout>} />
      <Route path="/jobs/:jobId" element={<PageLayout><JobDetailPage /></PageLayout>} />

      <Route path="/dashboard" element={anyUser(<Dashboard />)} />
      <Route path="/notifications" element={anyUser(<NotificationsPage />)} />
      <Route path="/profile" element={anyUser(<ProfilePage />)} />

      <Route path="/resumes" element={student(<ResumesPage />)} />
      <Route path="/applications" element={student(<ApplicationsPage />)} />
      <Route path="/saved-jobs" element={student(<SavedJobsPage />)} />
      <Route path="/ai" element={student(<AIToolsPage />)} />

      <Route path="/recruiter/jobs" element={recruiter(<RecruiterJobsPage />)} />
      <Route path="/recruiter/jobs/:jobId/applicants" element={recruiter(<ApplicantsPage />)} />
      <Route path="/company" element={recruiter(<CompanyPage />)} />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <AppShell />
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
