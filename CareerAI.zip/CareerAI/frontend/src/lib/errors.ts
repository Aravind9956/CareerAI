import axios from 'axios';

type FieldError = { loc?: (string | number)[]; msg?: string };

/** Turn any thrown API error into a short, user-safe message (never a raw backend exception). */
export function friendlyError(err: unknown, fallback = 'Something went wrong. Please try again.'): string {
  if (!axios.isAxiosError(err)) return fallback;
  if (!err.response) return 'Cannot reach the server. Check that the backend is running and try again.';

  const { status, data } = err.response as { status: number; data?: { detail?: unknown } };
  const detail = data?.detail;

  switch (status) {
    case 401:
      return typeof detail === 'string' && /credential|password|email/i.test(detail)
        ? 'Incorrect email or password.'
        : 'Your session has expired. Please sign in again.';
    case 403:
      return 'You do not have permission to do that.';
    case 404:
      return 'We could not find what you were looking for.';
    case 409:
      return typeof detail === 'string' ? detail : 'This action conflicts with existing data.';
    case 413:
      return 'That file is too large.';
    case 422: {
      if (Array.isArray(detail) && detail.length > 0) {
        const first = detail[0] as FieldError;
        const field = first.loc?.filter((p) => p !== 'body').join(' → ');
        return field ? `Check "${field}": ${first.msg ?? 'invalid value'}` : first.msg ?? 'Some fields are invalid.';
      }
      return typeof detail === 'string' ? detail : 'Some fields are invalid. Please review and try again.';
    }
    default:
      if (status >= 500) return 'The server ran into a problem. Please try again in a moment.';
      return typeof detail === 'string' ? detail : fallback;
  }
}

export function statusOf(err: unknown): number | null {
  return axios.isAxiosError(err) ? err.response?.status ?? null : null;
}
