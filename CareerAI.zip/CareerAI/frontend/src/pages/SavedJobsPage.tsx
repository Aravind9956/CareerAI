import { useEffect, useState } from 'react';
import { Bookmark, Trash2, LoaderCircle, AlertCircle, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

interface SavedJob {
  id: string;
  job_id: string;
  job_title: string;
  company_name: string;
  saved_at: string | null;
}

function timeAgo(dateStr: string | null) {
  if (!dateStr) return 'Recently';
  const d = new Date(dateStr);
  const diff = Date.now() - d.getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 7) return `${days}d ago`;
  return `${Math.floor(days / 7)}w ago`;
}

export default function SavedJobsPage() {
  const { success, error: toastError } = useToast();
  const [savedJobs, setSavedJobs] = useState<SavedJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [removingId, setRemovingId] = useState<string | null>(null);

  useEffect(() => {
    api.get('/saved-jobs')
      .then((res) => setSavedJobs(res.data))
      .catch(() => setError('Could not load saved jobs. Please refresh the page.'))
      .finally(() => setLoading(false));
  }, []);

  async function handleRemove(savedJob: SavedJob) {
    setRemovingId(savedJob.job_id);
    try {
      await api.delete(`/jobs/${savedJob.job_id}/save`);
      setSavedJobs((prev) => prev.filter((s) => s.id !== savedJob.id));
      success('Removed', `${savedJob.job_title} removed from saved jobs`);
    } catch {
      toastError('Remove failed', 'Could not remove this saved job.');
    } finally {
      setRemovingId(null);
    }
  }

  return (
    <div style={{ maxWidth: '780px' }}>
      <div style={{ marginBottom: '2rem' }}>
        <p style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
          Bookmarks
        </p>
        <h1 style={{ marginBottom: '0.5rem' }}>Saved jobs</h1>
        <p style={{ color: 'var(--text-secondary)' }}>
          {savedJobs.length > 0 ? `${savedJobs.length} saved position${savedJobs.length !== 1 ? 's' : ''}` : 'Jobs you bookmark will appear here.'}
        </p>
      </div>

      {loading && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '3rem', color: 'var(--text-muted)' }}>
          <LoaderCircle size={22} className="spin" /> Loading saved jobs…
        </div>
      )}

      {!loading && error && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', padding: '1rem', background: 'var(--danger-light)', borderRadius: 'var(--radius-md)', color: 'var(--danger)', fontSize: '0.875rem' }}>
          <AlertCircle size={16} /> {error}
        </div>
      )}

      {!loading && !error && savedJobs.length === 0 && (
        <div style={{ textAlign: 'center', padding: '4rem 2rem', color: 'var(--text-muted)' }}>
          <Bookmark size={40} style={{ marginBottom: '1rem', opacity: 0.3 }} />
          <h3 style={{ color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>No saved jobs yet</h3>
          <p style={{ fontSize: '0.875rem', marginBottom: '1.25rem' }}>Bookmark jobs from the discover page to track them here</p>
          <Link to="/jobs" className="btn btn-primary">Browse jobs</Link>
        </div>
      )}

      {!loading && !error && savedJobs.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
          {savedJobs.map((savedJob) => (
            <div key={savedJob.id} className="card" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <div style={{
                width: '2.75rem', height: '2.75rem', borderRadius: 'var(--radius-md)', flexShrink: 0,
                background: 'var(--primary)', color: '#fff', display: 'flex', alignItems: 'center',
                justifyContent: 'center', fontWeight: 700, fontSize: '1.125rem',
              }}>
                {savedJob.company_name.charAt(0).toUpperCase()}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <h3 style={{ fontSize: '1rem', margin: '0 0 0.25rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {savedJob.job_title}
                </h3>
                <p style={{ margin: 0, fontWeight: 600, fontSize: '0.875rem', color: 'var(--text-primary)' }}>{savedJob.company_name}</p>
                <p style={{ margin: '0.25rem 0 0', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                  Saved {timeAgo(savedJob.saved_at)}
                </p>
              </div>
              <div style={{ display: 'flex', gap: '0.5rem', flexShrink: 0 }}>
                <Link
                  to={`/jobs`}
                  className="btn btn-secondary btn-sm"
                  title="View job"
                  style={{ display: 'flex', alignItems: 'center', gap: '0.375rem' }}
                >
                  <ExternalLink size={14} /> View
                </Link>
                <button
                  onClick={() => handleRemove(savedJob)}
                  disabled={removingId === savedJob.job_id}
                  className="btn btn-secondary btn-sm"
                  title="Remove"
                  style={{ color: 'var(--danger)', display: 'flex', alignItems: 'center', gap: '0.375rem' }}
                >
                  {removingId === savedJob.job_id ? <LoaderCircle size={14} className="spin" /> : <Trash2 size={14} />}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
