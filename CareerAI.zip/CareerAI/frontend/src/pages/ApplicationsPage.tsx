import { useEffect, useState } from 'react';
import { Briefcase, Clock, LoaderCircle, AlertCircle, FileText, CheckCircle2 } from 'lucide-react';
import api from '../services/api';
import { Link } from 'react-router-dom';

interface Application {
  id: string;
  job_id: string;
  job_title: string;
  company_name: string;
  resume_id: string | null;
  cover_letter: string | null;
  status: string;
  created_at: string;
}

const STATUS_META: Record<string, { label: string; badgeClass: string }> = {
  APPLIED:     { label: 'Applied',     badgeClass: 'badge-default' },
  SHORTLISTED: { label: 'Shortlisted', badgeClass: 'badge-warning' },
  INTERVIEW:   { label: 'Interview',   badgeClass: 'badge-accent' },
  SELECTED:    { label: 'Selected',    badgeClass: 'badge-success' },
  REJECTED:    { label: 'Rejected',    badgeClass: 'badge-danger' },
};

function timeAgo(dateStr: string) {
  const d = new Date(dateStr);
  const diff = Date.now() - d.getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 7) return `${days}d ago`;
  if (days < 30) return `${Math.floor(days / 7)}w ago`;
  return `${Math.floor(days / 30)}mo ago`;
}

export default function ApplicationsPage() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    api.get('/applications/my')
      .then((res) => setApplications(res.data))
      .catch(() => setError('Could not load applications. Please refresh the page.'))
      .finally(() => setLoading(false));
  }, []);

  // Count by status
  const statusCounts = applications.reduce<Record<string, number>>((acc, a) => {
    acc[a.status] = (acc[a.status] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <div style={{ maxWidth: '860px' }}>
      <div style={{ marginBottom: '2rem' }}>
        <p style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
          Applications
        </p>
        <h1 style={{ marginBottom: '0.5rem' }}>My applications</h1>
        <p style={{ color: 'var(--text-secondary)' }}>
          {applications.length > 0 ? `${applications.length} total application${applications.length !== 1 ? 's' : ''}` : 'Track all your job applications in one place.'}
        </p>
      </div>

      {/* Status summary cards */}
      {applications.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: '0.875rem', marginBottom: '2rem' }}>
          {Object.entries(STATUS_META).map(([status, meta]) => (
            <div key={status} className="card" style={{ padding: '1rem', textAlign: 'center' }}>
              <p style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 0.25rem' }}>
                {statusCounts[status] ?? 0}
              </p>
              <p style={{ fontSize: '0.75rem', fontWeight: 600, margin: 0 }}>{meta.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '3rem', color: 'var(--text-muted)' }}>
          <LoaderCircle size={22} className="spin" /> Loading applications…
        </div>
      )}

      {/* Error */}
      {!loading && error && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', padding: '1rem', background: 'var(--danger-light)', borderRadius: 'var(--radius-md)', color: 'var(--danger)', fontSize: '0.875rem' }}>
          <AlertCircle size={16} /> {error}
        </div>
      )}

      {/* Empty */}
      {!loading && !error && applications.length === 0 && (
        <div style={{ textAlign: 'center', padding: '4rem 2rem', color: 'var(--text-muted)' }}>
          <Briefcase size={40} style={{ marginBottom: '1rem', opacity: 0.3 }} />
          <h3 style={{ color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>No applications yet</h3>
          <p style={{ fontSize: '0.875rem', marginBottom: '1.25rem' }}>Start applying to jobs to track your progress here</p>
          <Link to="/jobs" className="btn btn-primary">Browse jobs</Link>
        </div>
      )}

      {/* Application list */}
      {!loading && !error && applications.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
          {applications.map((app) => {
            const meta = STATUS_META[app.status] ?? { label: app.status, badgeClass: 'badge-default' };
            const isExpanded = expandedId === app.id;
            return (
              <div key={app.id} className="card" style={{ padding: '1.25rem' }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '1rem' }}>
                  <div style={{
                    width: '2.75rem', height: '2.75rem', borderRadius: 'var(--radius-md)', flexShrink: 0,
                    background: 'var(--primary)', color: '#fff', display: 'flex', alignItems: 'center',
                    justifyContent: 'center', fontWeight: 700, fontSize: '1.125rem',
                  }}>
                    {app.company_name.charAt(0).toUpperCase()}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', flexWrap: 'wrap', marginBottom: '0.25rem' }}>
                      <h3 style={{ fontSize: '1rem', margin: 0 }}>{app.job_title}</h3>
                      <span className={`badge ${meta.badgeClass}`}>{meta.label}</span>
                      {app.status === 'SELECTED' && <CheckCircle2 size={16} style={{ color: 'var(--success)' }} />}
                    </div>
                    <p style={{ margin: '0 0 0.375rem', fontWeight: 600, fontSize: '0.875rem', color: 'var(--text-primary)' }}>{app.company_name}</p>
                    <p style={{ margin: 0, fontSize: '0.8125rem', display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
                      <Clock size={12} /> Applied {timeAgo(app.created_at)}
                      {app.resume_id && <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', marginLeft: '0.25rem' }}><FileText size={12} /> Resume attached</span>}
                    </p>
                  </div>
                  {app.cover_letter && (
                    <button
                      onClick={() => setExpandedId(isExpanded ? null : app.id)}
                      className="btn btn-secondary btn-sm"
                    >
                      {isExpanded ? 'Hide' : 'Cover letter'}
                    </button>
                  )}
                </div>

                {isExpanded && app.cover_letter && (
                  <div style={{
                    marginTop: '1rem', padding: '1rem', background: 'var(--surface-muted)',
                    borderRadius: 'var(--radius-md)', fontSize: '0.875rem', lineHeight: '1.7',
                    color: 'var(--text-secondary)', whiteSpace: 'pre-wrap',
                  }}>
                    {app.cover_letter}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
