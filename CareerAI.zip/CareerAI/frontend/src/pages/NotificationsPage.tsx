import { useEffect, useState } from 'react';
import { Bell, BellOff, CheckCheck, Clock, LoaderCircle, AlertCircle } from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

interface Notification {
  id: string;
  title: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

function timeAgo(dateStr: string) {
  const d = new Date(dateStr);
  const diff = Date.now() - d.getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days === 1) return 'Yesterday';
  if (days < 7) return `${days}d ago`;
  return `${Math.floor(days / 7)}w ago`;
}

export default function NotificationsPage() {
  const { success, error: toastError } = useToast();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [markingAll, setMarkingAll] = useState(false);

  useEffect(() => {
    api.get('/notifications')
      .then((res) => setNotifications(res.data))
      .catch(() => setError('Could not load notifications.'))
      .finally(() => setLoading(false));
  }, []);

  async function markRead(id: string) {
    try {
      await api.patch(`/notifications/${id}/read`);
      setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, is_read: true } : n));
    } catch {
      toastError('Error', 'Could not mark notification as read.');
    }
  }

  async function markAllRead() {
    setMarkingAll(true);
    try {
      await api.post('/notifications/read-all');
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
      success('All notifications read', 'Your inbox is clear.');
    } catch {
      toastError('Error', 'Could not mark all notifications as read.');
    } finally {
      setMarkingAll(false);
    }
  }

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  return (
    <div style={{ maxWidth: '700px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <p style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
            Inbox
          </p>
          <h1 style={{ marginBottom: '0.5rem' }}>Notifications</h1>
          <p style={{ color: 'var(--text-secondary)' }}>
            {unreadCount > 0 ? `${unreadCount} unread notification${unreadCount !== 1 ? 's' : ''}` : 'You are all caught up.'}
          </p>
        </div>
        {unreadCount > 0 && (
          <button
            onClick={markAllRead}
            disabled={markingAll}
            className="btn btn-secondary"
            style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', alignSelf: 'flex-start' }}
          >
            {markingAll ? <LoaderCircle size={15} className="spin" /> : <CheckCheck size={15} />}
            Mark all as read
          </button>
        )}
      </div>

      {loading && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '3rem', color: 'var(--text-muted)' }}>
          <LoaderCircle size={22} className="spin" /> Loading notifications…
        </div>
      )}

      {!loading && error && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', padding: '1rem', background: 'var(--danger-light)', borderRadius: 'var(--radius-md)', color: 'var(--danger)', fontSize: '0.875rem' }}>
          <AlertCircle size={16} /> {error}
        </div>
      )}

      {!loading && !error && notifications.length === 0 && (
        <div style={{ textAlign: 'center', padding: '4rem 2rem', color: 'var(--text-muted)' }}>
          <BellOff size={40} style={{ marginBottom: '1rem', opacity: 0.3 }} />
          <h3 style={{ color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>No notifications yet</h3>
          <p style={{ fontSize: '0.875rem' }}>Notifications about your applications will appear here</p>
        </div>
      )}

      {!loading && !error && notifications.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className="card"
              style={{
                padding: '1.125rem 1.25rem',
                display: 'flex', alignItems: 'flex-start', gap: '1rem',
                background: notification.is_read ? 'var(--surface)' : 'var(--accent-light)',
                border: notification.is_read ? '1px solid var(--border)' : '1px solid #fed7aa',
                cursor: notification.is_read ? 'default' : 'pointer',
                transition: 'all 0.15s',
              }}
              onClick={() => { if (!notification.is_read) markRead(notification.id); }}
            >
              <div style={{
                width: '2.25rem', height: '2.25rem', borderRadius: '50%', flexShrink: 0,
                background: notification.is_read ? 'var(--surface-muted)' : 'var(--accent)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: notification.is_read ? 'var(--text-muted)' : '#fff',
              }}>
                <Bell size={16} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.5rem', marginBottom: '0.25rem' }}>
                  <h4 style={{ fontSize: '0.9375rem', fontWeight: notification.is_read ? 500 : 700, margin: 0 }}>
                    {notification.title}
                  </h4>
                  {!notification.is_read && (
                    <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--accent)', flexShrink: 0, marginTop: '5px' }} />
                  )}
                </div>
                <p style={{ margin: '0 0 0.375rem', fontSize: '0.875rem', lineHeight: '1.5' }}>
                  {notification.message}
                </p>
                <p style={{ margin: 0, fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                  <Clock size={11} /> {timeAgo(notification.created_at)}
                  {!notification.is_read && <span style={{ marginLeft: '0.375rem', color: 'var(--accent)', fontWeight: 600 }}>· Click to mark as read</span>}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
