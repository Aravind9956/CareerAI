import React, { useEffect, useState } from 'react';
import {
  User, Building2, Code, Link2, Globe, MapPin, Phone, GraduationCap,
  Save, LoaderCircle, CheckCircle2, AlertCircle,
} from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

/* ── Student Profile ─────────────────────────────────────────────────── */
interface StudentProfile {
  user_id: string;
  full_name: string;
  email: string;
  phone: string | null;
  location: string | null;
  degree: string | null;
  college: string | null;
  graduation_year: number | null;
  github_url: string | null;
  linkedin_url: string | null;
  portfolio_url: string | null;
  profile_completion: number;
  missing: string[];
}

function StudentProfileForm({ profile, onSaved }: { profile: StudentProfile; onSaved: (p: StudentProfile) => void }) {
  const { success, error: toastError } = useToast();
  const [form, setForm] = useState({
    full_name: profile.full_name || '',
    phone: profile.phone || '',
    location: profile.location || '',
    degree: profile.degree || '',
    college: profile.college || '',
    graduation_year: profile.graduation_year ? String(profile.graduation_year) : '',
    github_url: profile.github_url || '',
    linkedin_url: profile.linkedin_url || '',
    portfolio_url: profile.portfolio_url || '',
  });
  const [loading, setLoading] = useState(false);

  function set(key: string, val: string) { setForm((f) => ({ ...f, [key]: val })); }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const body = {
        full_name: form.full_name || null,
        phone: form.phone || null,
        location: form.location || null,
        degree: form.degree || null,
        college: form.college || null,
        graduation_year: form.graduation_year ? parseInt(form.graduation_year) : null,
        github_url: form.github_url || null,
        linkedin_url: form.linkedin_url || null,
        portfolio_url: form.portfolio_url || null,
      };
      const res = await api.put('/students/profile', body);
      onSaved(res.data);
      success('Profile updated', 'Your changes have been saved.');
    } catch (err: unknown) {
      const msg = (err && typeof err === 'object' && 'response' in err)
        ? ((err as { response?: { data?: { detail?: string } } }).response?.data?.detail ?? 'Update failed.')
        : 'Update failed.';
      toastError('Update failed', msg);
    } finally {
      setLoading(false);
    }
  }

  const completionColor = profile.profile_completion >= 80 ? 'var(--success)' : profile.profile_completion >= 50 ? 'var(--warning)' : 'var(--danger)';

  return (
    <form onSubmit={handleSave}>
      {/* Completion meter */}
      <div className="card" style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
        <div style={{
          width: '3.5rem', height: '3.5rem', borderRadius: '50%',
          border: `4px solid ${completionColor}`, display: 'flex', alignItems: 'center',
          justifyContent: 'center', fontSize: '0.9375rem', fontWeight: 700, color: completionColor, flexShrink: 0,
        }}>
          {profile.profile_completion}%
        </div>
        <div style={{ flex: 1 }}>
          <p style={{ fontWeight: 600, color: 'var(--text-primary)', margin: '0 0 0.25rem' }}>Profile completeness</p>
          {profile.missing.length > 0 ? (
            <p style={{ fontSize: '0.8125rem', margin: 0 }}>
              Missing: {profile.missing.join(', ')}
            </p>
          ) : (
            <p style={{ fontSize: '0.8125rem', color: 'var(--success)', margin: 0, display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
              <CheckCircle2 size={14} /> Profile is complete
            </p>
          )}
        </div>
      </div>

      {/* Basic info */}
      <h3 style={{ marginBottom: '1rem', fontSize: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Basic information</h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1.25rem', marginBottom: '1.5rem' }}>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label" htmlFor="p-fullname">Full name</label>
          <input id="p-fullname" className="input" value={form.full_name} onChange={(e) => set('full_name', e.target.value)} placeholder="Your full name" />
        </div>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label" htmlFor="p-phone"><Phone size={13} style={{ display: 'inline', marginRight: '4px' }} />Phone</label>
          <input id="p-phone" className="input" value={form.phone} onChange={(e) => set('phone', e.target.value)} placeholder="+1 555 000 0000" />
        </div>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label" htmlFor="p-location"><MapPin size={13} style={{ display: 'inline', marginRight: '4px' }} />Location</label>
          <input id="p-location" className="input" value={form.location} onChange={(e) => set('location', e.target.value)} placeholder="City, Country" />
        </div>
      </div>

      {/* Education */}
      <h3 style={{ marginBottom: '1rem', fontSize: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Education</h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1.25rem', marginBottom: '1.5rem' }}>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label" htmlFor="p-degree"><GraduationCap size={13} style={{ display: 'inline', marginRight: '4px' }} />Degree</label>
          <input id="p-degree" className="input" value={form.degree} onChange={(e) => set('degree', e.target.value)} placeholder="B.S. Computer Science" />
        </div>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label" htmlFor="p-college">College / University</label>
          <input id="p-college" className="input" value={form.college} onChange={(e) => set('college', e.target.value)} placeholder="University name" />
        </div>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label" htmlFor="p-gradyear">Graduation year</label>
          <input id="p-gradyear" className="input" type="number" min={1950} max={2200} value={form.graduation_year} onChange={(e) => set('graduation_year', e.target.value)} placeholder="2026" />
        </div>
      </div>

      {/* Links */}
      <h3 style={{ marginBottom: '1rem', fontSize: '1rem', color: 'var(--text-secondary)', fontWeight: 600 }}>Links</h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label" htmlFor="p-github"><Code size={13} style={{ display: 'inline', marginRight: '4px' }} />GitHub</label>
          <input id="p-github" className="input" value={form.github_url} onChange={(e) => set('github_url', e.target.value)} placeholder="https://github.com/username" />
        </div>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label" htmlFor="p-linkedin"><Link2 size={13} style={{ display: 'inline', marginRight: '4px' }} />LinkedIn</label>
          <input id="p-linkedin" className="input" value={form.linkedin_url} onChange={(e) => set('linkedin_url', e.target.value)} placeholder="https://linkedin.com/in/username" />
        </div>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label" htmlFor="p-portfolio"><Globe size={13} style={{ display: 'inline', marginRight: '4px' }} />Portfolio</label>
          <input id="p-portfolio" className="input" value={form.portfolio_url} onChange={(e) => set('portfolio_url', e.target.value)} placeholder="https://yoursite.com" />
        </div>
      </div>

      <button type="submit" className="btn btn-primary" disabled={loading} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        {loading ? <><LoaderCircle size={16} className="spin" /> Saving…</> : <><Save size={16} /> Save profile</>}
      </button>
    </form>
  );
}

/* ── Recruiter Profile ───────────────────────────────────────────────── */
interface RecruiterProfile {
  user_id: string;
  full_name: string;
  email: string;
  phone: string | null;
  company_id: string | null;
}

function RecruiterProfileForm({ profile, onSaved }: { profile: RecruiterProfile; onSaved: (p: RecruiterProfile) => void }) {
  const { success, error: toastError } = useToast();
  const [form, setForm] = useState({ full_name: profile.full_name || '', phone: profile.phone || '' });
  const [loading, setLoading] = useState(false);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.put('/recruiters/profile', { full_name: form.full_name || null, phone: form.phone || null });
      onSaved(res.data);
      success('Profile updated', 'Your changes have been saved.');
    } catch {
      toastError('Update failed', 'Could not save profile changes.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSave}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label" htmlFor="rp-fullname">Full name</label>
          <input id="rp-fullname" className="input" value={form.full_name} onChange={(e) => setForm((f) => ({ ...f, full_name: e.target.value }))} placeholder="Your full name" />
        </div>
        <div className="form-group" style={{ margin: 0 }}>
          <label className="form-label" htmlFor="rp-phone"><Phone size={13} style={{ display: 'inline', marginRight: '4px' }} />Phone</label>
          <input id="rp-phone" className="input" value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} placeholder="+1 555 000 0000" />
        </div>
      </div>
      {profile.company_id && (
        <div className="card" style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <Building2 size={18} style={{ color: 'var(--accent)' }} />
          <div>
            <p style={{ fontWeight: 600, color: 'var(--text-primary)', margin: 0, fontSize: '0.875rem' }}>Company linked</p>
            <p style={{ fontSize: '0.8125rem', margin: 0 }}>ID: {profile.company_id}</p>
          </div>
        </div>
      )}
      <button type="submit" className="btn btn-primary" disabled={loading} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        {loading ? <><LoaderCircle size={16} className="spin" /> Saving…</> : <><Save size={16} /> Save profile</>}
      </button>
    </form>
  );
}

/* ── Page ────────────────────────────────────────────────────────────── */
export default function ProfilePage() {
  const { user } = useAuth();
  const [studentProfile, setStudentProfile] = useState<StudentProfile | null>(null);
  const [recruiterProfile, setRecruiterProfile] = useState<RecruiterProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function load() {
      try {
        if (user?.role === 'STUDENT') {
          const res = await api.get('/students/profile');
          setStudentProfile(res.data);
        } else if (user?.role === 'RECRUITER') {
          const res = await api.get('/recruiters/profile');
          setRecruiterProfile(res.data);
        }
      } catch {
        setError('Could not load profile. Please refresh the page.');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [user]);

  return (
    <div style={{ maxWidth: '860px' }}>
      <div style={{ marginBottom: '2rem' }}>
        <p style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
          Your account
        </p>
        <h1 style={{ marginBottom: '0.5rem' }}>Profile</h1>
        <p style={{ color: 'var(--text-secondary)' }}>
          {user?.role === 'STUDENT' ? 'Manage your student profile and career links.' : 'Manage your recruiter account.'}
        </p>
      </div>

      {/* Account summary */}
      <div className="card" style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
        <div style={{
          width: '3rem', height: '3rem', borderRadius: '50%', background: 'var(--primary)',
          color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '1.125rem', flexShrink: 0,
        }}>
          {user?.full_name?.charAt(0).toUpperCase() ?? <User size={20} />}
        </div>
        <div>
          <p style={{ fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 0.125rem', fontSize: '1.0625rem' }}>{user?.full_name}</p>
          <p style={{ margin: 0, fontSize: '0.875rem' }}>{user?.email}</p>
        </div>
        <span className="badge badge-default" style={{ marginLeft: 'auto' }}>
          {user?.role === 'STUDENT' ? '🎓 Student' : user?.role === 'RECRUITER' ? '💼 Recruiter' : '🛡 Admin'}
        </span>
      </div>

      {loading && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '3rem', color: 'var(--text-muted)' }}>
          <LoaderCircle size={22} className="spin" /> Loading profile…
        </div>
      )}

      {!loading && error && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', padding: '1rem', background: 'var(--danger-light)', borderRadius: 'var(--radius-md)', color: 'var(--danger)', fontSize: '0.875rem' }}>
          <AlertCircle size={16} /> {error}
        </div>
      )}

      {!loading && !error && studentProfile && (
        <div className="card">
          <StudentProfileForm profile={studentProfile} onSaved={setStudentProfile} />
        </div>
      )}

      {!loading && !error && recruiterProfile && (
        <div className="card">
          <RecruiterProfileForm profile={recruiterProfile} onSaved={setRecruiterProfile} />
        </div>
      )}
    </div>
  );
}
