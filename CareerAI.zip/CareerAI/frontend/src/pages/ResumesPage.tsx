import React, { useEffect, useRef, useState } from 'react';
import {
  Upload, Trash2, Download, FileText, CheckCircle2, Clock, LoaderCircle, AlertCircle,
} from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

interface Resume {
  id: string;
  file_name: string;
  is_current: boolean;
  extracted_text: string | null;
  created_at: string;
}

function timeAgo(dateStr: string) {
  const d = new Date(dateStr);
  const diff = Date.now() - d.getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 7) return `${days}d ago`;
  return `${Math.floor(days / 7)}w ago`;
}

export default function ResumesPage() {
  const { success, error: toastError } = useToast();
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function loadResumes() {
    setLoading(true); setError('');
    try {
      const res = await api.get('/resumes');
      setResumes(res.data);
    } catch {
      setError('Could not load resumes. Make sure you are signed in.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadResumes(); }, []);

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.pdf') && file.type !== 'application/pdf') {
      toastError('Invalid file', 'Please upload a PDF file.');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toastError('File too large', 'Maximum file size is 5 MB.');
      return;
    }
    setUploading(true);
    try {
      const form = new FormData();
      form.append('file', file);
      await api.post('/resumes/upload', form, { headers: { 'Content-Type': 'multipart/form-data' } });
      success('Resume uploaded!', `${file.name} is now your current resume.`);
      await loadResumes();
    } catch (err: unknown) {
      const msg = (err && typeof err === 'object' && 'response' in err)
        ? ((err as { response?: { data?: { detail?: string } } }).response?.data?.detail ?? 'Upload failed.')
        : 'Upload failed. The file may not be a readable PDF.';
      toastError('Upload failed', msg);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }

  async function handleDelete(resume: Resume) {
    if (!window.confirm(`Delete "${resume.file_name}"? This cannot be undone.`)) return;
    setDeletingId(resume.id);
    try {
      await api.delete(`/resumes/${resume.id}`);
      success('Resume deleted', `${resume.file_name} has been removed.`);
      setResumes((prev) => prev.filter((r) => r.id !== resume.id));
    } catch {
      toastError('Delete failed', 'Could not delete the resume.');
    } finally {
      setDeletingId(null);
    }
  }

  async function handleDownload(resume: Resume) {
    try {
      const res = await api.get(`/resumes/${resume.id}/download`, { responseType: 'blob' });
      const url = URL.createObjectURL(new Blob([res.data], { type: 'application/pdf' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = resume.file_name;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      toastError('Download failed', 'Could not download the resume file.');
    }
  }

  return (
    <div style={{ maxWidth: '780px' }}>
      <div style={{ marginBottom: '2rem' }}>
        <p style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
          Resume center
        </p>
        <h1 style={{ marginBottom: '0.5rem' }}>Your resumes</h1>
        <p style={{ color: 'var(--text-secondary)' }}>
          Upload PDF resumes. The most recently uploaded becomes your current resume.
        </p>
      </div>

      {/* Upload zone */}
      <div
        className="card"
        onClick={() => fileInputRef.current?.click()}
        style={{
          border: '2px dashed var(--border)', cursor: 'pointer', textAlign: 'center', padding: '2.5rem',
          marginBottom: '2rem', transition: 'all 0.15s',
          background: uploading ? 'var(--surface-muted)' : 'var(--surface)',
        }}
        onMouseEnter={(e) => (e.currentTarget.style.borderColor = 'var(--primary)')}
        onMouseLeave={(e) => (e.currentTarget.style.borderColor = 'var(--border)')}
      >
        <input ref={fileInputRef} type="file" accept="application/pdf,.pdf" onChange={handleUpload} style={{ display: 'none' }} disabled={uploading} />
        {uploading
          ? <><LoaderCircle size={32} className="spin" style={{ color: 'var(--accent)', marginBottom: '0.75rem' }} /><p style={{ fontWeight: 600, color: 'var(--text-primary)' }}>Uploading and extracting text…</p></>
          : (
            <>
              <Upload size={32} style={{ color: 'var(--text-muted)', marginBottom: '0.75rem' }} />
              <p style={{ fontWeight: 600, color: 'var(--text-primary)', marginBottom: '0.25rem' }}>Click to upload a PDF resume</p>
              <p style={{ fontSize: '0.8125rem' }}>PDF only · maximum 5 MB</p>
            </>
          )
        }
      </div>

      {/* Loading */}
      {loading && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '3rem', color: 'var(--text-muted)' }}>
          <LoaderCircle size={22} className="spin" /> Loading resumes…
        </div>
      )}

      {/* Error */}
      {!loading && error && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', padding: '1rem', background: 'var(--danger-light)', borderRadius: 'var(--radius-md)', color: 'var(--danger)', fontSize: '0.875rem', marginBottom: '1rem' }}>
          <AlertCircle size={16} /> {error}
        </div>
      )}

      {/* Empty */}
      {!loading && !error && resumes.length === 0 && (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
          <FileText size={40} style={{ marginBottom: '1rem', opacity: 0.3 }} />
          <h3 style={{ color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>No resumes yet</h3>
          <p style={{ fontSize: '0.875rem' }}>Upload your first PDF resume above</p>
        </div>
      )}

      {/* Resume list */}
      {!loading && !error && resumes.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
          {resumes.map((resume) => (
            <div key={resume.id} className="card" style={{ padding: '1.25rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <div style={{
                  width: '2.75rem', height: '2.75rem', borderRadius: 'var(--radius-md)', flexShrink: 0,
                  background: resume.is_current ? 'var(--accent-light)' : 'var(--surface-muted)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: resume.is_current ? 'var(--accent)' : 'var(--text-muted)',
                }}>
                  <FileText size={20} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <p style={{ fontWeight: 600, color: 'var(--text-primary)', margin: 0, fontSize: '0.9375rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {resume.file_name}
                    </p>
                    {resume.is_current && (
                      <span className="badge badge-success" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                        <CheckCircle2 size={10} /> Current
                      </span>
                    )}
                  </div>
                  <p style={{ margin: '0.25rem 0 0', fontSize: '0.8125rem', display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
                    <Clock size={12} /> {timeAgo(resume.created_at)}
                    {resume.extracted_text && (
                      <span style={{ color: 'var(--success)', marginLeft: '0.25rem' }}>· Text extracted</span>
                    )}
                  </p>
                </div>
                <div style={{ display: 'flex', gap: '0.5rem', flexShrink: 0 }}>
                  {resume.extracted_text && (
                    <button
                      onClick={() => setExpandedId(expandedId === resume.id ? null : resume.id)}
                      className="btn btn-secondary btn-sm"
                    >
                      {expandedId === resume.id ? 'Hide' : 'Preview'}
                    </button>
                  )}
                  <button
                    onClick={() => handleDownload(resume)}
                    className="btn btn-secondary btn-sm"
                    title="Download"
                    style={{ display: 'flex', alignItems: 'center', gap: '0.375rem' }}
                  >
                    <Download size={14} />
                  </button>
                  <button
                    onClick={() => handleDelete(resume)}
                    disabled={deletingId === resume.id}
                    className="btn btn-secondary btn-sm"
                    title="Delete"
                    style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', color: 'var(--danger)' }}
                  >
                    {deletingId === resume.id ? <LoaderCircle size={14} className="spin" /> : <Trash2 size={14} />}
                  </button>
                </div>
              </div>

              {/* Extracted text preview */}
              {expandedId === resume.id && resume.extracted_text && (
                <div style={{
                  marginTop: '1rem', padding: '1rem', background: 'var(--surface-muted)',
                  borderRadius: 'var(--radius-md)', fontSize: '0.8125rem', lineHeight: '1.7',
                  color: 'var(--text-secondary)', maxHeight: '300px', overflowY: 'auto',
                  whiteSpace: 'pre-wrap',
                }}>
                  {resume.extracted_text}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
