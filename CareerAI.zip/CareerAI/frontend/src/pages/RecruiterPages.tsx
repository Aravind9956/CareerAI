import { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Pencil, Plus, Trash2, Users, X } from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';
import { friendlyError, statusOf } from '../lib/errors';
import { EmptyState, ErrorState, PageHeader, SkeletonCards, StatusBadge, formatDate, humanize } from '../components/ui';

type Company = { id: string; name: string; description: string | null; website_url: string | null; location: string | null };
type Job = {
  id: string; company_id: string; title: string; description: string; location: string | null;
  work_mode: string; job_type: string; required_skills: string[]; preferred_skills: string[];
  salary_range: string | null; experience_requirement: string | null; education_requirement: string | null;
  openings: number; is_active: boolean; created_at: string;
};
type Application = { id: string; job_id: string; job_title: string; status: string; cover_letter: string | null; resume_id: string | null; created_at: string };

const STATUSES = ['APPLIED', 'SHORTLISTED', 'INTERVIEW', 'SELECTED', 'REJECTED'] as const;
const splitSkills = (v: string) => v.split(',').map((s) => s.trim()).filter(Boolean);

/* ── Manage jobs ─────────────────────────────────────────────────────── */
export function RecruiterJobsPage() {
  const { success, error: toastError } = useToast();
  const [company, setCompany] = useState<Company | null>(null);
  const [noCompany, setNoCompany] = useState(false);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editing, setEditing] = useState<Job | 'new' | null>(null);

  const load = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const c = await api.get<Company>('/companies/me');
      setCompany(c.data);
      // No "my jobs" endpoint exists: combine the public active list (filtered to this company)
      // with the recruiter dashboard's recent jobs, which also include closed listings.
      const [active, dash] = await Promise.all([
        api.get<{ items: Job[] }>('/jobs?page=1&page_size=100'),
        api.get<{ recent_jobs: Job[] }>('/dashboards/recruiter'),
      ]);
      const map = new Map<string, Job>();
      [...dash.data.recent_jobs, ...active.data.items.filter((j) => j.company_id === c.data.id)].forEach((j) => map.set(j.id, j));
      setJobs([...map.values()].sort((a, b) => b.created_at.localeCompare(a.created_at)));
      setNoCompany(false);
    } catch (e) {
      if (statusOf(e) === 404) setNoCompany(true); else setError(friendlyError(e));
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function close(job: Job) {
    if (!window.confirm(`Close "${job.title}"? It will no longer appear in job search.`)) return;
    try { await api.delete(`/jobs/${job.id}`); success('Job closed'); load(); }
    catch (e) { toastError('Could not close job', friendlyError(e)); }
  }

  return (
    <div className="stack-lg">
      <PageHeader title="Manage jobs" subtitle={company ? company.name : undefined}
        actions={company && <button className="btn btn-primary" onClick={() => setEditing('new')}><Plus size={16} /> New job</button>} />
      {loading ? <SkeletonCards /> : error ? <ErrorState message={error} onRetry={load} /> : noCompany ? (
        <EmptyState title="Set up your company first" message="Jobs are posted on behalf of a company."
          action={<Link className="btn btn-primary" to="/company">Create company profile</Link>} />
      ) : jobs.length === 0 ? (
        <EmptyState title="No jobs yet" message="Post your first opening to start receiving applications."
          action={<button className="btn btn-primary" onClick={() => setEditing('new')}>Post a job</button>} />
      ) : (
        <div className="stack">
          {jobs.map((job) => (
            <article key={job.id} className="card row-card">
              <div className="row-main">
                <h3>{job.title}</h3>
                <p className="muted small">{job.location || humanize(job.work_mode)} · {humanize(job.job_type)} · Posted {formatDate(job.created_at)}</p>
              </div>
              <span className={`badge ${job.is_active ? 'badge-success' : 'badge-default'}`}>{job.is_active ? 'Active' : 'Closed'}</span>
              <div className="row-actions">
                <Link className="btn btn-secondary btn-sm" to={`/recruiter/jobs/${job.id}/applicants`}><Users size={14} /> Applicants</Link>
                <button className="btn btn-ghost btn-sm" onClick={() => setEditing(job)} aria-label={`Edit ${job.title}`}><Pencil size={14} /></button>
                {job.is_active && <button className="btn btn-ghost btn-sm" onClick={() => close(job)} aria-label={`Close ${job.title}`}><Trash2 size={14} /></button>}
              </div>
            </article>
          ))}
        </div>
      )}
      {editing && <JobFormDialog job={editing === 'new' ? null : editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); load(); }} />}
    </div>
  );
}

function JobFormDialog({ job, onClose, onSaved }: { job: Job | null; onClose: () => void; onSaved: () => void }) {
  const { success, error: toastError } = useToast();
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState({
    title: job?.title ?? '', description: job?.description ?? '', location: job?.location ?? '',
    work_mode: job?.work_mode ?? 'REMOTE', job_type: job?.job_type ?? 'FULL_TIME',
    required_skills: job?.required_skills.join(', ') ?? '', preferred_skills: job?.preferred_skills.join(', ') ?? '',
    salary_range: job?.salary_range ?? '', experience_requirement: job?.experience_requirement ?? '',
    education_requirement: job?.education_requirement ?? '', openings: job?.openings ?? 1,
  });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setF((p) => ({ ...p, [k]: k === 'openings' ? Number(e.target.value) : e.target.value }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const body = {
      title: f.title, description: f.description, location: f.location || null, work_mode: f.work_mode, job_type: f.job_type,
      required_skills: splitSkills(f.required_skills), preferred_skills: splitSkills(f.preferred_skills),
      salary_range: f.salary_range || null, experience_requirement: f.experience_requirement || null,
      education_requirement: f.education_requirement || null, openings: f.openings,
    };
    try {
      if (job) await api.put(`/jobs/${job.id}`, body); else await api.post('/jobs', body);
      success(job ? 'Job updated' : 'Job posted');
      onSaved();
    } catch (err) { toastError('Could not save job', friendlyError(err)); }
    finally { setBusy(false); }
  }

  return (
    <div className="modal-overlay" role="dialog" aria-modal="true" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <form className="modal-content modal-wide" onSubmit={submit}>
        <div className="modal-head"><h3>{job ? 'Edit job' : 'Post a job'}</h3>
          <button type="button" className="btn btn-ghost btn-sm" onClick={onClose} aria-label="Close"><X size={18} /></button></div>
        <div className="form-grid">
          <div className="form-group span-2"><label className="form-label" htmlFor="jt">Title</label>
            <input id="jt" className="input" required minLength={2} value={f.title} onChange={set('title')} /></div>
          <div className="form-group"><label className="form-label" htmlFor="jm">Work mode</label>
            <select id="jm" className="select" value={f.work_mode} onChange={set('work_mode')}>
              <option value="REMOTE">Remote</option><option value="HYBRID">Hybrid</option><option value="ONSITE">On-site</option></select></div>
          <div className="form-group"><label className="form-label" htmlFor="jy">Job type</label>
            <select id="jy" className="select" value={f.job_type} onChange={set('job_type')}>
              <option value="FULL_TIME">Full time</option><option value="PART_TIME">Part time</option><option value="INTERNSHIP">Internship</option></select></div>
          <div className="form-group"><label className="form-label" htmlFor="jl">Location</label>
            <input id="jl" className="input" value={f.location} onChange={set('location')} /></div>
          <div className="form-group"><label className="form-label" htmlFor="js">Salary range</label>
            <input id="js" className="input" value={f.salary_range} onChange={set('salary_range')} /></div>
          <div className="form-group span-2"><label className="form-label" htmlFor="jd">Description</label>
            <textarea id="jd" className="input textarea" rows={5} required minLength={20} value={f.description} onChange={set('description')} /></div>
          <div className="form-group span-2"><label className="form-label" htmlFor="jr">Required skills <span className="muted">(comma separated)</span></label>
            <input id="jr" className="input" value={f.required_skills} onChange={set('required_skills')} /></div>
          <div className="form-group span-2"><label className="form-label" htmlFor="jp">Preferred skills <span className="muted">(comma separated)</span></label>
            <input id="jp" className="input" value={f.preferred_skills} onChange={set('preferred_skills')} /></div>
          <div className="form-group"><label className="form-label" htmlFor="je">Experience</label>
            <input id="je" className="input" value={f.experience_requirement} onChange={set('experience_requirement')} /></div>
          <div className="form-group"><label className="form-label" htmlFor="jed">Education</label>
            <input id="jed" className="input" value={f.education_requirement} onChange={set('education_requirement')} /></div>
          <div className="form-group"><label className="form-label" htmlFor="jo">Openings</label>
            <input id="jo" type="number" min={1} className="input" value={f.openings} onChange={set('openings')} /></div>
        </div>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : job ? 'Save changes' : 'Post job'}</button>
        </div>
      </form>
    </div>
  );
}

/* ── Applicants for one job ──────────────────────────────────────────── */
export function ApplicantsPage() {
  const { jobId } = useParams<{ jobId: string }>();
  const { success, error: toastError } = useToast();
  const [apps, setApps] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('ALL');

  const load = useCallback(() => {
    setLoading(true); setError('');
    api.get<Application[]>(`/recruiter/applications/${jobId}`)
      .then((r) => setApps(r.data))
      .catch((e) => setError(friendlyError(e)))
      .finally(() => setLoading(false));
  }, [jobId]);
  useEffect(load, [load]);

  async function setStatus(app: Application, status: string) {
    try {
      const r = await api.patch<Application>(`/applications/${app.id}/status`, { status });
      setApps((prev) => prev.map((a) => (a.id === app.id ? { ...a, status: r.data.status } : a)));
      success('Status updated', humanize(status));
    } catch (e) { toastError('Could not update status', friendlyError(e)); }
  }

  const visible = filter === 'ALL' ? apps : apps.filter((a) => a.status === filter);

  return (
    <div className="stack-lg">
      <Link to="/recruiter/jobs" className="btn btn-ghost btn-sm back-btn"><ArrowLeft size={15} /> All jobs</Link>
      <PageHeader title="Applicants" subtitle={apps[0]?.job_title} />
      <div className="tabs" role="tablist">
        {['ALL', ...STATUSES].map((s) => (
          <button key={s} role="tab" aria-selected={filter === s} className={`tab ${filter === s ? 'active' : ''}`} onClick={() => setFilter(s)}>
            {s === 'ALL' ? `All (${apps.length})` : `${humanize(s)} (${apps.filter((a) => a.status === s).length})`}
          </button>
        ))}
      </div>
      {loading ? <SkeletonCards /> : error ? <ErrorState message={error} onRetry={load} /> : visible.length === 0 ? (
        <EmptyState title="No applicants here" message="Applications will appear as candidates apply." />
      ) : (
        <div className="stack">
          {visible.map((a) => (
            <article key={a.id} className="card stack">
              <div className="row-card-flat">
                <div className="row-main">
                  <h3>Application {a.id.slice(0, 8)}</h3>
                  <p className="muted small">Applied {formatDate(a.created_at)} · {a.resume_id ? 'Resume attached' : 'No resume'}</p>
                </div>
                <StatusBadge status={a.status} />
                <select className="select select-sm" value={a.status} aria-label="Change status" onChange={(e) => setStatus(a, e.target.value)}>
                  {STATUSES.map((s) => <option key={s} value={s}>{humanize(s)}</option>)}
                </select>
              </div>
              {a.cover_letter && <p className="prose small">{a.cover_letter}</p>}
            </article>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── Company profile ─────────────────────────────────────────────────── */
export function CompanyPage() {
  const { success, error: toastError } = useToast();
  const [exists, setExists] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [f, setF] = useState({ name: '', description: '', website_url: '', location: '' });

  useEffect(() => {
    api.get<Company>('/companies/me')
      .then((r) => { setExists(true); setF({ name: r.data.name, description: r.data.description ?? '', website_url: r.data.website_url ?? '', location: r.data.location ?? '' }); })
      .catch((e) => { if (statusOf(e) !== 404) setError(friendlyError(e)); })
      .finally(() => setLoading(false));
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const body = { name: f.name, description: f.description || null, website_url: f.website_url || null, location: f.location || null };
    try {
      if (exists) await api.put('/companies/me', body); else { await api.post('/companies', body); setExists(true); }
      success('Company saved');
    } catch (err) { toastError('Could not save company', friendlyError(err)); }
    finally { setBusy(false); }
  }
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF((p) => ({ ...p, [k]: e.target.value }));

  return (
    <div className="stack-lg narrow">
      <PageHeader title="Company profile" subtitle={exists ? 'Shown on your job listings.' : 'Create your company to start posting jobs.'} />
      {loading ? <SkeletonCards count={1} height={280} /> : error ? <ErrorState message={error} /> : (
        <form className="card stack" onSubmit={submit}>
          <div className="form-group"><label className="form-label" htmlFor="cn">Company name</label>
            <input id="cn" className="input" required minLength={2} value={f.name} onChange={set('name')} /></div>
          <div className="form-group"><label className="form-label" htmlFor="cl">Location</label>
            <input id="cl" className="input" value={f.location} onChange={set('location')} /></div>
          <div className="form-group"><label className="form-label" htmlFor="cw">Website</label>
            <input id="cw" className="input" type="url" placeholder="https://" value={f.website_url} onChange={set('website_url')} /></div>
          <div className="form-group"><label className="form-label" htmlFor="cd">About</label>
            <textarea id="cd" className="input textarea" rows={5} value={f.description} onChange={set('description')} /></div>
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : exists ? 'Save changes' : 'Create company'}</button>
        </form>
      )}
    </div>
  );
}
