import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { friendlyError } from '../lib/errors';
import { EmptyState, ErrorState, MatchScore, PageHeader, Skeleton, StatCard, StatusBadge, formatDate, humanize } from '../components/ui';

type Job = { id: string; company_name: string; title: string; location: string | null; job_type: string; work_mode: string; is_active: boolean; created_at: string };
type StudentDash = {
  profile_completion: number; applications_total: number; applications_by_status: Record<string, number>;
  saved_jobs_count: number; current_resume_present: boolean; recommended_jobs: Job[];
};
type RecruiterDash = {
  company_name: string; active_jobs: number; total_applications: number; shortlisted_candidates: number;
  interviews: number; selected_candidates: number; recent_jobs: Job[];
};
type AdminDash = {
  total_users: number; students: number; recruiters: number; companies: number; jobs: number; active_listings: number; applications: number;
};
type Application = { id: string; job_id: string; job_title: string; company_name: string; status: string; created_at: string };
type Notification = { id: string; title: string; message: string; is_read: boolean; created_at: string };
type Analysis = { id: string; created_at: string; result: { overall_score: number; improvement_suggestions: string[] } };
type Match = { id: string; job_id: string; score: number; skill_gaps: string[]; created_at: string };

function greeting() {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
}

function JobRow({ job }: { job: Job }) {
  return (
    <Link to={`/jobs/${job.id}`} className="list-row">
      <span className="company-mark sm" aria-hidden="true">{job.company_name.charAt(0)}</span>
      <span className="list-row-main">
        <strong>{job.title}</strong>
        <span className="muted small">{job.company_name} · {job.location || humanize(job.work_mode)}</span>
      </span>
      <span className="chip">{humanize(job.job_type)}</span>
    </Link>
  );
}

/* ── Student ─────────────────────────────────────────────────────────── */
function StudentView({ data, name }: { data: StudentDash; name: string }) {
  const [apps, setApps] = useState<Application[] | null>(null);
  const [notes, setNotes] = useState<Notification[] | null>(null);
  const [analysis, setAnalysis] = useState<Analysis | null | undefined>(undefined);
  const [matches, setMatches] = useState<Match[] | null>(null);

  useEffect(() => {
    api.get<Application[]>('/applications/my').then((r) => setApps(r.data)).catch(() => setApps([]));
    api.get<Notification[]>('/notifications').then((r) => setNotes(r.data)).catch(() => setNotes([]));
    api.get<Analysis[]>('/ai/resume-analyses')
      .then((r) => setAnalysis([...r.data].sort((a, b) => b.created_at.localeCompare(a.created_at))[0] ?? null))
      .catch(() => setAnalysis(null));
    api.get<Match[]>('/ai/job-matches').then((r) => setMatches(r.data)).catch(() => setMatches([]));
  }, []);

  const interviews = (apps ?? []).filter((a) => a.status === 'INTERVIEW');
  const gaps = matches ? [...new Set(matches.flatMap((m) => m.skill_gaps))].slice(0, 8) : null;
  const chart = Object.entries(data.applications_by_status).map(([s, count]) => ({ status: humanize(s), count }));
  const unread = (notes ?? []).filter((n) => !n.is_read).length;

  return (
    <div className="stack-lg">
      <PageHeader title={`${greeting()}, ${name.split(' ')[0]}`} subtitle="Here's where your search stands." />

      <div className="stat-grid">
        <StatCard label="Applications" value={data.applications_total} />
        <StatCard label="Saved jobs" value={data.saved_jobs_count} />
        <StatCard label="Interviews" value={data.applications_by_status.INTERVIEW ?? 0} />
        <StatCard label="Profile strength" value={`${data.profile_completion}%`} />
      </div>

      <div className="dash-grid">
        <section className="card span-main">
          <div className="card-head"><h2 className="section-title">Recommended jobs</h2><Link to="/jobs" className="link-arrow">Browse all <ArrowRight size={14} /></Link></div>
          {data.recommended_jobs.length === 0
            ? <EmptyState title="No active roles yet" message="New listings will show up here." />
            : <div className="list">{data.recommended_jobs.map((j) => <JobRow key={j.id} job={j} />)}</div>}
          <p className="muted small note">Recent active listings — not personalised rankings.</p>
        </section>

        <section className="card">
          <h2 className="section-title">Resume strength</h2>
          {analysis === undefined ? <Skeleton height={88} /> : analysis ? (
            <div className="stack">
              <div className="match-row"><MatchScore score={analysis.result.overall_score} />
                <p className="muted small">Latest AI review · {formatDate(analysis.created_at)}</p></div>
              {analysis.result.improvement_suggestions[0] && <p className="small">{analysis.result.improvement_suggestions[0]}</p>}
              <Link to="/ai" className="link-arrow">Open AI Career Center <ArrowRight size={14} /></Link>
            </div>
          ) : (
            <div className="stack">
              <p className="muted small">{data.current_resume_present ? 'Run an AI review on your resume to see a score.' : 'Upload a resume to get an AI review.'}</p>
              <Link to={data.current_resume_present ? '/ai' : '/resumes'} className="btn btn-secondary btn-sm">{data.current_resume_present ? 'Review resume' : 'Upload resume'}</Link>
            </div>
          )}
        </section>

        <section className="card span-main">
          <div className="card-head"><h2 className="section-title">Application activity</h2><Link to="/applications" className="link-arrow">View all <ArrowRight size={14} /></Link></div>
          {data.applications_total === 0 ? (
            <EmptyState title="No applications yet" message="Apply to a role and track it here." />
          ) : (
            <>
              <div className="chart-box">
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={chart} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
                    <CartesianGrid vertical={false} stroke="var(--border)" />
                    <XAxis dataKey="status" tick={{ fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: 'var(--text-muted)' }} axisLine={false} tickLine={false} />
                    <Tooltip cursor={{ fill: 'var(--surface-muted)' }} />
                    <Bar dataKey="count" fill="var(--brand-green)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="list">
                {(apps ?? []).slice(0, 4).map((a) => (
                  <Link key={a.id} to={`/jobs/${a.job_id}`} className="list-row">
                    <span className="list-row-main"><strong>{a.job_title}</strong><span className="muted small">{a.company_name} · {formatDate(a.created_at)}</span></span>
                    <StatusBadge status={a.status} />
                  </Link>
                ))}
              </div>
            </>
          )}
        </section>

        <section className="card">
          <h2 className="section-title">Skill gap</h2>
          {gaps === null ? <Skeleton height={60} /> : gaps.length > 0 ? (
            <div className="stack"><p className="muted small">From your recent AI job matches</p>
              <div className="chip-row">{gaps.map((g) => <span key={g} className="chip chip-coral">{g}</span>)}</div>
              <Link to="/ai" className="link-arrow">Run a skill gap analysis <ArrowRight size={14} /></Link></div>
          ) : (
            <div className="stack"><p className="muted small">Match yourself against a job to see which skills to build.</p>
              <Link to="/ai" className="btn btn-secondary btn-sm">Analyse skill gap</Link></div>
          )}
        </section>

        <section className="card">
          <h2 className="section-title">Interview stage</h2>
          {apps === null ? <Skeleton height={60} /> : interviews.length === 0
            ? <p className="muted small">No applications are at the interview stage right now.</p>
            : <div className="list">{interviews.map((a) => (
                <Link key={a.id} to={`/jobs/${a.job_id}`} className="list-row"><span className="list-row-main"><strong>{a.job_title}</strong><span className="muted small">{a.company_name}</span></span></Link>))}</div>}
        </section>

        <section className="card">
          <div className="card-head"><h2 className="section-title">Notifications{unread > 0 && <span className="badge badge-accent">{unread} new</span>}</h2>
            <Link to="/notifications" className="link-arrow">All <ArrowRight size={14} /></Link></div>
          {notes === null ? <Skeleton height={60} /> : notes.length === 0
            ? <p className="muted small">You're all caught up.</p>
            : <div className="list">{notes.slice(0, 3).map((n) => (
                <div key={n.id} className="list-row static"><span className="list-row-main"><strong>{n.title}</strong><span className="muted small">{n.message}</span></span>
                  {!n.is_read && <span className="dot" aria-label="Unread" />}</div>))}</div>}
        </section>
      </div>
    </div>
  );
}

/* ── Recruiter ───────────────────────────────────────────────────────── */
function RecruiterView({ data }: { data: RecruiterDash }) {
  return (
    <div className="stack-lg">
      <PageHeader title={data.company_name || 'Recruiter dashboard'} subtitle="Your hiring pipeline at a glance."
        actions={<Link className="btn btn-primary" to="/recruiter/jobs">Manage jobs</Link>} />
      <div className="stat-grid">
        <StatCard label="Active jobs" value={data.active_jobs} />
        <StatCard label="Applications" value={data.total_applications} />
        <StatCard label="Shortlisted" value={data.shortlisted_candidates} />
        <StatCard label="Interviews" value={data.interviews} />
      </div>
      <section className="card">
        <h2 className="section-title">Recent jobs</h2>
        {data.recent_jobs.length === 0 ? <EmptyState title="No jobs yet" message="Post a job to start receiving applications." action={<Link className="btn btn-primary btn-sm" to="/recruiter/jobs">Post a job</Link>} /> : (
          <div className="list">{data.recent_jobs.map((j) => (
            <Link key={j.id} to={`/recruiter/jobs/${j.id}/applicants`} className="list-row">
              <span className="list-row-main"><strong>{j.title}</strong><span className="muted small">{j.location || humanize(j.work_mode)} · {humanize(j.job_type)}</span></span>
              <span className={`badge ${j.is_active ? 'badge-success' : 'badge-default'}`}>{j.is_active ? 'Active' : 'Closed'}</span>
            </Link>))}</div>)}
      </section>
    </div>
  );
}

/* ── Admin ───────────────────────────────────────────────────────────── */
function AdminView({ data }: { data: AdminDash }) {
  return (
    <div className="stack-lg">
      <PageHeader title="Platform overview" />
      <div className="stat-grid">
        <StatCard label="Users" value={data.total_users} hint={`${data.students} students · ${data.recruiters} recruiters`} />
        <StatCard label="Companies" value={data.companies} />
        <StatCard label="Jobs" value={data.jobs} hint={`${data.active_listings} active`} />
        <StatCard label="Applications" value={data.applications} />
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const role = user?.role?.toLowerCase() ?? 'student';
  const [data, setData] = useState<StudentDash | RecruiterDash | AdminDash | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(() => {
    setLoading(true); setError('');
    api.get(`/dashboards/${role}`).then((r) => setData(r.data)).catch((e) => setError(friendlyError(e))).finally(() => setLoading(false));
  }, [role]);
  useEffect(load, [load]);

  if (loading) {
    return (
      <div className="stack-lg" role="status" aria-label="Loading dashboard">
        <Skeleton height={36} width={280} />
        <div className="stat-grid">{[0, 1, 2, 3].map((i) => <Skeleton key={i} height={92} />)}</div>
        <Skeleton height={260} />
      </div>
    );
  }
  if (error || !data) return <ErrorState message={error || 'Could not load your dashboard.'} onRetry={load} />;

  if (role === 'recruiter') return <RecruiterView data={data as RecruiterDash} />;
  if (role === 'admin') return <AdminView data={data as AdminDash} />;
  return <StudentView data={data as StudentDash} name={user?.full_name ?? ''} />;
}
