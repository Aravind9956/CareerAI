import { useState } from 'react'
import type { FormEvent } from 'react'
import { ArrowLeft, FileSearch, LoaderCircle, Sparkles, Upload } from 'lucide-react'
import { Link } from 'react-router-dom'
import api from '../services/api'
import '../App.css'

type Analysis = {
  overall_score: number
  skills: { name: string; strength: string }[]
  strengths: string[]
  weaknesses: string[]
  missing_skills: string[]
  improvement_suggestions: string[]
  ats_feedback: string[]
}

export default function ResumeAnalyzer() {
  const [file, setFile] = useState<File | null>(null)
  const [targetJobDescription, setTargetJobDescription] = useState('')
  const [analysis, setAnalysis] = useState<Analysis | null>(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(event: FormEvent) {
    event.preventDefault()
    const token = localStorage.getItem('careerai_access_token')
    if (!token) { setError('Sign in to analyze a resume.'); return }
    if (!file) { setError('Choose a PDF resume first.'); return }
    setLoading(true); setError('')
    try {
      const formData = new FormData()
      formData.append('file', file)
      const upload = await api.post('/resumes/upload', formData, { headers: { Authorization: `Bearer ${token}` } })
      const response = await api.post('/ai/resume-analysis', { resume_id: upload.data.id, target_job_description: targetJobDescription || null }, { headers: { Authorization: `Bearer ${token}` } })
      setAnalysis(response.data.result)
    } catch { setError('We could not analyze that resume. Check that it is a readable PDF and try again.') } finally { setLoading(false) }
  }

  return <main className="app-shell analyzer-shell"><nav className="topbar"><Link className="brand" to="/"><span className="brand-mark"><Sparkles size={16} /></span>career<span>ai</span></Link><Link className="back-link" to="/dashboard"><ArrowLeft size={15} /> Dashboard</Link></nav><section className="analyzer-content"><div className="analyzer-heading"><div><p className="section-kicker">Resume intelligence</p><h1>Understand what<br /><em>your resume is saying.</em></h1><p className="dashboard-copy">Get structured feedback on clarity, strengths, ATS readiness, and the skills a target role asks for.</p></div><FileSearch size={34} /></div><form className="analyzer-form" onSubmit={submit}><label className="upload-zone"><Upload size={22} /><strong>{file ? file.name : 'Choose a PDF resume'}</strong><span>{file ? 'Ready to analyze' : 'PDF only · up to 5 MB'}</span><input type="file" accept="application/pdf,.pdf" onChange={(event) => setFile(event.target.files?.[0] || null)} /></label><label className="analyzer-label">Target job description <span>optional</span><textarea value={targetJobDescription} onChange={(event) => setTargetJobDescription(event.target.value)} placeholder="Paste a role description to identify skill gaps..." rows={5} /></label><button className="primary-button" disabled={loading}>{loading ? <><LoaderCircle className="spin" size={16} /> Analyzing</> : <><Sparkles size={16} /> Analyze resume</>}</button>{error && <p className="analyzer-error">{error}</p>}</form>{analysis && <section className="analysis-result"><div className="analysis-score"><span>AI estimate</span><strong>{analysis.overall_score}<small>/100</small></strong><p>Compatibility and resume-quality signal, not a hiring decision.</p></div><div className="analysis-panels"><article className="analysis-panel"><p className="section-kicker">Detected skills</p><h2>What is already present</h2><div className="skill-list">{analysis.skills.map((skill) => <span key={skill.name}>{skill.name}<small>{skill.strength}</small></span>)}</div></article><article className="analysis-panel gaps-panel"><p className="section-kicker">Skill gaps</p><h2>Worth developing for this role</h2>{analysis.missing_skills.length ? <div className="skill-list">{analysis.missing_skills.map((skill) => <span key={skill}>{skill}</span>)}</div> : <p className="dashboard-copy">No target-specific gaps were detected.</p>}</article></div><div className="analysis-notes"><div><strong>Strengths</strong>{analysis.strengths.map((item) => <p key={item}>+ {item}</p>)}</div><div><strong>Improve next</strong>{analysis.improvement_suggestions.map((item) => <p key={item}>+ {item}</p>)}</div></div></section>}</section></main>
}
