import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Bookmark, BookmarkCheck, Building2, Clock, LoaderCircle, MapPin, Sparkles, X } from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { friendlyError, statusOf } from '../lib/errors';
import { ErrorState, MatchScore, Skeleton, formatDate, humanize } from '../components/ui';

type Job = {
  id: string; company_id: string; company_name: string; title: string; description: string;
  location: string | null; work_mode: string; job_type: string;
  required_skills: string[]; preferred_skills: string[];
  salary_range: string | null; experience_requirement: string | null; education_requirement: string | null;
  application_deadline: string | null; openings: number; is_active: boolean; created_at: string;
};
type Resume = { id: string; file_name: string; is_current: boolean };
type Match = { score: number; matched_skills: string[]; skill_gaps: string[]; explanation: string; is_estimate: boolean; provider: string };

export default function JobDetailPage() {
  const { jobId } = useParams<{ jobId: string }>();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { success, error: toastError } = useToast();
  const isStudent = user?.role === 'STUDENT';

  const [job, setJob] = useState<Job | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);
  const [applied, setApplied] = useState(false);
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [match, setMatch] = useState<Match | null>(null);
  const [matching, setMatching] = useState(false);
  const [showApply, setShowApply] = useState(false);

  const load = useCallback(() => {
    if (!jobId) return;
    setLoading(true);
    setError('');
    api.get<Job>(`/jobs/${jobId}`)
      .then((r) => setJob(r.data))
      .catch((e) => setError(statusOf(e) === 404 ? 'This job no longer exists.' : friendlyError(e)))
      .finally(() => setLoading(false));
  }, [jobId]);

  useEffect(load, [load]);

  useEffect(() => {
    if (!isAuthenticated || !isStudent || !jobId) return;
    api.get<{ job_id: string }[]>('/saved-jobs').then((r) => setSaved(r.data.some((s) => s.job_id === jobId))).catch(() => {});
    api.get<{ job_id: string }[]>('/applications/my').then((r) => setApplied(r.data.some((a) => a.job_id === jobId))).catch(() => {});
    api.get<Resume[]>('/resumes').then((r) => setResumes(r.data)).catch(() => {});
  }, [isAuthenticated, isStudent, jobId]);

  async function toggleSave() {
    if (!job) return;
    try {
      if (saved) { await api.delete(`/jobs/${job.id}/save`); setSaved(false); }
      else { await api.post(`/jobs/${job.id}/save`); setSaved(true); }
    } catch (e) {
      // 409 means it was already saved — treat as saved.
      if (statusOf(e) === 409) setSaved(true); else toastError('Could not update saved jobs', friendlyError(e));
    }
  }

  async function runMatch() {
    if (!job) return;
    const current = resumes.find((r) => r.is_current) ?? resumes[0];
    if (!current) { toastError('Upload a resume first', 'AI matching compares your resume with this role.'); return; }
    setMatching(true);
    try {
      const r = await api.post<Match>('/ai/job-match', { job_id: job.id, resume_id: current.id });
      setMatch(r.data);
    } catch (e) {
      toastError('Match failed', friendlyError(e));
    } finally { setMatching(false); }
  }

  if (loading) {
    return <div className="stack"><Skeleton height={28} width={220} /><Skeleton height={140} /><Skeleton height={260} /></div>;
  }
  if (error || !job) {
    return <ErrorState message={error || 'Job not found.'} onRetry={error ? load : undefined} />;
  }

  return (
    <div className="stack-lg">
      <button className="btn btn-ghost btn-sm back-btn" onClick={() => navigate(-1)}><ArrowLeft size={15} /> Back</button>

      <header className="detail-head card">
        <div className="company-mark" aria-hidden="true">{job.company_name.charAt(0)}</div>
        <div className="detail-head-main">
          <h1>{job.title}</h1>
          <p className="muted"><Building2 size={14} /> {job.company_name}</p>
          <div className="chip-row">
            {job.location && <span className="chip"><MapPin size={12} /> {job.location}</span>}
            <span className="chip">{humanize(job.work_mode)}</span>
            <span className="chip">{humanize(job.job_type)}</span>
            {job.salary_range && <span className="chip">{job.salary_range}</span>}
            {!job.is_active && <span className="badge badge-danger">Closed</span>}
          </div>
        </div>
      </header>

      <div className="detail-layout">
        <div className="stack-lg">
          <section className="card">
            <h2 className="section-title">About the role</h2>
            <p className="prose">{job.description}</p>
          </section>

          {(job.required_skills.length > 0 || job.preferred_skills.length > 0) && (
            <section className="card">
              <h2 className="section-title">Skills</h2>
              {job.required_skills.length > 0 && (
                <>
                  <h3 className="mini-title">Required</h3>
                  <div className="chip-row">{job.required_skills.map((s) => <span key={s} className="chip chip-green">{s}</span>)}</div>
                </>
              )}
              {job.preferred_skills.length > 0 && (
                <>
                  <h3 className="mini-title">Nice to have</h3>
                  <div className="chip-row">{job.preferred_skills.map((s) => <span key={s} className="chip">{s}</span>)}</div>
                </>
              )}
            </section>
          )}

          <section className="card">
            <h2 className="section-title">Details</h2>
            <dl className="facts">
              {job.experience_requirement && <><dt>Experience</dt><dd>{job.experience_requirement}</dd></>}
              {job.education_requirement && <><dt>Education</dt><dd>{job.education_requirement}</dd></>}
              <dt>Openings</dt><dd>{job.openings}</dd>
              <dt>Posted</dt><dd>{formatDate(job.created_at)}</dd>
              {job.application_deadline && <><dt>Deadline</dt><dd>{formatDate(job.application_deadline)}</dd></>}
            </dl>
          </section>
        </div>

        <aside className="stack detail-side">
          <section className="card">
            {isStudent ? (
              <div className="stack">
                <button className="btn btn-primary btn-block" disabled={applied || !job.is_active} onClick={() => setShowApply(true)}>
                  {applied ? 'Already applied' : job.is_active ? 'Apply now' : 'Applications closed'}
                </button>
                <button className="btn btn-secondary btn-block" onClick={toggleSave}>
                  {saved ? <><BookmarkCheck size={16} /> Saved</> : <><Bookmark size={16} /> Save job</>}
                </button>
                {job.application_deadline && <p className="muted small"><Clock size={12} /> Apply by {formatDate(job.application_deadline)}</p>}
              </div>
            ) : isAuthenticated ? (
              <p className="muted small">Sign in with a student account to apply for this role.</p>
            ) : (
              <div className="stack">
                <p className="muted small">Create a free account to apply and get AI match insights.</p>
                <Link className="btn btn-primary btn-block" to="/?auth=register">Create account</Link>
                <Link className="btn btn-secondary btn-block" to="/?auth=login">Sign in</Link>
              </div>
            )}
          </section>

          {isStudent && (
            <section className="card">
              <h2 className="section-title"><Sparkles size={16} /> AI match</h2>
              {!match ? (
                <div className="stack">
                  <p className="muted small">Compare your current resume with this role.</p>
                  {resumes.length === 0 && <p className="muted small">Upload a resume in the <Link to="/resumes">Resume Center</Link> to enable this.</p>}
                  <button className="btn btn-secondary btn-block" onClick={runMatch} disabled={matching || resumes.length === 0}>
                    {matching ? <><LoaderCircle size={15} className="spin" /> Analysing…</> : 'Check my match'}
                  </button>
                </div>
              ) : (
                <div className="stack">
                  <div className="match-row"><MatchScore score={match.score} /><p className="muted small">{match.explanation}</p></div>
                  {match.matched_skills.length > 0 && (<><h3 className="mini-title">Matched skills</h3>
                    <div className="chip-row">{match.matched_skills.map((s) => <span key={s} className="chip chip-green">{s}</span>)}</div></>)}
                  {match.skill_gaps.length > 0 && (<><h3 className="mini-title">Skill gaps</h3>
                    <div className="chip-row">{match.skill_gaps.map((s) => <span key={s} className="chip chip-coral">{s}</span>)}</div></>)}
                  {match.is_estimate && <p className="muted small">This is an automated estimate, not a hiring prediction.</p>}
                </div>
              )}
            </section>
          )}
        </aside>
      </div>

      {showApply && (
        <ApplyDialog
          job={job}
          resumeId={(resumes.find((r) => r.is_current) ?? resumes[0])?.id ?? null}
          onClose={() => setShowApply(false)}
          onApplied={() => { setApplied(true); success('Application submitted', `${job.title} at ${job.company_name}`); }}
        />
      )}
    </div>
  );
}

function ApplyDialog({ job, resumeId, onClose, onApplied }: { job: Job; resumeId: string | null; onClose: () => void; onApplied: () => void }) {
  const { error: toastError } = useToast();
  const [cover, setCover] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await api.post(`/jobs/${job.id}/apply`, { cover_letter: cover.trim() || null, resume_id: resumeId });
      onApplied();
      onClose();
    } catch (err) {
      toastError('Application failed', statusOf(err) === 409 ? 'You have already applied to this job.' : friendlyError(err));
      if (statusOf(err) === 409) { onApplied(); onClose(); }
    } finally { setBusy(false); }
  }

  return (
    <div className="modal-overlay" role="dialog" aria-modal="true" aria-label={`Apply for ${job.title}`}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <form className="modal-content" onSubmit={submit}>
        <div className="modal-head">
          <div><h3>Apply for {job.title}</h3><p className="muted small">{job.company_name}</p></div>
          <button type="button" className="btn btn-ghost btn-sm" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </div>
        <div className="form-group">
          <label className="form-label" htmlFor="cover">Cover letter <span className="muted">(optional)</span></label>
          <textarea id="cover" className="input textarea" rows={6} maxLength={5000} value={cover} onChange={(e) => setCover(e.target.value)}
            placeholder="Tell them why you're a good fit." />
        </div>
        <p className="muted small">{resumeId ? 'Your current resume will be attached.' : 'No resume on file — you can apply without one.'}</p>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? 'Submitting…' : 'Submit application'}</button>
        </div>
      </form>
    </div>
  );
}
