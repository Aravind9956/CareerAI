import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';

export type UserRole = 'STUDENT' | 'RECRUITER' | 'ADMIN';

export type User = {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  is_active: boolean;
};

type AuthContextType = {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (payload: { email: string; password: string; full_name: string; role: UserRole }) => Promise<User>;
  logout: () => void;
  refreshUser: () => Promise<User | null>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('careerai_access_token'));
  const [user, setUser] = useState<User | null>(() => {
    const cached = localStorage.getItem('careerai_user');
    return cached ? JSON.parse(cached) : null;
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Fetch latest user data when token changes or app initializes
  const fetchUser = async (authToken?: string) => {
    const tokenToUse = authToken || localStorage.getItem('careerai_access_token');
    if (!tokenToUse) {
      setUser(null);
      setIsLoading(false);
      return null;
    }

    try {
      const response = await api.get('/users/me', {
        headers: { Authorization: `Bearer ${tokenToUse}` },
      });
      const userData: User = response.data;
      setUser(userData);
      localStorage.setItem('careerai_user', JSON.stringify(userData));
      localStorage.setItem('careerai_role', userData.role.toLowerCase());
      return userData;
    } catch {
      logout();
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUser();

    // Listen for auth expiration events dispatched by api interceptor
    const handleAuthChange = () => {
      setToken(null);
      setUser(null);
    };
    window.addEventListener('careerai_auth_change', handleAuthChange);
    return () => window.removeEventListener('careerai_auth_change', handleAuthChange);
  }, []);

  const login = async (email: string, password: string): Promise<User> => {
    const formData = new URLSearchParams();
    formData.append('username', email);
    formData.append('password', password);

    const response = await api.post('/auth/login', formData, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    });

    const accessToken = response.data.access_token;
    const userData: User = response.data.user;

    localStorage.setItem('careerai_access_token', accessToken);
    localStorage.setItem('careerai_user', JSON.stringify(userData));
    localStorage.setItem('careerai_role', userData.role.toLowerCase());

    setToken(accessToken);
    setUser(userData);

    return userData;
  };

  const register = async (payload: { email: string; password: string; full_name: string; role: UserRole }): Promise<User> => {
    const response = await api.post('/auth/register', payload);
    const registeredUser: User = response.data;
    // Automatically log in after registration
    await login(payload.email, payload.password);
    return registeredUser;
  };

  const logout = () => {
    localStorage.removeItem('careerai_access_token');
    localStorage.removeItem('careerai_user');
    localStorage.removeItem('careerai_role');
    setToken(null);
    setUser(null);
  };

  const refreshUser = async () => {
    return fetchUser();
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!token && !!user,
        isLoading,
        login,
        register,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
