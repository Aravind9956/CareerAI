import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to attach JWT token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('careerai_access_token');
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle global auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Clear token on 401 unauthorized
      const currentToken = localStorage.getItem('careerai_access_token');
      if (currentToken) {
        localStorage.removeItem('careerai_access_token');
        localStorage.removeItem('careerai_user');
        // Dispatch event so auth state updates gracefully
        window.dispatchEvent(new Event('careerai_auth_change'));
      }
    }
    return Promise.reject(error);
  }
);

export default api;
