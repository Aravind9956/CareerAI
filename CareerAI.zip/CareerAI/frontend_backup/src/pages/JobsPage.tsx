import React, { useCallback, useEffect, useState } from 'react';
import {
  Briefcase, Bookmark, BookmarkCheck, ChevronLeft, ChevronRight,
  Clock, Filter, LoaderCircle, MapPin, Search, Sparkles, X, CheckCircle2,
} from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

/* ── Types ───────────────────────────────────────────────────────────── */
interface Job {
  id: string;
  company_name: string;
  title: string;
  description: string;
  location: string | null;
  work_mode: string;
  job_type: string;
  required_skills: string[];
  preferred_skills: string[];
  salary_range: string | null;
  experience_requirement: string | null;
  education_requirement: string | null;
  application_deadline: string | null;
  openings: number;
  is_active: boolean;
  created_at: string;
}

interface JobListResponse {
  items: Job[];
  page: number;
  page_size: number;
  total: number;
  pages: number;
}

/* ── Helpers ─────────────────────────────────────────────────────────── */
function workModeBadge(mode: string) {
  if (mode === 'REMOTE') return 'badge-success';
  if (mode === 'HYBRID') return 'badge-warning';
  return 'badge-default';
}

function jobTypeBadge(type: string) {
  if (type === 'INTERNSHIP') return 'badge-accent';
  if (type === 'FULL_TIME') return 'badge-brand';
  return 'badge-default';
}

function fmtMode(m: string) { return m.charAt(0) + m.slice(1).toLowerCase(); }
function fmtType(t: string) { return t.replace('_', ' ').toLowerCase().replace(/^\w/, c => c.toUpperCase()); }
function timeAgo(dateStr: string) {
  const d = new Date(dateStr);
  const diff = Date.now() - d.getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 7) return `${days}d ago`;
  if (days < 30) return `${Math.floor(days / 7)}w ago`;
  return `${Math.floor(days / 30)}mo ago`;
}

/* ── Apply Modal ─────────────────────────────────────────────────────── */
function ApplyModal({ job, onClose, onApplied }: { job: Job; onClose: () => void; onApplied: () => void }) {
  const { success, error: toastError } = useToast();
  const [coverLetter, setCoverLetter] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleApply(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post(`/jobs/${job.id}/apply`, { cover_letter: coverLetter || null });
      success('Application submitted!', `Applied to ${job.title} at ${job.company_name}`);
      onApplied();
      onClose();
    } catch (err: unknown) {
      const msg = (() => {
        if (err && typeof err === 'object' && 'response' in err) {
          const r = (err as { response?: { data?: { detail?: string }; status?: number } }).response;
          if (r?.status === 409) return 'You have already applied to this job.';
          if (r?.data?.detail) return r.data.detail;
        }
        return 'Application failed. Please try again.';
      })();
      toastError('Application failed', msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-content">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem' }}>
          <div>
            <h3 style={{ marginBottom: '0.25rem' }}>Apply for {job.title}</h3>
            <p style={{ fontSize: '0.875rem', margin: 0 }}>{job.company_name}</p>
          </div>
          <button onClick={onClose} className="btn-ghost btn-sm" style={{ padding: '6px' }}><X size={18} /></button>
        </div>
        <form onSubmit={handleApply}>
          <div className="form-group" style={{ marginBottom: '1.5rem' }}>
            <label className="form-label">Cover letter <span style={{ fontWeight: 400, color: 'var(--text-muted)' }}>(optional)</span></label>
            <textarea
              className="input textarea"
              placeholder="Introduce yourself and explain why you're a great fit..."
              value={coverLetter}
              onChange={(e) => setCoverLetter(e.target.value)}
              rows={6}
              style={{ resize: 'vertical', lineHeight: '1.6' }}
            />
          </div>
          <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end' }}>
            <button type="button" onClick={onClose} className="btn btn-secondary">Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? <><LoaderCircle size={16} className="spin" /> Submitting…</> : 'Submit application'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ── Job Detail Panel ────────────────────────────────────────────────── */
function JobDetail({
  job, onClose, savedIds, onToggleSave, appliedIds, onApplied, isAuth,
}: {
  job: Job;
  onClose: () => void;
  savedIds: Set<string>;
  onToggleSave: (jobId: string) => void;
  appliedIds: Set<string>;
  onApplied: () => void;
  isAuth: boolean;
}) {
  const [applyOpen, setApplyOpen] = useState(false);
  const isSaved = savedIds.has(job.id);
  const isApplied = appliedIds.has(job.id);

  return (
    <aside style={{
      position: 'sticky', top: '5.5rem', background: 'var(--surface)',
      border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)',
      padding: '1.75rem', height: 'fit-content', maxHeight: '82vh', overflowY: 'auto',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.25rem' }}>
        <div>
          <h2 style={{ fontSize: '1.25rem', marginBottom: '0.375rem' }}>{job.title}</h2>
          <p style={{ fontWeight: 600, fontSize: '0.9375rem', color: 'var(--text-primary)', margin: '0 0 0.5rem' }}>{job.company_name}</p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
            <span className={`badge ${jobTypeBadge(job.job_type)}`}>{fmtType(job.job_type)}</span>
            <span className={`badge ${workModeBadge(job.work_mode)}`}>{fmtMode(job.work_mode)}</span>
          </div>
        </div>
        <button onClick={onClose} className="btn-ghost btn-sm" style={{ padding: '6px' }}><X size={18} /></button>
      </div>

      {/* Meta */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', marginBottom: '1.25rem', fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
        {job.location && <span style={{ display: 'flex', alignItems: 'center', gap: '0.375rem' }}><MapPin size={14} />{job.location}</span>}
        {job.salary_range && <span style={{ display: 'flex', alignItems: 'center', gap: '0.375rem' }}>💰 {job.salary_range}</span>}
        {job.experience_requirement && <span>📋 {job.experience_requirement}</span>}
        {job.education_requirement && <span>🎓 {job.education_requirement}</span>}
        {job.openings > 1 && <span>👥 {job.openings} openings</span>}
        <span style={{ display: 'flex', alignItems: 'center', gap: '0.375rem' }}><Clock size={14} /> Posted {timeAgo(job.created_at)}</span>
      </div>

      {/* Actions */}
      {isAuth && (
        <div style={{ display: 'flex', gap: '0.625rem', marginBottom: '1.5rem' }}>
          <button
            onClick={() => setApplyOpen(true)}
            className="btn btn-primary"
            disabled={isApplied}
            style={{ flex: 1, justifyContent: 'center' }}
          >
            {isApplied ? <><CheckCircle2 size={16} /> Applied</> : 'Apply now'}
          </button>
          <button
            onClick={() => onToggleSave(job.id)}
            className="btn btn-secondary"
            style={{ padding: '0.625rem 0.875rem' }}
            title={isSaved ? 'Unsave' : 'Save job'}
          >
            {isSaved ? <BookmarkCheck size={18} style={{ color: 'var(--accent)' }} /> : <Bookmark size={18} />}
          </button>
        </div>
      )}

      {/* Description */}
      <div style={{ marginBottom: '1.25rem' }}>
        <h4 style={{ marginBottom: '0.625rem', fontSize: '0.9375rem' }}>Description</h4>
        <p style={{ fontSize: '0.875rem', lineHeight: '1.7', whiteSpace: 'pre-wrap' }}>{job.description}</p>
      </div>

      {job.required_skills.length > 0 && (
        <div style={{ marginBottom: '1rem' }}>
          <h4 style={{ marginBottom: '0.5rem', fontSize: '0.9375rem' }}>Required skills</h4>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
            {job.required_skills.map((s) => <span key={s} className="badge badge-default">{s}</span>)}
          </div>
        </div>
      )}

      {job.preferred_skills.length > 0 && (
        <div>
          <h4 style={{ marginBottom: '0.5rem', fontSize: '0.9375rem' }}>Preferred skills</h4>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
            {job.preferred_skills.map((s) => <span key={s} className="badge badge-brand">{s}</span>)}
          </div>
        </div>
      )}

      {applyOpen && (
        <ApplyModal
          job={job}
          onClose={() => setApplyOpen(false)}
          onApplied={onApplied}
        />
      )}
    </aside>
  );
}

/* ── Job Card ────────────────────────────────────────────────────────── */
function JobCard({
  job, selected, onClick, savedIds, onToggleSave, appliedIds, isAuth,
}: {
  job: Job;
  selected: boolean;
  onClick: () => void;
  savedIds: Set<string>;
  onToggleSave: (jobId: string) => void;
  appliedIds: Set<string>;
  isAuth: boolean;
}) {
  const isSaved = savedIds.has(job.id);
  const isApplied = appliedIds.has(job.id);

  return (
    <article
      onClick={onClick}
      className="card card-hover"
      style={{
        cursor: 'pointer', padding: '1.25rem',
        border: selected ? '2px solid var(--primary)' : '1px solid var(--border)',
        borderRadius: 'var(--radius-lg)',
        background: selected ? 'var(--surface-muted)' : 'var(--surface)',
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
        <div style={{
          width: '2.5rem', height: '2.5rem', borderRadius: 'var(--radius-md)',
          background: 'var(--primary)', color: '#fff', display: 'flex',
          alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '1rem',
          flexShrink: 0,
        }}>
          {job.company_name.charAt(0).toUpperCase()}
        </div>
        <div style={{ display: 'flex', gap: '0.375rem' }}>
          {isApplied && <span className="badge badge-success"><CheckCircle2 size={11} /> Applied</span>}
          {isAuth && (
            <button
              onClick={(e) => { e.stopPropagation(); onToggleSave(job.id); }}
              className="btn-ghost"
              style={{ padding: '4px' }}
              title={isSaved ? 'Unsave' : 'Save'}
            >
              {isSaved
                ? <BookmarkCheck size={17} style={{ color: 'var(--accent)' }} />
                : <Bookmark size={17} style={{ color: 'var(--text-muted)' }} />}
            </button>
          )}
        </div>
      </div>
      <h3 style={{ fontSize: '1rem', marginBottom: '0.25rem' }}>{job.title}</h3>
      <p style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)', margin: '0 0 0.625rem' }}>{job.company_name}</p>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.375rem', marginBottom: '0.75rem' }}>
        <span className={`badge ${jobTypeBadge(job.job_type)}`}>{fmtType(job.job_type)}</span>
        <span className={`badge ${workModeBadge(job.work_mode)}`}>{fmtMode(job.work_mode)}</span>
        {job.location && (
          <span className="badge badge-default" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
            <MapPin size={10} />{job.location}
          </span>
        )}
      </div>
      <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', margin: '0 0 0.5rem', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
        {job.description}
      </p>
      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
        <Clock size={11} /> {timeAgo(job.created_at)}
        {job.salary_range && <><span>·</span> {job.salary_range}</>}
      </div>
    </article>
  );
}

/* ── Main Page ───────────────────────────────────────────────────────── */
export default function JobsPage() {
  const { isAuthenticated, user } = useAuth();
  const { success, error: toastError } = useToast();

  const [jobs, setJobs] = useState<Job[]>([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [q, setQ] = useState('');
  const [location, setLocation] = useState('');
  const [jobType, setJobType] = useState('');
  const [workMode, setWorkMode] = useState('');
  const [draftQ, setDraftQ] = useState('');

  const [selected, setSelected] = useState<Job | null>(null);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [appliedIds, setAppliedIds] = useState<Set<string>>(new Set());

  /* Load saved + applied when authenticated */
  useEffect(() => {
    if (!isAuthenticated || user?.role !== 'STUDENT') return;
    api.get('/saved-jobs').then((r) => setSavedIds(new Set(r.data.map((s: { job_id: string }) => s.job_id)))).catch(() => {});
    api.get('/applications/my').then((r) => setAppliedIds(new Set(r.data.map((a: { job_id: string }) => a.job_id)))).catch(() => {});
  }, [isAuthenticated, user]);

  /* Fetch jobs */
  const fetchJobs = useCallback(async (pageNum: number) => {
    setLoading(true); setError('');
    try {
      const params = new URLSearchParams();
      params.set('page', String(pageNum));
      params.set('page_size', '12');
      if (q) params.set('q', q);
      if (location) params.set('location', location);
      if (jobType) params.set('job_type', jobType);
      if (workMode) params.set('work_mode', workMode);
      const res = await api.get<JobListResponse>(`/jobs?${params.toString()}`);
      setJobs(res.data.items);
      setTotalPages(res.data.pages);
      setTotal(res.data.total);
    } catch {
      setError('Failed to load jobs. Make sure the backend is running.');
    } finally {
      setLoading(false);
    }
  }, [q, location, jobType, workMode]);

  useEffect(() => { fetchJobs(page); }, [fetchJobs, page]);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    setQ(draftQ);
    setPage(1);
  }

  function clearFilters() {
    setQ(''); setDraftQ(''); setLocation(''); setJobType(''); setWorkMode(''); setPage(1);
  }

  async function toggleSave(jobId: string) {
    if (!isAuthenticated) return;
    try {
      if (savedIds.has(jobId)) {
        await api.delete(`/jobs/${jobId}/save`);
        setSavedIds((prev) => { const n = new Set(prev); n.delete(jobId); return n; });
        success('Job removed', 'Removed from saved jobs');
      } else {
        await api.post(`/jobs/${jobId}/save`);
        setSavedIds((prev) => new Set([...prev, jobId]));
        success('Job saved!', 'Added to your saved jobs');
      }
    } catch {
      toastError('Action failed', 'Could not update saved jobs');
    }
  }

  const hasFilters = !!(q || location || jobType || workMode);

  return (
    <div>
      {/* Page header */}
      <div style={{ marginBottom: '2rem' }}>
        <p style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
          Discover opportunities
        </p>
        <h1 style={{ marginBottom: '0.5rem' }}>Find your next role</h1>
        <p style={{ color: 'var(--text-secondary)' }}>
          {total > 0 ? `${total} active position${total !== 1 ? 's' : ''} available` : 'Search the job board'}
        </p>
      </div>

      {/* Search bar */}
      <form onSubmit={handleSearch} style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: '1 1 300px' }}>
          <Search size={16} style={{ position: 'absolute', left: '0.875rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          <input
            className="input"
            placeholder='Search jobs, skills, companies…'
            value={draftQ}
            onChange={(e) => setDraftQ(e.target.value)}
            style={{ paddingLeft: '2.5rem' }}
          />
        </div>
        <input className="input" placeholder="Location" value={location} onChange={(e) => setLocation(e.target.value)} style={{ flex: '0 1 160px' }} />
        <select className="input select" value={jobType} onChange={(e) => { setJobType(e.target.value); setPage(1); }} style={{ flex: '0 1 160px' }}>
          <option value="">All types</option>
          <option value="INTERNSHIP">Internship</option>
          <option value="FULL_TIME">Full Time</option>
          <option value="PART_TIME">Part Time</option>
        </select>
        <select className="input select" value={workMode} onChange={(e) => { setWorkMode(e.target.value); setPage(1); }} style={{ flex: '0 1 140px' }}>
          <option value="">All modes</option>
          <option value="REMOTE">Remote</option>
          <option value="HYBRID">Hybrid</option>
          <option value="ONSITE">Onsite</option>
        </select>
        <button type="submit" className="btn btn-primary" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Filter size={15} /> Search
        </button>
        {hasFilters && (
          <button type="button" onClick={clearFilters} className="btn btn-secondary" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <X size={15} /> Clear
          </button>
        )}
      </form>

      {/* Main grid */}
      <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 420px' : '1fr', gap: '1.5rem', alignItems: 'start' }}>
        <div>
          {/* Loading */}
          {loading && (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '5rem', gap: '0.75rem', color: 'var(--text-muted)' }}>
              <LoaderCircle size={22} className="spin" /> Loading jobs…
            </div>
          )}

          {/* Error */}
          {!loading && error && (
            <div style={{ textAlign: 'center', padding: '4rem 2rem', color: 'var(--danger)' }}>
              <Briefcase size={40} style={{ marginBottom: '1rem', opacity: 0.4 }} />
              <p>{error}</p>
            </div>
          )}

          {/* Empty */}
          {!loading && !error && jobs.length === 0 && (
            <div style={{ textAlign: 'center', padding: '5rem 2rem', color: 'var(--text-muted)' }}>
              <Sparkles size={40} style={{ marginBottom: '1rem', opacity: 0.3 }} />
              <h3 style={{ color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>No jobs found</h3>
              <p style={{ fontSize: '0.875rem' }}>Try adjusting your search filters</p>
              {hasFilters && <button onClick={clearFilters} className="btn btn-secondary" style={{ marginTop: '1rem' }}>Clear filters</button>}
            </div>
          )}

          {/* Job list */}
          {!loading && !error && jobs.length > 0 && (
            <div style={{ display: 'grid', gap: '0.875rem' }}>
              {jobs.map((job) => (
                <JobCard
                  key={job.id}
                  job={job}
                  selected={selected?.id === job.id}
                  onClick={() => setSelected(selected?.id === job.id ? null : job)}
                  savedIds={savedIds}
                  onToggleSave={toggleSave}
                  appliedIds={appliedIds}
                  isAuth={isAuthenticated && user?.role === 'STUDENT'}
                />
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '1rem', marginTop: '2rem' }}>
              <button
                onClick={() => setPage((p) => p - 1)}
                disabled={page === 1}
                className="btn btn-secondary btn-sm"
                style={{ display: 'flex', alignItems: 'center', gap: '0.375rem' }}
              >
                <ChevronLeft size={16} /> Prev
              </button>
              <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                Page {page} of {totalPages}
              </span>
              <button
                onClick={() => setPage((p) => p + 1)}
                disabled={page === totalPages}
                className="btn btn-secondary btn-sm"
                style={{ display: 'flex', alignItems: 'center', gap: '0.375rem' }}
              >
                Next <ChevronRight size={16} />
              </button>
            </div>
          )}
        </div>

        {/* Detail panel */}
        {selected && (
          <JobDetail
            job={selected}
            onClose={() => setSelected(null)}
            savedIds={savedIds}
            onToggleSave={toggleSave}
            appliedIds={appliedIds}
            onApplied={() => setAppliedIds((prev) => new Set([...prev, selected.id]))}
            isAuth={isAuthenticated && user?.role === 'STUDENT'}
          />
        )}
      </div>
    </div>
  );
}
