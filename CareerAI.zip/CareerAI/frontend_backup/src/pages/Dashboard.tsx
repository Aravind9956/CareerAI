import { useEffect, useState } from 'react';
import { ArrowRight, BriefcaseBusiness, FileText, LoaderCircle, Target, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

type Job = {
  id: string;
  company_name: string;
  title: string;
  location: string | null;
  job_type: string;
  work_mode: string;
  is_active: boolean;
};

type StudentDashboard = {
  profile_completion: number;
  applications_total: number;
  applications_by_status: Record<string, number>;
  saved_jobs_count: number;
  current_resume_present: boolean;
  recommended_jobs: Job[];
};

type RecruiterDashboard = {
  company_name: string;
  active_jobs: number;
  total_applications: number;
  shortlisted_candidates: number;
  interviews: number;
  selected_candidates: number;
  recent_jobs: Job[];
};

type AdminDashboard = {
  total_users: number;
  total_students: number;
  total_recruiters: number;
  total_jobs: number;
  total_applications: number;
  active_jobs: number;
};

function Metric({ label, value, tone }: { label: string; value: string | number; tone: string }) {
  return (
    <article className={`dashboard-metric ${tone}`}>
      <span>{label}</span>
      <strong>{value}</strong>
    </article>
  );
}

function StudentView({ data }: { data: StudentDashboard }) {
  const chartData = Object.entries(data.applications_by_status).map(([status, count]) => ({
    status: status.charAt(0) + status.slice(1).toLowerCase(),
    count,
  }));

  return (
    <>
      <div className="dashboard-metrics">
        <Metric label="Profile complete" value={`${data.profile_completion}%`} tone="metric-peach" />
        <Metric label="Applications" value={data.applications_total} tone="metric-sage" />
        <Metric label="Saved jobs" value={data.saved_jobs_count} tone="metric-lilac" />
        <Metric label="Resume" value={data.current_resume_present ? 'Ready' : 'Missing'} tone="metric-cream" />
      </div>
      <div className="dashboard-columns">
        <section className="dashboard-card chart-card">
          <div className="dashboard-card-heading">
            <div>
              <p className="section-kicker">Application pulse</p>
              <h2>Keep your momentum visible</h2>
            </div>
            <Target size={20} />
          </div>
          <ResponsiveContainer width="100%" height={245}>
            <BarChart data={chartData} margin={{ top: 15, right: 12, left: -18, bottom: 5 }}>
              <CartesianGrid vertical={false} stroke="#e7ebe5" />
              <XAxis dataKey="status" tick={{ fill: '#8a9690', fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis allowDecimals={false} tick={{ fill: '#8a9690', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip cursor={{ fill: '#f3f5f0' }} />
              <Bar dataKey="count" fill="#2e5d4e" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </section>
        <section className="dashboard-card">
          <div className="dashboard-card-heading">
            <div>
              <p className="section-kicker">Next best step</p>
              <h2>{data.profile_completion < 100 ? 'Finish your profile' : 'Explore your matches'}</h2>
            </div>
            <FileText size={20} />
          </div>
          <p className="dashboard-copy">
            {data.profile_completion < 100
              ? 'A complete profile gives recruiters more context and helps CareerAI tailor your search.'
              : 'Your profile is ready. Browse active opportunities and keep your application history up to date.'}
          </p>
          {!data.current_resume_present && (
            <Link className="dashboard-action" to="/resumes" style={{ marginBottom: '0.75rem', display: 'flex' }}>
              Upload a resume <ArrowRight size={15} />
            </Link>
          )}
          <Link className="dashboard-action" to="/ai">
            AI career tools <ArrowRight size={15} />
          </Link>
        </section>
      </div>
      <section className="dashboard-card jobs-dashboard-card">
        <div className="dashboard-card-heading">
          <div>
            <p className="section-kicker">Fresh opportunities</p>
            <h2>Recently posted roles</h2>
          </div>
          <BriefcaseBusiness size={20} />
        </div>
        <div className="dashboard-job-list">
          {data.recommended_jobs.length
            ? data.recommended_jobs.map((job) => (
                <div className="dashboard-job" key={job.id}>
                  <div className="company-logo coral">{job.company_name.charAt(0)}</div>
                  <div>
                    <strong>{job.title}</strong>
                    <span>{job.company_name} · {job.location || job.work_mode}</span>
                  </div>
                  <span className="job-type-label">{job.job_type.replace('_', ' ')}</span>
                </div>
              ))
            : <p className="dashboard-copy" style={{ marginTop: '1rem' }}>No active roles are available yet.</p>
          }
        </div>
        <p className="ai-note">Recommendations are recent active listings, not guaranteed hiring outcomes.</p>
      </section>
    </>
  );
}

function RecruiterView({ data }: { data: RecruiterDashboard }) {
  return (
    <>
      <div className="dashboard-heading">
        <div>
          <p className="section-kicker">Recruiter workspace</p>
          <h1>{data.company_name || 'Your company'}</h1>
          <p className="dashboard-copy">A focused view of your hiring pipeline.</p>
        </div>
        <Users size={28} />
      </div>
      <div className="dashboard-metrics">
        <Metric label="Active jobs" value={data.active_jobs} tone="metric-sage" />
        <Metric label="Applications" value={data.total_applications} tone="metric-peach" />
        <Metric label="Shortlisted" value={data.shortlisted_candidates} tone="metric-lilac" />
        <Metric label="Selected" value={data.selected_candidates} tone="metric-cream" />
      </div>
      <section className="dashboard-card jobs-dashboard-card">
        <div className="dashboard-card-heading">
          <div>
            <p className="section-kicker">Your listings</p>
            <h2>Recent job activity</h2>
          </div>
          <BriefcaseBusiness size={20} />
        </div>
        {data.recent_jobs.length === 0
          ? <p className="dashboard-copy" style={{ marginTop: '1rem' }}>No job listings yet.</p>
          : data.recent_jobs.map((job) => (
              <div className="dashboard-job" key={job.id}>
                <div className="company-logo navy">{job.title.charAt(0)}</div>
                <div>
                  <strong>{job.title}</strong>
                  <span>{job.location || job.work_mode} · {job.job_type.replace('_', ' ')}</span>
                </div>
                <span className="job-type-label">{job.is_active ? 'Active' : 'Closed'}</span>
              </div>
            ))
        }
      </section>
    </>
  );
}

function AdminView({ data }: { data: AdminDashboard }) {
  return (
    <>
      <div className="dashboard-heading">
        <div>
          <p className="section-kicker">Administration</p>
          <h1>Platform overview</h1>
          <p className="dashboard-copy">High-level system metrics.</p>
        </div>
      </div>
      <div className="dashboard-metrics">
        <Metric label="Total users" value={data.total_users} tone="metric-peach" />
        <Metric label="Students" value={data.total_students} tone="metric-sage" />
        <Metric label="Recruiters" value={data.total_recruiters} tone="metric-lilac" />
        <Metric label="Active jobs" value={data.active_jobs} tone="metric-cream" />
      </div>
      <div className="dashboard-metrics" style={{ marginTop: '0.875rem' }}>
        <Metric label="Total jobs" value={data.total_jobs} tone="metric-sage" />
        <Metric label="Applications" value={data.total_applications} tone="metric-peach" />
      </div>
    </>
  );
}

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const role = user?.role?.toLowerCase() ?? 'student';
  const [data, setData] = useState<StudentDashboard | RecruiterDashboard | AdminDashboard | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isAuthenticated) { setLoading(false); return; }
    api.get(`/dashboards/${role}`)
      .then((res) => setData(res.data))
      .catch(() => setError('We could not load your dashboard right now. Please refresh the page.'))
      .finally(() => setLoading(false));
  }, [isAuthenticated, role]);

  if (!isAuthenticated) {
    return (
      <div className="dashboard-empty">
        <h1>Sign in to view your dashboard</h1>
        <p>Use the Sign In button in the navigation bar.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="dashboard-empty">
        <LoaderCircle className="spin" size={26} />
        <p>Loading your workspace…</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="dashboard-empty">
        <h1 style={{ color: '#b75f4d' }}>{error}</h1>
        <p>Make sure the backend is running at http://127.0.0.1:8000</p>
      </div>
    );
  }

  return (
    <section className="dashboard-content" style={{ paddingTop: 0 }}>
      {role === 'recruiter' && data && <RecruiterView data={data as RecruiterDashboard} />}
      {role === 'admin' && data && <AdminView data={data as AdminDashboard} />}
      {role === 'student' && data && <StudentView data={data as StudentDashboard} />}
    </section>
  );
}
