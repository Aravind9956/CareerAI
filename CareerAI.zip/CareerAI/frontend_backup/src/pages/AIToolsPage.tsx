import React, { useEffect, useState } from 'react';
import {
  Sparkles, FileSearch, Target, BookOpen, MessageSquare, LoaderCircle,
  AlertCircle, CheckCircle2, ChevronDown, ChevronUp,
} from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

/* ── Types ───────────────────────────────────────────────────────────── */
interface Resume { id: string; file_name: string; is_current: boolean; }
interface Job { id: string; title: string; company_name: string; }

interface SkillAnalysis { name: string; strength: string; }
interface ResumeAnalysisResult {
  overall_score: number;
  skills: SkillAnalysis[];
  strengths: string[];
  weaknesses: string[];
  missing_skills: string[];
  improvement_suggestions: string[];
  ats_feedback: string[];
}

interface JobMatchResult {
  score: number;
  matched_skills: string[];
  skill_gaps: string[];
  explanation: string;
  is_estimate: boolean;
}

interface SkillGapResult {
  your_skills: string[];
  skills_to_develop: string[];
  learning_path: string[];
  explanation: string;
  is_guidance: boolean;
}

interface InterviewContent {
  technical_questions: string[];
  project_questions: string[];
  hr_questions: string[];
  behavioral_questions: string[];
  role_specific_questions: string[];
}

interface FeedbackResult {
  relevance: number;
  completeness: number;
  technical_accuracy: number;
  communication: number;
  feedback: string[];
  is_coaching: boolean;
}

/* ── Shared helpers ──────────────────────────────────────────────────── */
type TabId = 'analysis' | 'matching' | 'skill-gap' | 'interview';

const TABS: { id: TabId; label: string; icon: React.ReactNode }[] = [
  { id: 'analysis',   label: 'Resume Analysis', icon: <FileSearch size={16} /> },
  { id: 'matching',   label: 'Job Match',        icon: <Target size={16} /> },
  { id: 'skill-gap',  label: 'Skill Gap',        icon: <BookOpen size={16} /> },
  { id: 'interview',  label: 'Interview Prep',   icon: <MessageSquare size={16} /> },
];

function ScoreBar({ label, value }: { label: string; value: number }) {
  const color = value >= 70 ? 'var(--success)' : value >= 40 ? 'var(--warning)' : 'var(--danger)';
  return (
    <div style={{ marginBottom: '0.875rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.875rem', marginBottom: '0.375rem' }}>
        <span style={{ color: 'var(--text-secondary)' }}>{label}</span>
        <span style={{ fontWeight: 700, color }}>{value}</span>
      </div>
      <div style={{ height: '6px', background: 'var(--surface-muted)', borderRadius: '99px', overflow: 'hidden' }}>
        <div style={{ height: '100%', width: `${value}%`, background: color, borderRadius: '99px', transition: 'width 0.6s ease' }} />
      </div>
    </div>
  );
}

function SkillChips({ skills, variant }: { skills: string[]; variant?: 'gap' | 'match' | 'default' }) {
  const bg = variant === 'gap' ? 'var(--danger-light)' : variant === 'match' ? 'var(--success-light)' : 'var(--surface-muted)';
  const color = variant === 'gap' ? 'var(--danger)' : variant === 'match' ? 'var(--success)' : 'var(--text-secondary)';
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.375rem' }}>
      {skills.map((s) => (
        <span key={s} style={{ padding: '0.25rem 0.625rem', background: bg, color, borderRadius: '99px', fontSize: '0.8125rem', fontWeight: 500 }}>
          {s}
        </span>
      ))}
    </div>
  );
}

function SectionCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="card" style={{ marginBottom: '1rem' }}>
      <h4 style={{ marginBottom: '1rem', fontSize: '0.9375rem' }}>{title}</h4>
      {children}
    </div>
  );
}

/* ── Resume Analysis Tab ─────────────────────────────────────────────── */
function ResumeAnalysisTab({ resumes }: { resumes: Resume[] }) {
  const { error: toastError } = useToast();
  const [resumeId, setResumeId] = useState(resumes.find((r) => r.is_current)?.id ?? resumes[0]?.id ?? '');
  const [jobDesc, setJobDesc] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ResumeAnalysisResult | null>(null);
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!resumeId) { setError('Select a resume first.'); return; }
    setLoading(true); setError(''); setResult(null);
    try {
      const res = await api.post('/ai/resume-analysis', { resume_id: resumeId, target_job_description: jobDesc || null });
      setResult(res.data.result);
    } catch (err: unknown) {
      const msg = (err && typeof err === 'object' && 'response' in err)
        ? ((err as { response?: { data?: { detail?: string } } }).response?.data?.detail ?? 'Analysis failed.')
        : 'Analysis failed. The resume may not have extractable text.';
      setError(msg);
      toastError('Analysis failed', msg);
    } finally {
      setLoading(false);
    }
  }

  if (resumes.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
        <FileSearch size={36} style={{ marginBottom: '1rem', opacity: 0.3 }} />
        <h3 style={{ color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>No resumes found</h3>
        <p style={{ fontSize: '0.875rem' }}>Upload a PDF resume in the Resumes section first.</p>
      </div>
    );
  }

  return (
    <div>
      <p style={{ marginBottom: '1.5rem', fontSize: '0.875rem' }}>
        Get structured AI feedback on your resume — clarity, strengths, ATS readiness, and skill gaps against a target role.
        <span style={{ display: 'block', color: 'var(--text-muted)', fontSize: '0.8125rem', marginTop: '0.25rem' }}>
          Results are estimates and guidance only, not hiring decisions.
        </span>
      </p>
      <form onSubmit={handleSubmit} style={{ marginBottom: result ? '2rem' : 0 }}>
        <div className="form-group">
          <label className="form-label" htmlFor="ra-resume">Resume</label>
          <select id="ra-resume" className="input select" value={resumeId} onChange={(e) => setResumeId(e.target.value)}>
            {resumes.map((r) => (
              <option key={r.id} value={r.id}>{r.file_name}{r.is_current ? ' (current)' : ''}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label className="form-label" htmlFor="ra-jobdesc">
            Target job description <span style={{ fontWeight: 400, color: 'var(--text-muted)' }}>(optional)</span>
          </label>
          <textarea
            id="ra-jobdesc"
            className="input textarea"
            placeholder="Paste a job description to identify relevant gaps…"
            value={jobDesc}
            onChange={(e) => setJobDesc(e.target.value)}
            rows={5}
            style={{ resize: 'vertical', lineHeight: '1.6' }}
          />
        </div>
        {error && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.75rem 1rem', background: 'var(--danger-light)', borderRadius: 'var(--radius-md)', marginBottom: '1rem', fontSize: '0.875rem', color: 'var(--danger)' }}>
            <AlertCircle size={15} /> {error}
          </div>
        )}
        <button type="submit" className="btn btn-primary" disabled={loading} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          {loading ? <><LoaderCircle size={16} className="spin" /> Analyzing…</> : <><Sparkles size={16} /> Analyze resume</>}
        </button>
      </form>

      {result && (
        <div>
          {/* Score */}
          <div style={{ background: 'var(--primary)', color: '#fff', borderRadius: 'var(--radius-lg)', padding: '1.75rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '3.5rem', fontWeight: 800, lineHeight: 1, letterSpacing: '-2px' }}>{result.overall_score}</div>
              <div style={{ fontSize: '0.8125rem', opacity: 0.7 }}>/100</div>
            </div>
            <div>
              <p style={{ color: '#e2e8f0', margin: '0 0 0.25rem', fontWeight: 600 }}>Resume quality estimate</p>
              <p style={{ color: '#94a3b8', margin: 0, fontSize: '0.8125rem' }}>AI-generated. Not a definitive assessment.</p>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem', marginBottom: '1rem' }}>
            <SectionCard title="Detected skills">
              <SkillChips skills={result.skills.map((s) => `${s.name} (${s.strength})`)} />
            </SectionCard>
            {result.missing_skills.length > 0 && (
              <SectionCard title="Skill gaps for this role">
                <SkillChips skills={result.missing_skills} variant="gap" />
              </SectionCard>
            )}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem' }}>
            <SectionCard title="Strengths">
              {result.strengths.map((s) => <p key={s} style={{ fontSize: '0.875rem', margin: '0 0 0.375rem', display: 'flex', gap: '0.5rem' }}><CheckCircle2 size={14} style={{ color: 'var(--success)', flexShrink: 0, marginTop: '2px' }} />{s}</p>)}
            </SectionCard>
            <SectionCard title="Suggestions">
              {result.improvement_suggestions.map((s) => <p key={s} style={{ fontSize: '0.875rem', margin: '0 0 0.375rem' }}>• {s}</p>)}
            </SectionCard>
          </div>
          {result.ats_feedback.length > 0 && (
            <SectionCard title="ATS feedback">
              {result.ats_feedback.map((s) => <p key={s} style={{ fontSize: '0.875rem', margin: '0 0 0.375rem' }}>• {s}</p>)}
            </SectionCard>
          )}
        </div>
      )}
    </div>
  );
}

/* ── Job Match Tab ───────────────────────────────────────────────────── */
function JobMatchTab({ resumes, jobs }: { resumes: Resume[]; jobs: Job[] }) {
  const { error: toastError } = useToast();
  const [resumeId, setResumeId] = useState(resumes.find((r) => r.is_current)?.id ?? resumes[0]?.id ?? '');
  const [jobId, setJobId] = useState(jobs[0]?.id ?? '');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<JobMatchResult | null>(null);
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!resumeId || !jobId) { setError('Select both a resume and a job.'); return; }
    setLoading(true); setError(''); setResult(null);
    try {
      const res = await api.post('/ai/job-match', { job_id: jobId, resume_id: resumeId });
      setResult(res.data);
    } catch (err: unknown) {
      const msg = (err && typeof err === 'object' && 'response' in err)
        ? ((err as { response?: { data?: { detail?: string } } }).response?.data?.detail ?? 'Matching failed.')
        : 'Job match failed. Please try again.';
      setError(msg);
      toastError('Match failed', msg);
    } finally {
      setLoading(false);
    }
  }

  const noData = resumes.length === 0 || jobs.length === 0;
  if (noData) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
        <Target size={36} style={{ marginBottom: '1rem', opacity: 0.3 }} />
        <h3 style={{ color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>Setup needed</h3>
        <p style={{ fontSize: '0.875rem' }}>Upload a resume and make sure at least one job is available in the system.</p>
      </div>
    );
  }

  return (
    <div>
      <p style={{ marginBottom: '1.5rem', fontSize: '0.875rem' }}>
        Match your resume against a specific job to see your compatibility score, matched skills, and gaps.
        <span style={{ display: 'block', color: 'var(--text-muted)', fontSize: '0.8125rem', marginTop: '0.25rem' }}>
          Scores are estimates and not predictors of hiring outcomes.
        </span>
      </p>
      <form onSubmit={handleSubmit} style={{ marginBottom: result ? '2rem' : 0 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1rem' }}>
          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label" htmlFor="jm-resume">Resume</label>
            <select id="jm-resume" className="input select" value={resumeId} onChange={(e) => setResumeId(e.target.value)}>
              {resumes.map((r) => <option key={r.id} value={r.id}>{r.file_name}{r.is_current ? ' (current)' : ''}</option>)}
            </select>
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label" htmlFor="jm-job">Job</label>
            <select id="jm-job" className="input select" value={jobId} onChange={(e) => setJobId(e.target.value)}>
              {jobs.map((j) => <option key={j.id} value={j.id}>{j.title} — {j.company_name}</option>)}
            </select>
          </div>
        </div>
        {error && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.75rem 1rem', background: 'var(--danger-light)', borderRadius: 'var(--radius-md)', margin: '1rem 0', fontSize: '0.875rem', color: 'var(--danger)' }}>
            <AlertCircle size={15} /> {error}
          </div>
        )}
        <button type="submit" className="btn btn-primary" disabled={loading} style={{ marginTop: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          {loading ? <><LoaderCircle size={16} className="spin" /> Matching…</> : <><Target size={16} /> Match now</>}
        </button>
      </form>

      {result && (
        <div>
          <div style={{ background: 'var(--primary)', color: '#fff', borderRadius: 'var(--radius-lg)', padding: '1.75rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '3.5rem', fontWeight: 800, lineHeight: 1, letterSpacing: '-2px' }}>{Math.round(result.score * 100)}</div>
              <div style={{ fontSize: '0.8125rem', opacity: 0.7 }}>/ 100</div>
            </div>
            <div>
              <p style={{ color: '#e2e8f0', margin: '0 0 0.375rem', fontWeight: 600 }}>Match score</p>
              <p style={{ color: '#94a3b8', margin: 0, fontSize: '0.8125rem' }}>{result.explanation}</p>
              {result.is_estimate && <p style={{ color: '#64748b', margin: '0.25rem 0 0', fontSize: '0.75rem' }}>Estimate only. Not a hiring prediction.</p>}
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
            {result.matched_skills.length > 0 && (
              <SectionCard title="Matched skills">
                <SkillChips skills={result.matched_skills} variant="match" />
              </SectionCard>
            )}
            {result.skill_gaps.length > 0 && (
              <SectionCard title="Skills to develop">
                <SkillChips skills={result.skill_gaps} variant="gap" />
              </SectionCard>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Skill Gap Tab ───────────────────────────────────────────────────── */
function SkillGapTab({ resumes, jobs }: { resumes: Resume[]; jobs: Job[] }) {
  const { error: toastError } = useToast();
  const [resumeId, setResumeId] = useState(resumes.find((r) => r.is_current)?.id ?? resumes[0]?.id ?? '');
  const [jobId, setJobId] = useState(jobs[0]?.id ?? '');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SkillGapResult | null>(null);
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!jobId) { setError('Select a job.'); return; }
    setLoading(true); setError(''); setResult(null);
    try {
      const res = await api.post('/ai/skill-gap', { job_id: jobId, resume_id: resumeId || null });
      setResult(res.data);
    } catch (err: unknown) {
      const msg = (err && typeof err === 'object' && 'response' in err)
        ? ((err as { response?: { data?: { detail?: string } } }).response?.data?.detail ?? 'Analysis failed.')
        : 'Skill gap analysis failed.';
      setError(msg);
      toastError('Analysis failed', msg);
    } finally {
      setLoading(false);
    }
  }

  if (jobs.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
        <BookOpen size={36} style={{ marginBottom: '1rem', opacity: 0.3 }} />
        <p>No jobs available to analyze. Browse the job board first.</p>
      </div>
    );
  }

  return (
    <div>
      <p style={{ marginBottom: '1.5rem', fontSize: '0.875rem' }}>
        Compare your current skills against a job's requirements and get an ordered learning path.
        <span style={{ display: 'block', color: 'var(--text-muted)', fontSize: '0.8125rem', marginTop: '0.25rem' }}>
          This is guidance for planning — not a definitive assessment.
        </span>
      </p>
      <form onSubmit={handleSubmit} style={{ marginBottom: result ? '2rem' : 0 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1rem' }}>
          {resumes.length > 0 && (
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label" htmlFor="sg-resume">Resume <span style={{ fontWeight: 400, color: 'var(--text-muted)' }}>(optional)</span></label>
              <select id="sg-resume" className="input select" value={resumeId} onChange={(e) => setResumeId(e.target.value)}>
                <option value="">No resume</option>
                {resumes.map((r) => <option key={r.id} value={r.id}>{r.file_name}{r.is_current ? ' (current)' : ''}</option>)}
              </select>
            </div>
          )}
          <div className="form-group" style={{ margin: 0 }}>
            <label className="form-label" htmlFor="sg-job">Job to analyze</label>
            <select id="sg-job" className="input select" value={jobId} onChange={(e) => setJobId(e.target.value)}>
              {jobs.map((j) => <option key={j.id} value={j.id}>{j.title} — {j.company_name}</option>)}
            </select>
          </div>
        </div>
        {error && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.75rem 1rem', background: 'var(--danger-light)', borderRadius: 'var(--radius-md)', margin: '1rem 0', fontSize: '0.875rem', color: 'var(--danger)' }}>
            <AlertCircle size={15} /> {error}
          </div>
        )}
        <button type="submit" className="btn btn-primary" disabled={loading} style={{ marginTop: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          {loading ? <><LoaderCircle size={16} className="spin" /> Analyzing…</> : <><BookOpen size={16} /> Analyze gap</>}
        </button>
      </form>

      {result && (
        <div>
          <p style={{ fontSize: '0.875rem', marginBottom: '1rem', lineHeight: '1.6' }}>{result.explanation}</p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem', marginBottom: '1rem' }}>
            {result.your_skills.length > 0 && (
              <SectionCard title="Your current skills">
                <SkillChips skills={result.your_skills} variant="match" />
              </SectionCard>
            )}
            {result.skills_to_develop.length > 0 && (
              <SectionCard title="Skills to develop">
                <SkillChips skills={result.skills_to_develop} variant="gap" />
              </SectionCard>
            )}
          </div>
          {result.learning_path.length > 0 && (
            <SectionCard title="Learning path">
              <ol style={{ paddingLeft: '1.25rem', margin: 0 }}>
                {result.learning_path.map((step, i) => (
                  <li key={i} style={{ fontSize: '0.875rem', lineHeight: '1.6', marginBottom: '0.5rem', color: 'var(--text-secondary)' }}>{step}</li>
                ))}
              </ol>
            </SectionCard>
          )}
          {result.is_guidance && (
            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.5rem' }}>
              This learning path is guidance for planning, not a definitive assessment.
            </p>
          )}
        </div>
      )}
    </div>
  );
}

/* ── Interview Prep Tab ──────────────────────────────────────────────── */
function InterviewPrepTab({ jobs }: { jobs: Job[] }) {
  const { error: toastError } = useToast();
  const [jobId, setJobId] = useState(jobs[0]?.id ?? '');
  const [loading, setLoading] = useState(false);
  const [content, setContent] = useState<InterviewContent | null>(null);
  const [error, setError] = useState('');
  const [openSection, setOpenSection] = useState<string | null>(null);

  // Feedback state
  const [fbQuestion, setFbQuestion] = useState('');
  const [fbAnswer, setFbAnswer] = useState('');
  const [fbCategory, setFbCategory] = useState<'technical' | 'project' | 'hr' | 'behavioral' | 'role_specific'>('technical');
  const [fbLoading, setFbLoading] = useState(false);
  const [fbResult, setFbResult] = useState<FeedbackResult | null>(null);
  const [fbError, setFbError] = useState('');

  async function handleGenerate(e: React.FormEvent) {
    e.preventDefault();
    if (!jobId) { setError('Select a job.'); return; }
    setLoading(true); setError(''); setContent(null); setFbResult(null);
    try {
      const res = await api.post('/ai/interview', { job_id: jobId });
      setContent(res.data.content);
      setOpenSection('technical_questions');
    } catch (err: unknown) {
      const msg = (err && typeof err === 'object' && 'response' in err)
        ? ((err as { response?: { data?: { detail?: string } } }).response?.data?.detail ?? 'Generation failed.')
        : 'Interview prep generation failed.';
      setError(msg);
      toastError('Generation failed', msg);
    } finally {
      setLoading(false);
    }
  }

  async function handleFeedback(e: React.FormEvent) {
    e.preventDefault();
    if (!fbQuestion.trim() || !fbAnswer.trim()) { setFbError('Both question and answer are required.'); return; }
    setFbLoading(true); setFbError(''); setFbResult(null);
    try {
      const res = await api.post('/ai/interview/feedback', { question: fbQuestion, answer: fbAnswer, category: fbCategory });
      setFbResult(res.data);
    } catch {
      setFbError('Feedback request failed. Please try again.');
    } finally {
      setFbLoading(false);
    }
  }

  const SECTIONS: { key: keyof InterviewContent; label: string }[] = [
    { key: 'technical_questions', label: 'Technical' },
    { key: 'project_questions', label: 'Project' },
    { key: 'hr_questions', label: 'HR' },
    { key: 'behavioral_questions', label: 'Behavioral' },
    { key: 'role_specific_questions', label: 'Role-specific' },
  ];

  if (jobs.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
        <MessageSquare size={36} style={{ marginBottom: '1rem', opacity: 0.3 }} />
        <p>No jobs available. Browse the job board first.</p>
      </div>
    );
  }

  return (
    <div>
      <p style={{ marginBottom: '1.5rem', fontSize: '0.875rem' }}>
        Generate structured interview questions for a job, then practice your answers and get AI coaching.
        <span style={{ display: 'block', color: 'var(--text-muted)', fontSize: '0.8125rem', marginTop: '0.25rem' }}>
          Feedback is coaching support — not a definitive evaluation.
        </span>
      </p>
      <form onSubmit={handleGenerate} style={{ marginBottom: '1.5rem' }}>
        <div className="form-group">
          <label className="form-label" htmlFor="ip-job">Job to prepare for</label>
          <select id="ip-job" className="input select" value={jobId} onChange={(e) => setJobId(e.target.value)}>
            {jobs.map((j) => <option key={j.id} value={j.id}>{j.title} — {j.company_name}</option>)}
          </select>
        </div>
        {error && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.75rem 1rem', background: 'var(--danger-light)', borderRadius: 'var(--radius-md)', marginBottom: '1rem', fontSize: '0.875rem', color: 'var(--danger)' }}>
            <AlertCircle size={15} /> {error}
          </div>
        )}
        <button type="submit" className="btn btn-primary" disabled={loading} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          {loading ? <><LoaderCircle size={16} className="spin" /> Generating…</> : <><MessageSquare size={16} /> Generate questions</>}
        </button>
      </form>

      {/* Questions accordion */}
      {content && (
        <div style={{ marginBottom: '2rem' }}>
          <h4 style={{ marginBottom: '1rem' }}>Interview questions</h4>
          {SECTIONS.map(({ key, label }) => {
            const qs = content[key];
            if (!qs || qs.length === 0) return null;
            const isOpen = openSection === key;
            return (
              <div key={key} style={{ marginBottom: '0.5rem', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', overflow: 'hidden' }}>
                <button
                  type="button"
                  onClick={() => setOpenSection(isOpen ? null : key)}
                  style={{
                    width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    padding: '0.875rem 1.125rem', background: isOpen ? 'var(--surface-muted)' : 'var(--surface)',
                    border: 'none', cursor: 'pointer', fontWeight: 600, fontSize: '0.9375rem', color: 'var(--text-primary)',
                  }}
                >
                  {label} <span style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-muted)', fontWeight: 400, fontSize: '0.875rem' }}>
                    {qs.length} questions {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </span>
                </button>
                {isOpen && (
                  <div style={{ padding: '0.875rem 1.125rem', background: 'var(--surface)' }}>
                    <ol style={{ paddingLeft: '1.25rem', margin: 0 }}>
                      {qs.map((q, i) => (
                        <li
                          key={i}
                          style={{ fontSize: '0.875rem', lineHeight: '1.7', marginBottom: '0.625rem', cursor: 'pointer', color: 'var(--text-secondary)' }}
                          onClick={() => setFbQuestion(q)}
                          title="Click to use for feedback"
                        >
                          {q}
                        </li>
                      ))}
                    </ol>
                    <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.25rem' }}>Click a question to use it for answer feedback below.</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Feedback form */}
      <div className="card" style={{ marginTop: content ? 0 : 0 }}>
        <h4 style={{ marginBottom: '1rem' }}>Practice your answer</h4>
        <form onSubmit={handleFeedback}>
          <div className="form-group">
            <label className="form-label" htmlFor="fb-q">Question</label>
            <textarea
              id="fb-q"
              className="input textarea"
              placeholder="Enter or paste an interview question…"
              value={fbQuestion}
              onChange={(e) => setFbQuestion(e.target.value)}
              rows={2}
              style={{ resize: 'vertical' }}
            />
          </div>
          <div className="form-group">
            <label className="form-label" htmlFor="fb-cat">Category</label>
            <select id="fb-cat" className="input select" value={fbCategory} onChange={(e) => setFbCategory(e.target.value as typeof fbCategory)}>
              <option value="technical">Technical</option>
              <option value="project">Project</option>
              <option value="hr">HR</option>
              <option value="behavioral">Behavioral</option>
              <option value="role_specific">Role-specific</option>
            </select>
          </div>
          <div className="form-group">
            <label className="form-label" htmlFor="fb-a">Your answer</label>
            <textarea
              id="fb-a"
              className="input textarea"
              placeholder="Write your answer here…"
              value={fbAnswer}
              onChange={(e) => setFbAnswer(e.target.value)}
              rows={5}
              style={{ resize: 'vertical', lineHeight: '1.6' }}
            />
          </div>
          {fbError && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.75rem 1rem', background: 'var(--danger-light)', borderRadius: 'var(--radius-md)', marginBottom: '1rem', fontSize: '0.875rem', color: 'var(--danger)' }}>
              <AlertCircle size={15} /> {fbError}
            </div>
          )}
          <button type="submit" className="btn btn-primary" disabled={fbLoading} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            {fbLoading ? <><LoaderCircle size={16} className="spin" /> Getting feedback…</> : <><Sparkles size={16} /> Get feedback</>}
          </button>
        </form>

        {fbResult && (
          <div style={{ marginTop: '1.5rem' }}>
            <h4 style={{ marginBottom: '1rem' }}>Coaching feedback</h4>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.875rem', marginBottom: '1.25rem' }}>
              <ScoreBar label="Relevance" value={fbResult.relevance} />
              <ScoreBar label="Completeness" value={fbResult.completeness} />
              <ScoreBar label="Technical accuracy" value={fbResult.technical_accuracy} />
              <ScoreBar label="Communication" value={fbResult.communication} />
            </div>
            {fbResult.feedback.map((f, i) => (
              <p key={i} style={{ fontSize: '0.875rem', lineHeight: '1.6', margin: '0 0 0.5rem', padding: '0.75rem 1rem', background: 'var(--surface-muted)', borderRadius: 'var(--radius-md)' }}>
                {f}
              </p>
            ))}
            {fbResult.is_coaching && (
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.5rem' }}>
                This feedback is coaching support and not a definitive evaluation.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Main Page ───────────────────────────────────────────────────────── */
export default function AIToolsPage() {
  const [activeTab, setActiveTab] = useState<TabId>('analysis');
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/resumes').catch(() => ({ data: [] })),
      api.get('/jobs?page=1&page_size=50').catch(() => ({ data: { items: [] } })),
    ]).then(([resumeRes, jobRes]) => {
      setResumes(resumeRes.data as Resume[]);
      setJobs((jobRes.data as { items: Job[] }).items ?? []);
    }).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div style={{ marginBottom: '2rem' }}>
        <p style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--accent)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
          AI-powered tools
        </p>
        <h1 style={{ marginBottom: '0.5rem' }}>Career AI</h1>
        <p style={{ color: 'var(--text-secondary)' }}>
          Resume analysis, job matching, skill gap guidance, and interview preparation — all in one place.
        </p>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '0.375rem', marginBottom: '2rem', flexWrap: 'wrap', borderBottom: '1px solid var(--border)', paddingBottom: '0' }}>
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              display: 'flex', alignItems: 'center', gap: '0.5rem',
              padding: '0.625rem 1rem', border: 'none', background: 'none', cursor: 'pointer',
              fontWeight: activeTab === tab.id ? 700 : 500,
              color: activeTab === tab.id ? 'var(--text-primary)' : 'var(--text-secondary)',
              fontSize: '0.9375rem',
              borderBottom: activeTab === tab.id ? '2px solid var(--primary)' : '2px solid transparent',
              marginBottom: '-1px',
              transition: 'all 0.15s',
            }}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '3rem', color: 'var(--text-muted)' }}>
          <LoaderCircle size={22} className="spin" /> Loading…
        </div>
      ) : (
        <div style={{ maxWidth: '860px' }}>
          {activeTab === 'analysis'  && <ResumeAnalysisTab resumes={resumes} />}
          {activeTab === 'matching'  && <JobMatchTab resumes={resumes} jobs={jobs} />}
          {activeTab === 'skill-gap' && <SkillGapTab resumes={resumes} jobs={jobs} />}
          {activeTab === 'interview' && <InterviewPrepTab jobs={jobs} />}
        </div>
      )}
    </div>
  );
}
