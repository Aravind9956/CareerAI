import { BrowserRouter, Link, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { ArrowRight, Bell, BriefcaseBusiness, Check, FileText, Search, Sparkles, Target } from 'lucide-react';
import './App.css';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import Dashboard from './pages/Dashboard';
import JobsPage from './pages/JobsPage';
import ProfilePage from './pages/ProfilePage';
import ResumesPage from './pages/ResumesPage';
import ApplicationsPage from './pages/ApplicationsPage';
import SavedJobsPage from './pages/SavedJobsPage';
import NotificationsPage from './pages/NotificationsPage';
import AIToolsPage from './pages/AIToolsPage';

/* ── Landing page (preserved from original) ─────────────────────────── */
function Landing() {
  return (
    <main className="app-shell">
      <section className="hero-section" id="discover">
        <div className="hero-copy">
          <p className="eyebrow"><span className="eyebrow-dot" /> Your next chapter starts here</p>
          <h1>Find work that<br /><em>moves you forward.</em></h1>
          <p className="hero-description">
            CareerAI brings the right opportunities, tools, and momentum together so you can build a career with intention.
          </p>
          <Link className="primary-button" to="/jobs">
            Explore opportunities <ArrowRight size={17} />
          </Link>
        </div>
        <div className="hero-visual">
          <div className="orbit orbit-one" />
          <div className="orbit orbit-two" />
          <div className="visual-card match-card">
            <div className="card-label"><Target size={15} /> AI match</div>
            <strong>92<span>%</span></strong>
            <p>Product Design Intern</p>
            <div className="match-line"><span /><span /><span /><span /></div>
          </div>
          <div className="visual-card profile-card">
            <div className="mini-avatar">JD</div>
            <div>
              <strong>Your profile</strong>
              <p>Ready to match</p>
            </div>
            <Check size={16} className="check-icon" />
          </div>
          <div className="visual-note"><Sparkles size={15} /><span>Matched to your strengths</span></div>
        </div>
      </section>

      <section className="dashboard-preview" id="applications">
        <div className="preview-header">
          <div>
            <p className="section-kicker">Your workspace</p>
            <h2>A clearer path to your next role</h2>
          </div>
          <Link className="outline-button" to="/dashboard">View dashboard <ArrowRight size={15} /></Link>
        </div>
        <div className="preview-grid">
          <article className="preview-panel search-panel">
            <div className="panel-icon peach"><Search size={19} /></div>
            <h3>Search with signal</h3>
            <p>Filter by what matters to you: skills, work style, location, and more.</p>
            <div className="search-bar"><Search size={15} /><span>Try "frontend internship"</span></div>
          </article>
          <article className="preview-panel resume-panel">
            <div className="panel-icon sage"><FileText size={19} /></div>
            <h3>Make your resume work harder</h3>
            <p>Get focused feedback and see exactly where you can stand out.</p>
            <div className="score-row">
              <div className="score-ring">85</div>
              <div><strong>Resume strength</strong><span>AI-powered feedback</span></div>
            </div>
          </article>
          <article className="preview-panel jobs-panel">
            <div className="panel-icon lilac"><BriefcaseBusiness size={19} /></div>
            <h3>Opportunities worth your time</h3>
            <div className="job-row">
              <div className="company-logo coral">T</div>
              <div><strong>Software Engineer Intern</strong><span>TechCorp · Remote</span></div>
              <span className="job-match">94%</span>
            </div>
            <div className="job-row">
              <div className="company-logo navy">D</div>
              <div><strong>Data Analyst</strong><span>DataCo · New York</span></div>
              <span className="job-match">88%</span>
            </div>
          </article>
        </div>
      </section>
    </main>
  );
}

/* ── Auth-gated route ────────────────────────────────────────────────── */
function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();
  if (isLoading) return null;
  if (!isAuthenticated) return <Navigate to="/" state={{ from: location }} replace />;
  return <>{children}</>;
}

/* ── Page layout wrapper (Navbar + Footer) ───────────────────────────── */
function PageLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navbar />
      <main className="main-content">
        <div className="container">{children}</div>
      </main>
      <Footer />
    </>
  );
}

/* ── App shell ───────────────────────────────────────────────────────── */
function AppShell() {
  return (
    <Routes>
      {/* Public routes – Navbar + Footer */}
      <Route path="/" element={<><Navbar /><Landing /><Footer /></>} />
      <Route path="/jobs" element={<PageLayout><JobsPage /></PageLayout>} />

      {/* Auth-gated routes */}
      <Route path="/dashboard" element={<PrivateRoute><PageLayout><Dashboard /></PageLayout></PrivateRoute>} />
      <Route path="/profile" element={<PrivateRoute><PageLayout><ProfilePage /></PageLayout></PrivateRoute>} />
      <Route path="/resumes" element={<PrivateRoute><PageLayout><ResumesPage /></PageLayout></PrivateRoute>} />
      <Route path="/applications" element={<PrivateRoute><PageLayout><ApplicationsPage /></PageLayout></PrivateRoute>} />
      <Route path="/saved-jobs" element={<PrivateRoute><PageLayout><SavedJobsPage /></PageLayout></PrivateRoute>} />
      <Route path="/notifications" element={<PrivateRoute><PageLayout><NotificationsPage /></PageLayout></PrivateRoute>} />
      <Route path="/ai" element={<PrivateRoute><PageLayout><AIToolsPage /></PageLayout></PrivateRoute>} />

      {/* Catch-all */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <AppShell />
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
