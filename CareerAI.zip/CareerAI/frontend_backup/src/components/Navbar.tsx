import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Sparkles, Bell, User, LogOut, Menu, X, Briefcase, FileText, Bookmark, CheckSquare, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import AuthModal from './AuthModal';
import api from '../services/api';

export const Navbar: React.FC = () => {
  const { user, isAuthenticated, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  const isActive = (path: string) => location.pathname === path;

  // Fetch unread notifications count if authenticated
  useEffect(() => {
    if (isAuthenticated) {
      api.get('/notifications?unread_only=true')
        .then((res) => setUnreadCount(res.data.length))
        .catch(() => {});
    }
  }, [isAuthenticated, location.pathname]);

  const openAuth = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setIsAuthOpen(true);
    setIsMobileMenuOpen(false);
  };

  const handleLogout = () => {
    logout();
    navigate('/');
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <header className="navbar">
        <div className="container navbar-inner">
          {/* Logo & Tagline */}
          <Link to="/" className="brand-logo">
            <div className="brand-icon">
              <Sparkles size={18} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              <span style={{ fontSize: '1.25rem', fontWeight: 800, lineHeight: 1.1 }}>
                career<span style={{ color: 'var(--accent)' }}>ai</span>
              </span>
              <span className="brand-tagline">Build a career that moves with you.</span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="nav-links">
            <Link to="/jobs" className={`nav-item ${isActive('/jobs') ? 'active' : ''}`}>
              <Briefcase size={16} style={{ display: 'inline', marginRight: '4px' }} /> Discover
            </Link>
            {isAuthenticated && user?.role === 'STUDENT' && (
              <>
                <Link to="/applications" className={`nav-item ${isActive('/applications') ? 'active' : ''}`}>
                  <CheckSquare size={16} style={{ display: 'inline', marginRight: '4px' }} /> Applications
                </Link>
                <Link to="/saved-jobs" className={`nav-item ${isActive('/saved-jobs') ? 'active' : ''}`}>
                  <Bookmark size={16} style={{ display: 'inline', marginRight: '4px' }} /> Saved
                </Link>
                <Link to="/resumes" className={`nav-item ${isActive('/resumes') ? 'active' : ''}`}>
                  <FileText size={16} style={{ display: 'inline', marginRight: '4px' }} /> Resumes
                </Link>
                <Link to="/ai" className={`nav-item ${isActive('/ai') ? 'active' : ''}`}>
                  <Sparkles size={16} style={{ color: 'var(--accent)', display: 'inline', marginRight: '4px' }} /> AI Tools
                </Link>
              </>
            )}
            {isAuthenticated && (
              <Link to="/dashboard" className={`nav-item ${isActive('/dashboard') ? 'active' : ''}`}>
                <LayoutDashboard size={16} style={{ display: 'inline', marginRight: '4px' }} /> Dashboard
              </Link>
            )}
          </nav>

          {/* Desktop Right Actions */}
          <div className="nav-actions">
            {isAuthenticated ? (
              <>
                <Link to="/notifications" className="btn-ghost" style={{ position: 'relative', padding: '8px' }} title="Notifications">
                  <Bell size={20} />
                  {unreadCount > 0 && (
                    <span style={{
                      position: 'absolute',
                      top: '4px',
                      right: '4px',
                      backgroundColor: 'var(--accent)',
                      color: 'white',
                      fontSize: '10px',
                      fontWeight: 700,
                      width: '16px',
                      height: '16px',
                      borderRadius: '50%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                      {unreadCount}
                    </span>
                  )}
                </Link>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Link to="/profile" className="btn-secondary btn-sm" style={{ gap: '0.375rem' }}>
                    <User size={15} />
                    <span>{user?.full_name.split(' ')[0]}</span>
                  </Link>
                  <button onClick={handleLogout} className="btn-ghost btn-sm" title="Log Out">
                    <LogOut size={16} />
                  </button>
                </div>
              </>
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <button onClick={() => openAuth('login')} className="btn-ghost btn-sm">
                  Sign In
                </button>
                <button onClick={() => openAuth('register')} className="btn-primary btn-sm">
                  Get Started
                </button>
              </div>
            )}

            {/* Mobile Hamburger Toggle */}
            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="btn-ghost" style={{ display: 'flex', padding: '6px' }} className-mobile-only>
              {isMobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Drawer */}
        {isMobileMenuOpen && (
          <div style={{
            backgroundColor: 'var(--surface)',
            borderBottom: '1px solid var(--border)',
            padding: '1rem 1.25rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.75rem',
          }}>
            <Link to="/jobs" onClick={() => setIsMobileMenuOpen(false)} className="nav-item">Discover Opportunities</Link>
            {isAuthenticated && (
              <>
                <Link to="/dashboard" onClick={() => setIsMobileMenuOpen(false)} className="nav-item">Dashboard</Link>
                <Link to="/applications" onClick={() => setIsMobileMenuOpen(false)} className="nav-item">My Applications</Link>
                <Link to="/saved-jobs" onClick={() => setIsMobileMenuOpen(false)} className="nav-item">Saved Jobs</Link>
                <Link to="/resumes" onClick={() => setIsMobileMenuOpen(false)} className="nav-item">Resume Center</Link>
                <Link to="/ai" onClick={() => setIsMobileMenuOpen(false)} className="nav-item">AI Career Tools</Link>
                <Link to="/notifications" onClick={() => setIsMobileMenuOpen(false)} className="nav-item">Notifications ({unreadCount})</Link>
                <Link to="/profile" onClick={() => setIsMobileMenuOpen(false)} className="nav-item">My Profile</Link>
                <button onClick={handleLogout} className="btn-secondary btn-sm" style={{ justifyContent: 'center', marginTop: '0.5rem' }}>
                  <LogOut size={16} /> Log Out
                </button>
              </>
            )}
            {!isAuthenticated && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', marginTop: '0.5rem' }}>
                <button onClick={() => openAuth('login')} className="btn-secondary">Sign In</button>
                <button onClick={() => openAuth('register')} className="btn-primary">Create Account</button>
              </div>
            )}
          </div>
        )}
      </header>

      {/* Auth Modal */}
      {isAuthOpen && (
        <AuthModal
          mode={authMode}
          onClose={() => setIsAuthOpen(false)}
          onSwitchMode={(mode) => setAuthMode(mode)}
        />
      )}
    </>
  );
};
